//選擇服務類型
var ways_id;
function showReservationCard() {
    // 顯示預定快取卡片
    showCard('reservationCard');
    document.getElementById('ways_id').value = 1;
    console.log(document.getElementById('ways_id').value);

    // 隱藏外送卡片
    hideCard('deliveryCard');
}

function showDeliveryCard() {
    // 顯示外送卡片
    showCard('deliveryCard');
    document.getElementById('ways_id').value = 2;
    console.log(document.getElementById('ways_id').value);

    // 隱藏預定快取卡片
    hideCard('reservationCard');
}

function showCard(cardId) {
    var card = document.getElementById(cardId);
    if (card) {
        card.style.display = 'block';
    }
}

function hideCard(cardId) {
    var card = document.getElementById(cardId);
    if (card) {
        card.style.display = 'none';
    }
}


function updateDescription(descriptionId, newText) {
    // 取得描述文字元素
    var description = document.getElementById(descriptionId);

    // 如果描述文字元素存在，更新內容
    if (description) {
        description.textContent = newText;
    }
}


var selectedCityId;
function loadDistricts() {

    var locationSelect = document.getElementById("locationSelect");
    var selectedCityId = document.getElementById("locationSelect").value;
    window.location.href = 'home_page.php?pickupcity_id=' + selectedCityId;
    console.log(selectedCityId);

}




var selectedCity;
var selectedCityId;

function updateCityValue() {
    // var selectLocation = document.getElementById("districtSelect").value;
    // var selectedCityId = document.getElementById("locationSelect").value;
    // // window.location.href = 'home_page.php?pickuparea_id=' + selectLocation;
    // window.location.href = 'home_page.php?pickupcity_id=' + selectedCityId + '&pickuparea_id=' + selectLocation;
    // console.log(selectLocation);
    // // selectedCity = select.options[select.selectedIndex].value;
    // // selectedCityId = select.options[select.selectedIndex].dataset.cityid;
    // // loadDistricts(); // 调用加载区域的函数
    var selectLocation = document.getElementById("districtSelect");
    var selectedAreaId = selectLocation.value;
    var selectedCityId = document.getElementById("locationSelect").value;

    // 如果選擇的地區不是空的，則將選中值設置為已選擇的地區
    if (selectedAreaId !== "") {
        selectLocation.setAttribute("selected_location", "selected_location");
    }

    window.location.href = 'home_page.php?pickupcity_id=' + selectedCityId + '&pickuparea_id=' + selectedAreaId;
}


function showDatePicker() {
    // 獲取日期選擇器面板元素
    var datePickerPanel = document.querySelector('.panel_tab1_date');

    // 切換日期選擇器的顯示/隱藏
    if (datePickerPanel.style.display === 'block') {
        datePickerPanel.style.display = 'none';
    } else {
        datePickerPanel.style.display = 'block';
    }
}


var selectedDateTime;
function L_DateClick(element) {
    var selectedDate = element.getAttribute('d'); // 取得所選日期
    var selectedWeekDay = getWeekDay(selectedDate); // 取得週幾
    var selectedHour = document.getElementById('Lct_sltDeliveryHourType2').value; // 取得所選小時
    var selectedMinute = document.getElementById('Lct_sltDeliveryMinuteType2').value; // 取得所選分鐘
    var selectedTime;
    // var selectedDateTime = selectedDate + ' ' + selectedHour + ':' + selectedMinute;
    // document.getElementById('selectedDateTime').value = selectedDateTime;

    // 存儲所選日期時間到全域變數中
    selectedDateTime = {
        date: selectedDate,
        weekday: selectedWeekDay,
        hour: selectedHour,
        minute: selectedMinute,
        time: selectedTime,
    };

    // 更新隱藏的 input 欄位
    document.getElementById('selectedDate').value = selectedDateTime.date;
    document.getElementById('selectedTime').value = selectedDateTime.hour + ':' + selectedDateTime.minute;
    console.log("selecteDate", selectedDate);
    console.log("selectedTime", selectedDateTime.hour + ':' + selectedDateTime.minute);


    // 將所選日期設定到 "flip_tab1_date" 元素中
    document.querySelector('.flip_tab1_date input').value = selectedDate + '(' + selectedWeekDay + ')' + ' ' + selectedHour + ':' + selectedMinute;
}

// function L_DateClick(element) {
//     var selectedDate = element.getAttribute('d'); // 取得所選日期
//     var selectedWeekDay = getWeekDay(selectedDate); // 取得週幾
//     var selectedHour = document.getElementById('Lct_sltDeliveryHourType2').value; // 取得所選小時
//     var selectedMinute = document.getElementById('Lct_sltDeliveryMinuteType2').value; // 取得所選分鐘

//     // 將所選日期和時間設定到 "flip_tab1_date" 元素中
//     var selectedDateValue = selectedDate + '(' + selectedWeekDay + ')';
//     var selectedTimeValue = selectedHour + ':' + selectedMinute;

//     document.getElementById('selectedDate').value = selectedDateValue;
//     document.getElementById('selectedTime').value = selectedTimeValue;

//     // 设置日期和时间到输入框
//     document.querySelector('.flip_tab1_date input').value = selectedDateValue + ' ' + selectedTimeValue;
// }


// 取得週幾
function getWeekDay(dateString) {
    var date = new Date(dateString);
    var days = ['日', '一', '二', '三', '四', '五', '六'];
    return days[date.getDay()];
}


function getDayOfWeek(dateString) {
    const daysOfWeek = ['日', '一', '二', '三', '四', '五', '六'];
    const date = new Date(dateString);
    const dayIndex = date.getDay();
    return daysOfWeek[dayIndex];
}





function updateButtonText(selectedText) {
    // 將選擇的文字更新到按鈕上
    document.getElementById('dropdownMenuButton1').innerText = selectedText;

    // 在這裡可以加入後端連接的程式碼，將選擇的內容傳送到後端
    // 例如，使用Ajax發送POST請求
    // 可以使用現代的前端框架（如Vue、React、Angular）來更方便地處理此類邏輯
    var currentUrl = window.location.href;
    var newUrl = currentUrl;

    if (selectedCityId !== undefined) {
        newUrl = updateQueryStringParameter(newUrl, 'pickupcity_id', selectedCityId);
    }

    if (selectedAreaId !== undefined) {
        newUrl = updateQueryStringParameter(newUrl, 'pickuparea_id', selectedAreaId);
    }

    // 重新導向到新的 URL
    if (newUrl !== currentUrl) {
        window.location.href = newUrl;
    }
}

// 更新 URL 中的查詢字符串參數
function updateQueryStringParameter(uri, key, value) {
    // 將查詢字符串分割成陣列
    var parts = uri.split("?");
    // 取得查詢字符串
    var queryString = parts.length > 1 ? parts[1] : "";

    // 將查詢字符串轉換為物件
    var params = new URLSearchParams(queryString);
    // 設定或新增參數
    params.set(key, value);

    // 將參數添加到 URL 中
    var newUrl = parts[0] + "?" + params.toString();

    return newUrl;
}

function submitOrderForm() {
    // 获取隐藏输入字段中的值
    var waysId = document.getElementById("waysId").value;
    var branchId = document.getElementById("branchId").value;

    // 将获取的值设置到隐藏字段中（确保值是最新的）
    document.getElementById("waysId").value = waysId;
    console.log(waysId);
    document.getElementById("branchId").value = branchId;
    console.log(branchId);

    // 提交表单
    document.getElementById("orderForm").submit();
}

