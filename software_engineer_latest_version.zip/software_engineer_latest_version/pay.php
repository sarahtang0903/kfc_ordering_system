<?php

// session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼

include("check_login.php");
$member_id = $_SESSION['member_id'];

$bagprice = 0;

$sql = "SELECT * FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);

$sql_shoppingbag = "SELECT shoppingbag FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
// $sql_shoppingbag = "SELECT shoppingbag FROM shoppingcart join member on member.member_id = $pay_member_id";
$result_shoppingbag = mysqli_query($link, $sql_shoppingbag);
$row_shoppingbag = mysqli_fetch_assoc($result_shoppingbag);

$test_1 = $row_shoppingbag['shoppingbag'];
// var_dump("shoppingbag:", $test_1);

$sql_test = "SELECT shoppingcart_meals_name FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
// $sql_test = "SELECT shoppingcart_meals_name FROM shoppingcart join member on member.member_id = $pay_member_id";
$result_test = mysqli_query($link, $sql_test);
$row_test = mysqli_fetch_assoc($result_test);

$sql_content = "SELECT * FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
$result_content = mysqli_query($link, $sql_content);
$row_content = mysqli_fetch_assoc($result_content);

$sql_member = "SELECT * FROM `member` WHERE member_id = $member_id";
$result_member = mysqli_query($link, $sql_member);
$row_member = mysqli_fetch_assoc($result_member);

$sql_ways = "SELECT shoppingbag FROM shoppingcart join member on member.member_id = shoppingcart.member_id";;
$result_ways = mysqli_query($link, $sql_ways);
$row_ways = mysqli_fetch_assoc($result_ways);

$sql_date = "SELECT * FROM `date` WHERE member_id = $member_id";
$result_date = mysqli_query($link, $sql_date);
$row_date = mysqli_fetch_assoc($result_date);

$sql_mux = "SELECT * from ((shoppingcart join ways on shoppingcart.ways_id = ways.ways_id join pickupcity on pickupcity.ways_id = ways.ways_id) join pickuparea on pickuparea.pickupcity_id = pickupcity.pickupcity_id) join branch on branch.pickuparea_id = pickuparea.pickuparea_id where shoppingcart.branch_id = branch.branch_id";
$result_mux = mysqli_query($link, $sql_mux);
$row_mux = mysqli_fetch_assoc($result_mux);

$sql_method = "SELECT * from shoppingcart join ways on shoppingcart.ways_id = ways.ways_id";
$result_method = mysqli_query($link, $sql_method);
$row_method = mysqli_fetch_assoc($result_method);

$sql_side = "SELECT * from shoppingcart join delivery on shoppingcart.delivery_id = delivery.delivery_id";
$result_side = mysqli_query($link, $sql_side);
$row_side = mysqli_fetch_assoc($result_side);

 
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $userInput = $_POST["userInput"];
    
    $member_id_get = $_POST['member_id'];
    var_dump($_POST['member_id']); 
    // 验证输入长度
    if (strlen($userInput) > 12) {         
        $sql = "DELETE FROM shoppingcart where member_id = $member_id_get";
        if ($link->query($sql) === TRUE) {
            echo "users資料表中的所有資料已成功刪除";
            header("Location: home_page.php");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $link->error;
        }
    } else {
        echo "输入不能小於12個字符";
    }     
}
 
?>


<!DOCTYPE html>
<html>

<head>
    <!--網頁編碼ｕｔｆ－８-->
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC Website</title>
    <style>
        /* 設定select元素的寬度 */
        select {
            width: 418px;
            /* 設定寬度為200像素 */
            height: 25px;
        }

        hr {
            border-color: #d61111;
            /* 使用16進制顏色碼，這裡是紅色 */
            /* text-align: left;
                width: 1000px; */
            width: 1000px;
            margin-left: 0;
        }

        .right-image {
            float: right;
            margin-left: 10px;
            /* 可以添加一些左邊距，以避免與文本太靠近 */
        }

        .button {
            padding: 10px;
            font-size: 14px;
            background-color: #d61111;
            /* 可以根據需要修改按鈕的背景顏色 */
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
        }

        /* 滑鼠懸停時改變背景顏色 */
        .button-finish {
            padding: 10px 350px;
        }

        button:hover {
            background-color: #2980b9;
        }

        .indent {
            margin-left: 40px;
            /* 調整左邊的空格寬度 */
        }

        .rightt {
            margin-left: 900px;
            /* 調整左邊的空格寬度 */
        }

        .rightl {
            margin-left: 800px;
            /* 調整左邊的空格寬度 */
        }

        .collapsible {
            background-color: #faf6f3;
            color: darksalmon;
            cursor: pointer;
            padding: 18px;
            width: 1000px;
            border: none;
            text-align: left;
            outline: none;
            font-size: 15px;
        }

        .active,
        .collapsible:hover {
            background-color: #faf6f3;
        }

        .content {
            padding: 0 5px;
            max-height: 0;
            width: 1000px;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
            background-color: #f1f1f1;
        }

        .custom-button {
            background-image: url('Mark.png');
            /* 替換成您的圖片路徑 */
            background-size: cover;
            /* 調整圖片大小以填滿按鈕 */
            width: 100px;
            /* 設定按鈕寬度 */
            height: 100px;
            /* 設定按鈕高度 */
            border: none;
            /* 去除按鈕邊框 */
            cursor: pointer;
        }

        .background {
            position: sticky;
            background-color: #fff;
            width: 1050px;
            top: 0;
        }
    </style>
    <script>
        // function showPrompt() {
        //     alert("已送出訂單!！");
        // }

        function validateCardNumber() {
            var cardNumber = document.getElementById('cardNumber').value;
            var sum = 0;
            var alternate = false;
            if (cardNumber) {
                for (var i = cardNumber.length - 1; i >= 0; i--) {
                    var n = parseInt(cardNumber[i], 10);
                    if (alternate) {
                        n *= 2;
                        if (n > 9) {
                            n = (n % 10) + 1;
                        }
                    }

                    sum += n;
                    alternate = !alternate;
                }
            } else {
                sum = 1;
            }


            var isValid = (sum % 10 === 0);
            alert(isValid ? "Card number is valid" : "Card number is invalid");
            var flag = isValid ? 1 : 0;
        }
    </script>


</head>
<!--webite 主畫面，都寫在ｂｏｄｙ標籤中-->

<body style="background-color: #faf6f3;">
    <!--<a href = "https://www.kfcclub.com.tw/">KFC訂購網站</a>-->
    <!-- <img src = "Mark.png"/> -->
    <!-- <form action="otherPage.php" method="post" class="inline-form">
            <button class="custom-button"></button>
        </form> -->
    <!-- <img class="rightt" src = "member.png"/>
        <form action="otherPage.php" method="post" class="inline-form">
            <button class="custom-button"></button>
        </form> -->
    <p class="background">
        <!-- <img src = "Mark.png" height="65" width="65" margin-top="0" margin-left="125"/>
        <img src = "member.png" class="rightt"height="50" width="50"/> -->
        <a href="home_page.php">
            <img src="Mark.png" alt="Clickable Image">
        </a>
        <a href="initial.php">
            <img class="rightt" src="member.png" alt="Clickable Image">
        </a>
    </p>
    <br>
    <img src="meal_detail.png" />
    <br>
    <button type="button" class="collapsible" style="font-size: 20px;">餐點內容 ▼</button>
    <div class="content">
        <?php
        // $width = 200;
        // $price_total = 0;
        // while ($row = mysqli_fetch_assoc($result)) {
        //     if ($row_content["shoppingcart_meals_name"] != $row_test["shoppingcart_meals_name"]) {
        //         $row_test = mysqli_fetch_assoc($result_test);
        //     } else {
        ?>
                <!-- <div class="mealTitle"> -->

                    <?php
                    // echo '<p class="indent">' . $row["shoppingcart_meals_name"];

                    // for ($a = 0; $a < 2; $a++) {
                    // ?>&nbsp;<?php
                    //     }
                    //         ?>
                    <!-- $ -->
                    <?php
                    // echo $row["shoppingcart_meals_price"];
                    // $price_total += $row["shoppingcart_meals_price"];
                    ?>
                </div>
                <?php
                // while ($row_content = mysqli_fetch_assoc($result_content)) {
                //     if ($row_content["shoppingcart_meals_name"] == $row_test["shoppingcart_meals_name"]) {
                ?>
        <?php
        //             } else {
        //                 $row_test = mysqli_fetch_assoc($result_test);
        //                 break;
        //             }
        //         }
        //     }
        // }
        ?>
        <?php
      $prevComboName = null;
      $width = 200;
      $price_total = 0;
      ?>
       
      <?php
      while ($row_content = mysqli_fetch_assoc($result)) {
        $comboName = $row_content["shoppingcart_meals_name"];
    
        // 检查套餐名是否变化
        if ($comboName != $prevComboName) {
          ?>
          <div class="mealTitle">

            <?php
            echo '<p class="indent">' . $row_content["shoppingcart_meals_name"];

            for ($a = 0; $a < 2; $a++) {
            ?>&nbsp;<?php
                }
                    ?>
            $
            <?php
            echo $row_content["shoppingcart_meals_price"];
            $price_total += $row_content["shoppingcart_meals_price"];
            ?>
            </div> 
    
               
              <?php
            $prevComboName = $comboName;
        }           
        
    ?>
         
         
    
         
 <?php        
    }
    ?>
        <div class="mealTitle">

            購物袋 x<?php
                    for ($a = 0; $a < 2; $a++) {
                    ?>&nbsp;<?php
                        }
                        echo $row_shoppingbag["shoppingbag"];
                        for ($a = 0; $a < 2; $a++) {
                            ?>&nbsp;<?php
                                }
                                    ?>
            $<?php
                $bagprice = $row_shoppingbag["shoppingbag"] * 3;
                echo $bagprice;
                ?>
        </div>


        <!--<div class="font_24 checkoutTotal" displayfor="propmotion">
                 金額總計
                <span class="floatR" id="Cart_TotalSum">0</span>
                <span class="floatR">$</span>
                </div> -->

        <!-- 按鈕 -->
        <form action="shoppingcart.php" method="post" class="inline-form">
            <button class="button rightl">修改訂單</button>
        </form>

    </div>
    <!-- <div class="rightt"><button class="button">送出訂單</button></div> -->
    <script>
        var coll = document.getElementsByClassName("collapsible");
        for (var i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }
            });
        }
    </script>
    <br>
    <img src="meal_info.png" />
    <ul>
        <li style="font-size: 20px;">訂購人</li>
        <form action="/test.aspx" method="post">
            <?php
            echo '<input type="text" style="width: 800px; height: 20px;" id="myInput" value="' . $row_member["gender"] . '">';
            ?>
            <!-- <input type="text" style="width: 800px; height: 20px;" > -->
        </form>
        <li style="font-size: 20px;">電子信箱</li>
        <form action="/test.aspx" method="post">
            <?php
            echo '<input type="text" style="width: 800px; height: 20px;" id="myInput" value="' . $row_member["member_email"] . '">';
            ?>
        </form>
        <li style="font-size: 20px;">手機</li>
        <form action="/test.aspx" method="post">
            <?php
            echo '<input type="text" style="width: 800px; height: 20px;" id="myInput" value="' . $row_member["member_phone"] . '">';
            ?>
        </form>
        <li style="font-size: 20px;">發票類型</li>
        <form>
            <input type="radio" name="option" value="paper"> 列印電子發票<br>
        </form>
    </ul>
    <div class="indent" style="font-size: 20px;">備註</div>
    <form action="/test.aspx" method="post">
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <input type="text" style="width: 820px; height: 50px;">
    </form>
    <form method="GET" action="data.php">
        <!-- username: <input name="username">
        age: <input name="age">
        <input type="submit"> -->
    </form>
    <br>
    <img src="meal_method.png" />
    <!-- <div class="container">
        <div style="color: darksalmon;">&nbsp;&nbsp;訂餐方式:</div>
        &nbsp;&nbsp;
        <?php
        // echo $sql_method["ways_name"];
        ?>
    </div> -->
    <!-- -----------------------靠背阿----------------------------------------- -->
    <div class="container">
        <div style="color: darksalmon;">&nbsp;&nbsp;訂餐方式:</div>
        &nbsp;&nbsp;
        <?php
        if (isset($row_method["ways_name"])) {
            echo $row_method["ways_name"];
        } else {
            echo "未找到訂餐方式";
        }
        ?>
    </div>
    <div style="color: darksalmon;">&nbsp;&nbsp;取餐地點:</div>
    &nbsp;&nbsp;
    <?php
    if ($row_method["ways_id"] == 1) {
        echo $row_mux["branch_name"];
        echo $row_mux["branch_address"];
    } else
        echo $row_side["address"];
    ?>
    <!-- -----------------------靠背阿----------------------------------------- -->
    <div style="color: darksalmon;">&nbsp;&nbsp;預計取餐時間:</div>
    &nbsp;&nbsp;
    <?php
    echo $row_date["date"];
    ?>
    &nbsp;&nbsp;&nbsp;
    <?php
    // $hours = range(0, 23); // 小時從0到23
    // $minutes = range(0, 55, 5); // 分鐘從0到55，間隔為5分鐘
    // date_default_timezone_set('Asia/Taipei');
    // // 獲取當前時間
    // $currentHour = date('G');
    // $currentMinute = date('i');
    // // echo $currentHour;
    // // echo $currentMinute;
    // // list($hour1, $minute1, $second1) = explode(":", $row_date["time"]);
    // echo '<select name="hour">';
    // foreach ($hours as $hour) {
    //     // 過濾掉已經過去的小時
    //     if ($hour >= $currentHour) {
    //         $selected = ($hour == $hour1) ? 'selected' : ''; // 如果是預設的小時，設置 selected
    //         echo "<option value='$hour' $selected>$hour</option>";
    //     }
    // }
    // echo '</select>';

    // echo '<select name="minute">';
    // foreach ($minutes as $minute) {
    //     // 如果當前小時等於選擇的小時，過濾掉已經過去的分鐘
    //     $selected = ($currentHour == date('G') && $minute == $minute1) ? 'selected' : ''; // 如果是預設的分鐘，設置 selected
    //     echo "<option value='$minute' $selected>$minute</option>";
    // }
    //echo '</select>';
    ?>

    <div class="times">
        <div>&nbsp;&nbsp;&nbsp;
            <select id="Lct_sltDeliveryHourType2">
                <option>07</option>
                <option>08</option>
                <option>09</option>
                <option>10</option>
                <option>11</option>
                <option>12</option>
                <option>13</option>
                <option>14</option>
                <option>15</option>
                <option>16</option>
                <option>17</option>
                <option>18</option>
                <option>19</option>
                <option>20</option>
                <option>21</option>
                <option>22</option>
                <option>23</option>
            </select>
            <select id="Lct_sltDeliveryHourType3">
                <option>00</option>
                <option>05</option>
                <option>10</option>
                <option>15</option>
                <option>20</option>
                <option>25</option>
                <option>30</option>
                <option>35</option>
                <option>40</option>
                <option>45</option>
                <option>50</option>
                <option>55</option>
            </select>
        </div>
        <br>
        <br>
        <img src="pay_option.png" />
        <hr />
        <div style="font-size:25px; color: #d61111;">&nbsp;&nbsp;待付金額:
            <?php
            echo "<span class='rightl'>" . $price_total + $bagprice . "</span>";
            ?>
        </div>

        <hr />
        <!-- <input type="radio" name="option" value="paper"> <img src = "pay_picture .png"/>信用卡付款<br>
            <div class="indent"><input type="text" style="width: 800px; height: 20px;" ></div> -->

        <!-- <div class="container">
        <input type="radio" id="visa" name="cardType" value="Visa">
        <label for="VISA">VISA</label>
        &nbsp;&nbsp;<input type="text" id="cardNumber" style="width: 800px; height: 20px" placeholder="Enter your card number">
        &nbsp;&nbsp;<button onclick="validateCardNumber()">Validate</button>
    </div> -->

        <!--<form method="post" action="<?//php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">-->
        <form method="POST" action="pay.php">
            <input type="radio" id="visa" name="cardType" value="Visa">
            <label for="userInput">VISA：</label>
            <input type="text" name="userInput" id="userInput" style="width: 800px; height: 20px" placeholder="Enter your card number" maxlength="19">
            <!--<input type="submit" name="valid" value="提交">-->
        
         
            <!-- 按鈕 -->
            <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <input type="hidden" name="member_id" value="<?php echo $member_id;?>">
            <input type="submit" class="button button-finish" value="送出訂單" name="delete">
             
        </form>




</body>

</html>