<?php
session_start();

// 執行 unset 操作
unset($_SESSION['member_id']);
unset($_SESSION['logged_in']);
unset($_SESSION['user_acc']);
unset($_SESSION['user_pwd']);

// 重定向回 initial.php 或其他您想要返回的頁面
header("Location: initial.php");
exit(); // 確保在執行 header 之後退出腳本
?>