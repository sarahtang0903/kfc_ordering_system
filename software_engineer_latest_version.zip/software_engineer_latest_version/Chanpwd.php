<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取新密码和确认新密码
    $newPassword = $_POST['newPassword'];
    $confirmNewPassword = $_POST['confirmNewPassword'];

    // 检查新密码和确认新密码是否匹配
    if ($newPassword === $confirmNewPassword) {

        $accountId = $_SESSION['ep'];

        // 在此处将新密码与帐号相关联，例如将其更新到数据库中
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "software_db";

        // 建立与数据库的连接
        $link = mysqli_connect($servername, $username, $password, $database) or die("无法选择数据库"); // 建立与数据库的连接对象
        mysqli_query($link, "SET NAMES utf8"); // 设置编码

        // 检查连接是否成功
        if (!$link) {
            die("连接失败: " . mysqli_connect_error());
        }

        // 使用帐号更新密码的SQL语句，假设表名为`member`，列名为`member_pwd`
        $sql = "UPDATE `member` SET `member_pwd` = '$newPassword' WHERE (`member_phone` = '$accountId' OR `member_email` = '$accountId')";
        $result = mysqli_query($link, $sql);

        if ($result) {
            // 密码更新成功，您可以执行其他操作或重定向到其他页面
            header("Location: initial.php");
            exit();
        } else {
            $_SESSION['error_message'] = "密码更新失败：" . mysqli_error($link);
            echo "密码更新失败：" . mysqli_error($link); // 添加此行以查看详细的错误消息
        }


        // 关闭连接
        mysqli_close($link);
    } else {
        $_SESSION['error_message'] = "新密码和确认新密码不匹配";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>修改密碼</title>
    <link rel="stylesheet" href="Chanpwd.css">
    <style>

    </style>
</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">
                <a href="home_page.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
                </a>
            </div>
            <div class="user-controls">
                <button id="unsetbutton">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="Member Icon" width="20" height="20">
                </button>
                <div class="cart-icon">
                    <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="Shopping Cart Icon" width="50" height="50"></a>
                </div>
            </div>
        </div>
        <nav class="header-bottom">
            <a href="hotdeal.php">熱門優惠</a>
            <a href="individual.php">個人餐</a>
            <a href="many.php">多人餐</a>
            <a href="breakfast.php">早餐</a>
            <a href="single.php">單點</a>
        </nav>
    </header>
    <script>
        document.getElementById("unsetbutton").addEventListener("click", function() {
            window.location.href = "unset_session.php";
        });
    </script>
    <main class="change-password">
        <div class="content">
            <div class="change-password__form">
                <div class="content">
                    <h1>修改密碼</h1>

                    <form action="ChanPwd.php" method="post">

                        <div class="input-wrapper">
                            <label for="newPassword">新密碼：</label>
                            <input type="password" id="newPassword" name="newPassword" required>
                        </div>
                        <div class="input-wrapper">
                            <label for="confirmNewPassword">確認新密碼：</label>
                            <input type="password" id="confirmNewPassword" name="confirmNewPassword" required>
                        </div>
                        <div>
                            <button type="submit" class="btn block btn-spacing"><span>確認修改</span></button>
                        </div>
                        <div id="error-message">
                            <?php
                            if (isset($_SESSION['error_message'])) {
                                echo '<p style="color: red;">' . $_SESSION['error_message'] . '</p>';
                                unset($_SESSION['error_message']); // 清除错误消息
                            }
                            ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>
</body>

</html>