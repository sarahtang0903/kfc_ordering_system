<?php
// header('Content-Type: application/json;charset=utf-8');
// session_start();
// $comboId = $_SESSION['combo_id'];
$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼
include("check_login.php");
?>

<!DOCTYPE html>
<html lang="en">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="hotdeal.css">
</head>

<body class="page-hotdeal">
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <button>
                <a href="initial.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>
        </div>
    </header>

    <nav>
        <a href="hotdeal.php">熱門優惠</a>
        <a href="individual.php" style="color: red;">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php">早餐</a>
        <a href="single.php">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>
    <nav class="hotdeal_bar">
        <a href="#individual_1">XL超豪肯!餐</a>
        <a href="#individual_2">L絕配餐</a>
        <a href="#individual_3">M經典餐</a>
        <a href="#individual_4">S雞勵餐</a>
        <a href="#individual_5">上校私廚沙拉</a>
    </nav>

    <h1></h1>
    <!--XL超豪肯!餐  -->
    <h1 id="individual_1">XL超豪肯!餐</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡XL">
            <div class="card-body">
                <h5 class="card-title">雙層咔啦雞腿堡XL餐</h5>
                <p class="card-text">
                <div>雙層咔啦雞腿堡 x 1</div>
                <div>咔啦脆雞(辣) x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$260</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 1";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1XL%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="海陸堡XL餐">
            <div class="card-body">
                <h5 class="card-title">海陸咔啦脆雞Q蝦堡XL餐</h5>
                <p class="card-text">
                <div>海陸咔啦脆雞Q蝦堡 x 1</div>
                <div>咔啦脆雞(辣) x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>...更多</div>
                <div>$245</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 2";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-XL-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞">
            <div class="card-body">
                <h5 class="card-title">剝皮辣椒紙包雞XL套餐</h5>
                <p class="card-text">
                <div>剝皮辣椒紙包雞 x 1</div>
                <div>20:00前供應雞汁風味飯 x 1</div>
                <div>上校雞塊4塊 x 1</div>
                <div>...更多</div>
                <div>$245</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 3";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-XL%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e9%ba%bb%e9%9b%9e20221215-pc.jpg" class="card-img-top" alt="XL餐-青花椒麻雞">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻脆雞XL餐</h5>
                <p class="card-text">
                <div>青花椒香麻脆雞(辣) x 1</div>
                <div>上校雞塊4塊 x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>$235</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 4";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒卡啦雞腿堡XL餐">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻咔啦雞腿堡套餐</h5>
                <p class="card-text">
                <div>青花椒香麻咔啦雞腿堡 x 1</div>
                <div>咔啦脆雞(辣) x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>...更多</div>
                <div>$220</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 5";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>


    </div>
    <!-- XL超豪肯!餐 -->

    <!-- L絕配餐 -->
    <h1 id="individual_2">L絕配餐</h1>
    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1L%e7%b5%95%e9%85%8d%e9%a4%90-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡L絕配餐">
            <div class="card-body">
                <h5 class="card-title">雙層咔啦雞腿堡L絕配餐</h5>
                <p class="card-text">
                <div>雙層咔啦雞腿堡 x 1</div>
                <div>香酥脆薯(小) x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$230</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 6";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1L%e7%b5%95%e9%85%8d%e9%a4%9020320417-pc.jpg" class="card-img-top" alt="海陸堡L絕配餐">
            <div class="card-body">
                <h5 class="card-title">海陸咔啦脆雞Q蝦堡XL餐</h5>
                <p class="card-text">
                <div>海陸咔啦脆雞Q蝦堡 x 1</div>
                <div>香酥脆薯(小) x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$215</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 7";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-L-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-L">
            <div class="card-body">
                <h5 class="card-title">剝皮辣椒紙包雞L配餐</h5>
                <p class="card-text">
                <div>剝皮辣椒紙包雞 x 1</div>
                <div>20:00前供應雞汁風味飯 x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$205</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 8";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-L%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e9%ba%bb%e9%9b%9e20221214-pc.jpg" class="card-img-top" alt="L餐-青花椒麻雞">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻脆雞 絕配餐</h5>

                <p class="card-text">
                <div>青花椒香麻脆雞(辣) x 2</div>
                <div>香酥脆薯(小) x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$195</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 9";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-L%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a120221214-pc.jpg" class="card-img-top" alt="L餐-青花椒咔啦雞腿堡">
            <div class="card-body">
                <h5 class="card-title">青花椒咔啦雞腿堡 絕配餐</h5>
                <p class="card-text">
                <div>青花椒香麻咔啦雞腿堡 x 1</div>
                <div>香酥脆薯(小) x 1</div>
                <div>原味蛋塔 x 1</div>
                <div>...更多</div>
                <div>$170</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 10";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>



    </div>
    <!-- L絕配餐結束 -->

    <!-- M經典餐開始 -->

    <h1 id="individual_3">M經典餐開始</h1>
    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1M%e7%b6%93%e5%85%b8%e9%a4%90-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡M經典餐">
            <div class="card-body">
                <h5 class="card-title">雙層咔啦雞腿堡M經典餐</h5>
                <p class="card-text">
                <div>雙層咔啦雞腿堡 x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>百事可樂(中) x 1</div>
                <div>$205</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 11";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1M%e7%b6%93%e5%85%b8%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="海陸堡M經典餐">
            <div class="card-body">
                <h5 class="card-title">海陸卡啦脆雞Q蝦堡M經典餐</h5>
                <p class="card-text">
                <div>海陸卡啦脆雞Q蝦堡 x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>百事可樂(中) x 1</div>
                <div>$195</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 12";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-M-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-M">
            <div class="card-body">
                <h5 class="card-title">剝皮辣椒紙包雞M經典餐</h5>
                <p class="card-text">
                <div>剝皮辣椒紙包雞 x 1</div>
                <div>20:00前供應雞汁風味飯 x 1</div>
                <div>百事可樂(中) x 1</div>
                <div>...更多</div>
                <div>$185</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 13";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%a5%93%e7%b3%96%e9%86%ac%e8%84%86%e9%9b%9e-M-20231127-pc.jpg" class="card-img-top" alt="青花椒香麻脆雞個人餐-M">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻脆雞 M經典餐</h5>
                <p class="card-text">
                <div>青花椒香麻脆雞(辣) x 2</div>
                <div>香酥脆薯(中) x 1</div>
                <div>百事可樂(中) x 1</div>
                <div>$181</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 14";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒香麻咔啦雞腿M">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻咔啦雞腿堡 M經典餐</h5>
                <p class="card-text">
                <div>青花椒香麻咔啦雞腿堡 x 1</div>
                <div>香酥脆薯(中) x 1</div>
                <div>百事可樂(中) x 1</div>
                <div>$157</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 15";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>



    </div>

    <!-- M經典餐結束 -->

    <!-- S雞勵餐開始 -->
    <h1 id="individual_4">S雞勵餐</h1>
    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%be%8e%e5%bc%8f%e7%85%99%e7%87%bb%e5%92%94%e8%84%86%e9%9b%9e%e5%a0%a120230208-pc.jpg" class="card-img-top" alt="美式煙燻咔脆雞堡-雞勵餐">
            <div class="card-body">
                <h5 class="card-title">美式煙燻咔脆雞堡 雞勵餐</h5>
                <p class="card-text">
                <div>美式煙燻咔脆雞堡 x 1</div>
                <div>百事可樂(小) x 1</div>
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 16";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e5%92%94%e5%95%a6%e9%85%a5%e8%84%86%e9%a4%9020221214-pc.jpg" class="card-img-top" alt="咔啦酥脆餐-雞勵餐">
            <div class="card-body">
                <h5 class="card-title">咔啦酥脆 雞勵餐</h5>
                <p class="card-text">
                <div>咔啦酥脆(辣) x 1</div>
                <div>上校雞塊 x 2</div>
                <div>百事可樂(小) x 1</div>
                <div>$109</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 17";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-8%e5%a1%8a%e4%b8%8a%e6%a0%a1%e9%9b%9e%e5%a1%8a%e9%a4%90%e9%9b%9e%e5%8b%b5%e9%a4%9020221215-pc.jpg" class="card-img-top" alt="8塊上校雞塊餐雞勵餐">
            <div class="card-body">
                <h5 class="card-title">8塊上校雞塊 雞勵餐</h5>
                <p class="card-text">
                <div>上校雞塊8塊 x 1</div>
                <div>百事可樂(小) x 1</div>
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 18";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e5%8e%9f%e5%91%b3%e8%b5%b7%e5%8f%b8%e7%87%bb%e9%9b%9e%e6%8d%b2%e9%9b%9e%e5%8b%b5%e9%a4%9020221215-pc.jpg" class="card-img-top" alt="原味起司燻雞捲雞勵餐">
            <div class="card-body">
                <h5 class="card-title">原味起司燻雞捲 雞勵餐</h5>
                <p class="card-text">
                <div>原味起司燻雞捲 x 1</div>
                <div>百事可樂(小) x 1</div>
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 19";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e8%8a%b1%e7%94%9f%e8%b5%b7%e5%8f%b8%e9%9b%9e%e6%9f%b3%e6%8d%b2%e9%9b%9e%e5%8b%b5%e9%a4%9020221215-pc.jpg" class="card-img-top" alt="花生起司雞柳捲雞勵餐">
            <div class="card-body">
                <h5 class="card-title">花生起司雞柳捲 雞勵餐</h5>
                <p class="card-text">
                <div>花生起司雞柳捲 x 1</div>
                <div>百事可樂(小) x 1</div>
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 20";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>


    </div>

    <!-- S雞勵餐結束 -->

    <!-- 上校私廚沙拉開始 -->
    <h1 id="individual_5">上校私廚沙拉</h1>
    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%83%a4%e9%9b%9e%e6%ba%ab%e6%b2%99%e6%8b%89%e5%a5%97%e9%a4%90(%e4%b8%8d%e9%81%a9%e7%94%a8%e5%a4%96%e9%80%81)-210927-pc.jpg" class="card-img-top" alt="烤雞溫沙拉套餐">
            <div class="card-body">
                <h5 class="card-title">上校私廚烤雞腿溫沙拉套餐</h5>
                <p class="card-text">
                <div>烤雞溫沙拉 x 1</div>
                <div>玉米濃湯(小) x 1</div>
                <div>響應環保不需叉子 x 1</div>
                <div>$178</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 21";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%87%b1%e8%96%a9%e7%83%a4%e5%9c%b0%e7%93%9c%e6%b2%99%e6%8b%89%e5%a5%97%e9%a4%9020220519-pc.jpg" class="card-img-top" alt="凱薩烤地瓜沙拉套餐">
            <div class="card-body">
                <h5 class="card-title">凱薩烤地瓜沙拉套餐</h5>
                <p class="card-text">
                <div>凱薩烤地瓜沙拉 x 1</div>
                <div>經典玉米 x 1</div>
                <div>無糖綠茶(中) x 1</div>
                <div>...更多</div>
                <div>$178</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 22";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%83%a4%e9%9b%9e%e6%ba%ab%e6%b2%99%e6%8b%89-%e5%96%ae%e9%bb%9e-211004-pc.jpg" class="card-img-top" alt="烤雞溫沙拉-單點">
            <div class="card-body">
                <h5 class="card-title">上校私廚烤雞溫沙拉</h5>
                <p class="card-text">
                <div>響應環保不需叉子 x 1</div>
                </p>
                <div>$135</div>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 23";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%87%b1%e8%96%a9%e7%83%a4%e5%9c%b0%e7%93%9c%e6%b2%99%e6%8b%8920220518-pc.jpg" class="card-img-top" alt="凱薩烤地瓜沙拉">
            <div class="card-body">
                <h5 class="card-title">凱薩烤地瓜沙拉</h5>
                <p class="card-text">
                <div>響應環保不需叉子 x 1</div>
                </p>
                <div>$129</div>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 24";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>



    </div>
    <!-- 上校私廚沙拉結束 -->






</body>

</html>