<?php
// header('Content-Type: application/json;charset=utf-8');

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼
include("check_login.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $member_id = $_SESSION['member_id'];
    $ways_Id = $_POST['ways_id'];
    var_dump($ways_Id);

    if ($ways_Id == 1) {
        $branch_Id = $_POST['branch_id'];
        $re_date = date("Y-m-d", strtotime($_POST['selectedDate']));
        $re_time = $_POST['selectedTime'];
        //$sql_time = "UPDATE `date` SET `date` = '$re_date', `time` = '$re_time'";
        $sql_time = "INSERT INTO date (date, time, member_id) VALUES ('$re_date', '$re_time', '$member_id')";
        mysqli_query($link, $sql_time);
        //$sql_shop = "UPDATE shoppingcart SET `ways_id`= '1', `branch_id` = '$branch_Id'";
        //mysqli_query($link, $sql_shop);

        $_SESSION['branch_id'] = $branch_Id;
        $lastInsert_date_id = mysqli_insert_id($link);
        $_SESSION['date_id'] = $lastInsert_date_id;
    } elseif ($ways_Id == 2) {
        $delivery_address =  $_POST['delivery_address'];
        //$sql_delivery = "UPDATE delivery SET `address` = '$delivery_address'";  // Assuming member_id is 1 for example
        $sql_delivery = "INSERT INTO delivery (`address`, ways_id, member_id) VALUES ('$delivery_address', $ways_Id, $member_id)";
        mysqli_query($link, $sql_delivery);
        //$sql_delivery_shoppingcart = "UPDATE shoppingcart SET `ways_id` = '2', `delivery_id` = '1'";
        //mysqli_query($link, $sql_delivery_shoppingcart);
        $last_delivery_id = mysqli_insert_id($link);
        $_SESSION['delivery_id'] = $last_delivery_id;
    }
    $_SESSION['ways_id'] = $ways_Id;


    header("Location: hotdeal.php");
    exit();  // Ensure that no more output is sent
}





?>


<!DOCTYPE php>
<html lang="en">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="home_page.css">
</head>

<body>
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <!--<button>
                <a href="initial.php">                 
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>-->
            <button id="unsetbutton">
                <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">

            </button>
            <script>
                document.getElementById("unsetbutton").addEventListener("click", function() {

                    window.location.href = "unset_session.php";
                });
            </script>
        </div>
    </header>

    <nav>
        <a href="hotdeal.php">熱門優惠</a>
        <a href="individual.php">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php">早餐</a>
        <a href="single.php">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>

    <div id="features-container">
        <div class="btn-group" role="group" aria-label="Basic radio toggle button group">
            <input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" checked>
            <label class="btn btn-white" for="btnradio1" onclick="showReservationCard()">
                <img src="https://storage.googleapis.com/kfcoosfs/tab_btn_startOrder_r.png" alt="Reservation Icon" style="width: 20px; height: 20px; margin-right: 8px;">
                <?php
                $sql = "SELECT * FROM ways WHERE ways_id = 1";
                $waysId = 1;
                $result = mysqli_query($link, $sql);
                while ($cat = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$cat['ways_id']}' >{$cat['ways_name']}</option>";
                }

                ?>
                <!-- 預定快取 -->
            </label>


            <input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off">
            <label class="btn btn-white" for="btnradio2" onclick="showDeliveryCard()">
                <img src="https://storage.googleapis.com/kfcoosfs/tab_btn_nontouch_r-210916.png" alt="Reservation Icon" style="width: 20px; height: 20px; margin-right: 8px;">
                <?php
                $sql = "SELECT * FROM ways WHERE ways_id = 2";
                $waysId = 2;
                $result = mysqli_query($link, $sql);
                while ($cat = mysqli_fetch_assoc($result)) {
                    echo "<option value='{$cat['ways_id']}' >{$cat['ways_name']}</option>";
                }
                ?>
            </label>
        </div>
        <div id="reservationCard" class="card">
            <div class="card-content">

                <p id="reservationDescription"></p>
                <!-- 額外的選項 -->
                <div id="locationSection">
                    <label for="location">地點依縣市尋找:</label>
                    <h6></h6>

                    <!-- echo "<select id ='locationSelect' name" -->

                    <!-- <form action="home_page.php" class="chooseways" method="POST"> -->
                    <select id="locationSelect" onchange="loadDistricts()">
                        <option value="">請選擇</option>
                        <!-- 這裡將動態生成地區選項 -->
                        <?php

                        $selectedCityId = isset($_GET['pickupcity_id']) ? $_GET['pickupcity_id'] : '';
                        $sql = "SELECT * FROM `pickupcity` ";
                        $result = mysqli_query($link, $sql);
                        while ($cat = mysqli_fetch_assoc($result)) {
                            $cityId = $cat['pickupcity_id'];
                            $waysId = $cat['ways_id'];
                            $selected = $cityId == $selectedCityId ? 'selected' : '';
                            echo "<option value='{$cityId}' {$selected}>{$cat['pickupcity_name']}</option>";
                        }
                        $result->free();


                        ?>
                        <!-- <form action="home_page.php" class="chooseways" method="POST">
                            <input type="hidden" name="ways_id" value="ways">
                        </form> -->

                    </select>
                    <!-- 添加 ways_id 的隱藏字段 -->
                    <!-- <input type="hidden" name="ways_id" value="your_ways_id_value"> -->

                    <!-- <input type="submit" name="submit" value="Submit"> -->

                    <!-- </form> -->

                    <select id="districtSelect" onchange="updateCityValue()">
                        <option value="">請選擇</option>
                        <?php

                        if (isset($_GET['pickupcity_id'])) {
                            $selectedAreaId = isset($_GET['pickuparea_id']) ? $_GET['pickuparea_id'] : '';
                            $val = mysqli_real_escape_string($link, $_GET['pickupcity_id']);
                            $sql = "SELECT * FROM  pickuparea  WHERE pickupcity_id = '$val'";
                            $result = mysqli_query($link, $sql);

                            while ($cat = mysqli_fetch_assoc($result)) {
                                $locationId = $cat['pickuparea_id'];
                                $selected_location = $locationId == $selectedAreaId ? 'selected' : '';  // 注意這裡的更改
                                echo "<option value='{$locationId}' {$selected_location}>{$cat['pickuparea_name']}</option>";
                            }
                        }
                        ?>
                        <!-- <option value="$selectedCityId"> $selectedCityId</option> -->
                    </select>
                </div>
                <h1></h1>

                <div id="Lct_TakeOutShop_Toggle" class="flip_tab1_store2">
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                            選擇餐廳
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                            <?php
                            $selectedRestatant = isset($_GET['pickuparea_id']) ? $_GET['pickuparea_id'] : '';

                            // Initialize $branchId before the loop
                            $branchId = '';
                            if (isset($_GET['pickuparea_id'])) {
                                $val = mysqli_real_escape_string($link, $_GET['pickuparea_id']);
                                $sql = "SELECT * FROM branch WHERE pickuparea_id = '$val'";
                                $result = mysqli_query($link, $sql);

                                while ($cat = mysqli_fetch_assoc($result)) {
                                    $restaurantId = $cat['branch_id'];
                                    $branchId = $cat['branch_id'];
                                    $restaurantName = $cat['branch_name'];
                                    $restaurantTime = $cat['branch_time'];
                                    $restaurantNote = $cat['branch_note'];
                                    $restaurantAddress = $cat['branch_address'];
                                    $selected_restaurant = $restaurantId == $selectedRestatant ? 'selected_restaurant' : '';
                                    echo "<li><a class='dropdown-item {$selected_restaurant}' href='#' onclick=\"updateButtonText('{$cat['branch_name']}')\">
                                    <h1>{$cat['branch_name']}</h1>
                                    {$cat['branch_address']}
                                    {$cat['branch_time']}
                                    </a></li>";
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </div>

                <h1></h1>

            </div>

            <div id="dateSection">
                <!-- 時間的小字 -->
                <p class="flip_tab1_date" onclick="showDatePicker()">
                    取餐日期:
                    <input type="text" id="Lct_SelectDeliveryDateType2" placeholder="2023/12/15(五)" onfocus="this.blur();">
                </p>

                <!-- 選擇日期時間 -->
                <div class="times">
                    <div>
                        <select id="Lct_sltDeliveryHourType2">
                            <option>07</option>
                            <option>08</option>
                            <option>09</option>
                            <option>10</option>
                            <option>11</option>
                            <option>12</option>
                            <option>13</option>
                            <option>14</option>
                            <option>15</option>
                            <option>16</option>
                            <option>17</option>
                            <option>18</option>
                            <option>19</option>
                            <option>20</option>
                            <option>21</option>
                            <option>22</option>
                            <option>23</option>
                        </select>
                    </div>
                    <p>:</p>
                    <div>
                        <select id="Lct_sltDeliveryMinuteType2">

                            <option>00</option>
                            <option>10</option>
                            <option>20</option>
                            <option>30</option>
                            <option>40</option>
                            <option>50</option>

                        </select>
                    </div>
                </div>
                <h1></h1>
                <div class="panel panel_tab1_date">
                    <div class="date" id="Lct_divDeliveryDateType2" orglen="14">
                        <div class="days_1">
                            <div class="day-container">
                                <div class="day-of-week">日</div>
                                <button></button>
                                <button name="Lct_DateT2" t="3" d="2023/12/17" tt="1" onclick="L_DateClick(this)">17</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/24" tt="1" onclick="L_DateClick(this)">24</button>

                            </div>
                            <div class="day-container">
                                <div class="day-of-week">一</div>
                                <button></button>
                                <button name="Lct_DateT2" t="3" d="2023/12/18" tt="1" onclick="L_DateClick(this)">18</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/25" tt="1" onclick="L_DateClick(this)">25</button>
                            </div>
                            <div class="day-container">
                                <div class="day-of-week">二</div>
                                <button></button>
                                <button name="Lct_DateT2" t="3" d="2023/12/19" tt="1" onclick="L_DateClick(this)">19</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/26" tt="1" onclick="L_DateClick(this)">26</button>
                            </div>
                            <div class="day-container">
                                <div class="day-of-week">三</div>
                                <button></button>
                                <button name="Lct_DateT2" t="3" d="2023/12/20" tt="1" onclick="L_DateClick(this)">20</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/27" tt="1" onclick="L_DateClick(this)">27</button>
                            </div>
                            <div class="day-container">
                                <div class="day-of-week">四</div>
                                <button name="Lct_DateT2" t="3" d="2023/12/14" tt="1" onclick="L_DateClick(this)">14</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/21" tt="1" onclick="L_DateClick(this)">21</button>
                                <button></button>
                            </div>
                            <div class="day-container">
                                <div class="day-of-week">五</div>
                                <button name="Lct_DateT2" t="3" d="2023/12/15" tt="1" onclick="L_DateClick(this)">15</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/22" tt="1" onclick="L_DateClick(this)">22</button>
                                <button></button>
                            </div>
                            <div class="day-container">
                                <div class="day-of-week">六</div>
                                <button name="Lct_DateT2" t="3" d="2023/12/16" tt="1" onclick="L_DateClick(this)">16</button>
                                <button name="Lct_DateT2" t="3" d="2023/12/23" tt="1" onclick="L_DateClick(this)">23</button>
                                <button></button>
                            </div>
                            <!-- 其他日期按鈕的部分省略 -->
                        </div>
                        <div class="days_1">
                            <!-- 其他日期按鈕的部分省略 -->
                        </div>
                    </div>
                </div>
                <!-- 其他元素的部分省略 -->
            </div>
            <h1></h1>
            <h1></h1>
            <h2></h2>

        </div>

    </div>

    <!-- 其他相關內容和表單等 -->
    </div>
    </div>

    <!-- <div id="deliveryCard" class="card">
        <h1></h1>
        <div></div>
        <div class="deliveryaddress">

            <input type="text" name="delivery_address" class="form-control" placeholder="請輸入包含市區的完整外送地址" aria-label="Username" aria-describedby="basic-addon1">
        </div>

    </div> -->
    <form action="home_page.php" class="home_page_finish" method="POST">
        <div id="goto_order" class="finish_goto_order">
            <!-- <input type="hidden" id="ways_id" name="ways_id" value=" -->
            <?php
            // echo $waysId; 
            ?>
            <!-- "> -->
            <input type="hidden" id="ways_id" name="ways_id" value="">
            <?php
            // echo "waysId: $waysId";
            ?>
            <div id="deliveryCard" class="card">
                <h1></h1>
                <div></div>
                <div class="deliveryaddress">

                    <input type="text" name="delivery_address" class="form-control" placeholder="請輸入包含市區的完整外送地址" aria-label="Username" aria-describedby="basic-addon1">
                </div>


            </div>
            <input type="hidden" name="branch_id" value="<?php echo $branchId; ?>">
            <input type="hidden" name="selectedDate" id="selectedDate" value="">
            <input type="hidden" name="selectedTime" id="selectedTime" value="">
            <input type="submit" value="前往訂餐" class="bbb">

    </form>

    </div>

    <h2 style="font-size: 1.3em;" id="menu_1">個人餐</h2>

    <div class="meals">
        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL%e9%a4%9020220518.jpg" alt="XL 超豪肯! 餐">
                </div>
                <p class="meal_ped_name">XL 超豪肯! 餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-L%e9%a4%90-%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a120221214.jpg" alt="L 絕配餐">
                </div>
                <p class="meal_ped_name">L 絕配餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1%e9%a4%9020220518.jpg" alt="M經典餐">
                </div>
                <p class="meal_ped_name">M 經典餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e8%8a%b1%e7%94%9f%e8%b5%b7%e5%8f%b8%e9%9b%9e%e6%9f%b3%e6%8d%b2%e9%9b%9e%e5%8b%b5%e9%a4%9020221215.jpg" alt="S 雞勵餐">
                </div>
                <p class="meal_ped_name">S 雞勵餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/menu-%e4%b8%8a%e6%a0%a1%e7%a7%81%e5%bb%9a%e6%b2%99%e6%8b%89-22215.jpg" alt="上校私廚沙拉">
                </div>
                <p class="meal_ped_name">上校私廚沙拉</p>
            </a>
        </div>


    </div>

    <h2 style="font-size: 1.3em;" id="menu_1">多人餐</h2>
    <div class="meals">
        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="many.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/2-4%e4%ba%bamenu-%e5%ae%85%e5%ae%85%e5%bf%ab%e6%a8%82%e9%a4%90-220215.jpg" alt="2-4人歡樂聚">
                </div>
                <p class="meal_ped_name">2-4人歡樂聚</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="individual.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e6%ad%a1%e8%81%9aB%e9%a4%90-10%e5%a1%8a%e9%9b%9e20221215.jpg" alt="5-7人歡樂聚">
                </div>
                <p class="meal_ped_name">5-7人歡樂聚</p>
            </a>
        </div>
    </div>

    <h2 style="font-size: 1.3em;" id="menu_1">早餐</h2>
    <div class="meals">
        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="breakfast.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/menu-%e8%8a%b1%e7%94%9f%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a1-%e5%a5%97%e9%a4%90202211171.jpg" alt="早餐">
                </div>
                <p class="meal_ped_name">早餐套餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="breakfast.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/%e7%b8%bd%e5%8c%af%e6%ad%90%e5%a7%86%e8%9b%8b%e7%87%92%e9%a4%85-220215.jpg" alt="早餐單點">
                </div>
                <p class="meal_ped_name">早餐單點</p>
            </a>
        </div>
    </div>

    <h2 style="font-size: 1.3em;" id="menu_1">單點</h2>
    <div class="meals">
        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="single.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/OOS%e7%94%a2%e5%93%81%e5%9c%96_%e9%9b%9e%e8%83%b8220215.jpg" alt="單點主餐">
                </div>
                <p class="meal_ped_name">單點主餐</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="single.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/%e5%8e%9f%e5%91%b3%e8%9b%8b%e6%92%bb%e7%a6%ae%e7%9b%92-220215.jpg" alt="蛋撻">
                </div>
                <p class="meal_ped_name">蛋撻</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="single.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/%e9%99%84%e9%a4%90%e9%bb%9e%e5%bf%83Menu-%e7%b6%93%e5%85%b8%e6%8b%bc%e7%9b%a4-220215.jpg" alt="附餐/點心">
                </div>
                <p class="meal_ped_name">附餐/點心</p>
            </a>
        </div>

        <div class="meal_prd" gavp="y" gavp_id="8" gavp_name="XL 超豪肯! 餐" gavp_pid="1" gavp_pname="個人餐">
            <a href="single.php">
                <div class="prdimg">
                    <img class="index lazy" src="https://kfcoosfs.kfcclub.com.tw/Menu-%e9%a3%b2%e6%96%99-%e7%99%be%e4%ba%8b%e5%8f%af%e6%a8%82(%e4%b8%ad)-220215.jpg" alt="飲料/湯品">
                </div>
                <p class="meal_ped_name">飲料/湯品</p>
            </a>
        </div>
    </div>








    <script src="home_page.js"></script>
</body>

</html>