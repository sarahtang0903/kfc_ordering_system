function back() {

}


// document.getElementById('mealForm').addEventListener('submit', function () {
//     // 获取 divMealListText 的内容
//     var mealListContent = document.getElementById('divMealListText').innerText.trim();

//     // 将内容设置到隐藏的输入框中
//     document.getElementById('mealListInput').value = mealListContent;
// });

// document.getElementById('mealForm').addEventListener('submit', function () {
//     // 获取 divMealListText 的内容
//     // var mealListElements = document.getElementById('divMealListText').getElementsByTagName('p');
//     var mealListElements = document.getElementById('divMealListText').innerText.trim();

//     console.log("讀取text:", mealListElements);


//     var mealListData = [];
//     var mealTotalPrice = document.getElementById('MealTotalPrice').innerText.trim();

//     // 循环遍历每一项
//     for (var i = 0; i < mealListElements.length; i++) {
//         var mealText = mealListElements[i].innerText.trim();
//         if (mealText !== '') {
//             mealListData.push(mealText);
//         }
//     }

//     // 将数据设置到隐藏的输入框中
//     document.getElementById('mealListInput').value = JSON.stringify(mealListData);
//     document.getElementById('mealTotalPriceInput').value = mealTotalPrice;
// });


document.getElementById('mealForm').addEventListener('submit', function () {
    // 获取 divMealListText 的内容
    var mealListElements = document.getElementById('divMealListText').getElementsByTagName('p');
    var mealListData = [];
    var mealTotalPrice = document.getElementById('MealTotalPrice').innerText.trim();

    var totalnum = document.getElementById('txtQuantity').innerText.trim();


    // 循环遍历每一项
    for (var i = 0; i < mealListElements.length; i++) {
        mealListData.push(mealListElements[i].innerText.trim());
    }

    // 将数据设置到隐藏的输入框中
    document.getElementById('mealListInput').value = JSON.stringify(mealListData);
    document.getElementById('mealTotalPriceInput').value = mealTotalPrice;
    document.getElementById('txtQuantity').value = totalnum;
});


// document.getElementById('mealForm').addEventListener('submit', function () {
//     // 获取 divMealListText 的内容
//     var mealListText = document.getElementById('divMealListText').textContent.trim();

//     // 将文本格式化为包含 <p> 标签的 HTML
//     var formattedHTML = mealListText.split('\n').map(function (item) {
//         if (item.trim() !== '') {
//             return '<p>' + item.trim() + '</p>';
//         }
//         return '';
//     }).join('');

//     // 創建一個虛擬元素來解析 HTML
//     var div = document.createElement('div');
//     div.innerHTML = formattedHTML;

//     var mealListElements = div.getElementsByTagName('p');
//     var mealListData = [];
//     var mealTotalPrice = document.getElementById('MealTotalPrice').innerText.trim();

//     // 循环遍历每一项
//     for (var i = 0; i < mealListElements.length; i++) {
//         var mealText = mealListElements[i].innerText.trim();
//         if (mealText !== '') {
//             mealListData.push(mealText);
//         }
//     }



//     // 将数据设置到隐藏的输入框中
//     document.getElementById('mealListInput').value = JSON.stringify(mealListData);
//     document.getElementById('mealTotalPriceInput').value = mealTotalPrice;
// });

// document.getElementById('mealForm').addEventListener('submit', function () {
//     // 获取 divMealListText 的内容
//     var mealListElements = document.getElementById('divMealListText').innerText.trim();
//     var mealListData = [];
//     var mealTotalPrice = document.getElementById('MealTotalPrice').innerText.trim();

//     // 循环遍历每一项
//     for (var i = 0; i < mealListElements.length; i++) {
//         var mealText = mealListElements[i].innerText.trim();
//         if (mealText !== '') {
//             mealListData.push(mealText);
//         }
//     }

//     // 将数据设置到隐藏的输入框中
//     document.getElementById('mealListInput').value = JSON.stringify(mealListData);
//     document.getElementById('mealTotalPriceInput').value = mealTotalPrice;
// });





// 在頁面載入時檢查是否有 cartetype_id 參數
window.onload = function () {
    var carttypeId = getUrlParameter('cartetype_id');
    if (carttypeId) {
        showReplacementDialog();
    }
};

// 獲取 URL 參數的值
function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    var results = regex.exec(location.search);
    return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
}


var test_combo_num;
function incrementQuantity() {
    var quantityInput = document.getElementById('txtQuantity');
    var currentQuantity = parseInt(quantityInput.value);
    var newQuantity = currentQuantity + 1;
    quantityInput.value = newQuantity;

    test_combo_num = quantityInput.value;
    console.log("quantity_add:", test_combo_num);

    // updateTotalPrice(newQuantity);
    // updateItemsList(newQuantity);
    // updateReplacementQuantity(newQuantity);
    updateTotalPrice(test_combo_num);
    updateItemsList(test_combo_num);
    //updateReplacementQuantity(test_combo_num);
    updateReplacementQuantity_num(test_combo_num);

}

function decrementQuantity() {
    var quantityInput = document.getElementById('txtQuantity');
    var currentQuantity = parseInt(quantityInput.value);
    var newQuantity = currentQuantity > 1 ? currentQuantity - 1 : 1;
    quantityInput.value = newQuantity;

    test_combo_num = quantityInput.value;
    console.log("quantity_minus:", test_combo_num);

    // updateTotalPrice(newQuantity);
    updateTotalPrice(test_combo_num);
    updateItemsList(test_combo_num);
    //updateReplacementQuantity(test_combo_num);
    updateReplacementQuantity_num(test_combo_num);
}

function updateReplacementQuantity_num(test_combo_num) {
    var replacementQuantityElement = document.getElementById('replacementQuantity');
    replacementQuantityElement.innerText = '共可選項 ' + test_combo_num + ' 項';
}

function updateReplacementQuantity(quantity) {
    // var replacementQuantityElement = document.getElementById('replacementQuantity');
    // console.log(("update:"), replacementQuantityElement);
    // replacementQuantityElement.innerText.replace(/x \d+$/, "x " + quantity);

    // replacementQuantityElement.innerText = '共可選' + quantity + '項';


    var mainDescriptionElement = document.getElementById('replacementQuantity');
    console.log("replacementQuantity:", mainDescriptionElement);
    if (mainDescriptionElement) {
        // 確保找到了元素再進行更新
        var meal_left = mainDescriptionElement.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', quantity);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + quantity);
        console.log('newnrw meal for element:', meal_check);
        mainDescriptionElement.textContent = meal_check;

        console.log("newnewnew:", quantity);
        // }
    } else {
        console.error('Element with id "newnewreplacementQuantity" not found.');
    }
    // // var chicken = document.getElementById('')
    // // // var replacementQuantityElement_
}

function updateTotalPrice(quantity) {
    var unitPrice = document.getElementById('MealTotalPriceNoDiscount_none').innerText; // 每份餐點價格
    console.log("uniyPrice:", unitPrice);
    test = quantity;
    console.log('updatequan:', test);
    // var total = unitPrice * quantity;
    var total = unitPrice * test;
    console.log("total:", total);

    document.getElementById('MealTotalPrice').innerText = total;
    document.getElementById('MealTotalPriceNoDiscount').innerText = total;
    updateReplacementQuantity(quantity);
}

// function updateItemsList(quantity) {
//     var items = ["雙層咔啦雞腿堡", "香酥脆薯(中)", "百事可樂(中)"]; // 你的餐點清單
//     var itemList = document.getElementById('divMealListText');
//     itemList.innerHTML = ""; // 清空当前列表

//     for (var i = 0; i < items.length; i++) {
//         var item = items[i] + " x " + quantity;
//         var listItem = document.createElement('p');
//         listItem.textContent = item;
//         itemList.appendChild(listItem);
//     }

//     // 更新左侧卡片的内容
//     // var cardTitles = document.querySelectorAll('.card-title');
//     var cardTexts = document.querySelectorAll('.card-text');
//     console.log("card-text", cardTexts);

//     for (var i = 0; i < cardTexts.length; i++) {
//         // cardTitles[i].textContent = items[i] + " x " + quantity;
//         cardTexts[i].textContent = items[i] + "x" + quantity;
//     }
// }

// function updateItemsList(quantity) {
//     var itemList = document.getElementById('divMealListText');


//     // 获取 divMealListText 元素中的文本内容
//     var mealsText = itemList.innerText;

//     // 使用换行符分割字符串为数组
//     var mealsArray = mealsText.split('\n');

//     itemList.innerHTML = ""; // 清空当前列表

//     // 遍历数组创建新的列表项
//     for (var i = 0; i < mealsArray.length; i++) {
//         var meal = mealsArray[i].trim(); // 去除两端的空格
//         if (meal !== '') {
//             var item = meal + " x " + quantity;
//             var listItem = document.createElement('p');
//             listItem.textContent = item;
//             itemList.appendChild(listItem);
//         }
//     }

//     // 更新左侧卡片的内容
//     var cardTexts = document.querySelectorAll('.card-text');
//     console.log("card-text", cardTexts);

//     for (var i = 0; i < cardTexts.length; i++) {
//         cardTexts[i].textContent = mealsArray[i].trim() + " x " + quantity;
//     }
// }

function updateItemsList(quantity) {


    //原本
    var itemList = document.getElementById('divMealListText');
    var mealsText = itemList.textContent; // 获取 div 的文本内容

    itemList.innerHTML = "";

    // 使用正则表达式匹配商品名称
    var itemRegex = /([\s\S]+?) x \d+/g;
    var itemsArray = [];
    var match;

    // itemList.innerHTML = "";

    while ((match = itemRegex.exec(mealsText)) !== null) {
        var itemName = match[1].trim(); // 匹配到的商品名称
        itemsArray.push(itemName);
    }

    // 现在 itemsArray 中包含了每一项的商品名称
    console.log(itemsArray);

    itemList.innerHTML = "";

    // 遍历数组创建新的列表项
    for (var i = 0; i < itemsArray.length; i++) {
        var itemName = itemsArray[i];
        var listItem = document.createElement('p');
        listItem.textContent = itemName + ' x ' + quantity;
        // document.getElementById('divMealListText').listItem.innerHTML = '<p>' + itemName + ' x ' + quantity + '</p>';
        // listItem.textContent = '<p>' + itemName + ' x ' + quantity + '</p>';

        itemList.appendChild(listItem);
    }

    document.getElementById('divMealListText').innerHTML = itemList.innerHTML;

    // 创建包含 <p> 的字符串
    // var innerHTMLString = '';
    // for (var i = 0; i < itemsArray.length; i++) {
    //     var itemName = itemsArray[i];
    //     innerHTMLString += '<p>' + itemName + ' x ' + quantity + '</p>';
    // }

    // console.log("innerHTML:", innerHTMLString);

    // // 将字符串设置为 div 的 innerHTML
    // itemList.innerHTML = innerHTMLString;

    // var spanWrapper = document.createElement('span');
    // for (var i = 0; i < itemsArray.length; i++) {
    //     var itemName = itemsArray[i];
    //     var spanItem = document.createElement('span');
    //     spanItem.innerHTML = itemName + ' x ' + quantity + '<br>'; // 每个商品名称之后添加换行符
    //     spanWrapper.appendChild(spanItem);
    // }

    var newList = document.getElementById('divMealListText');
    console.log("newitemList:", newList);








    // var itemList = document.getElementById('divMealListText');

    // // 获取 divMealListText 元素中的文本内容
    // var mealsText = itemList.innerText;

    // // 使用换行符分割字符串为数组
    // var mealsArray = mealsText.split('\n');
    // var test = quantity;
    // console.log(test);
    // // 清空当前列表
    // itemList.innerHTML = "";


    // // 遍历数组创建新的列表项
    // for (var i = 0; i < mealsArray.length; i++) {
    //     var meal = mealsArray[i].trim(); // 去除两端的空格
    //     if (meal !== '') {
    //         // 使用正则表达式替换 x1 为新的数量
    //         console.log('Before replacement:', meal); // 添加调试语句

    //         meal = meal.replace(/x \d+$/, "x " + quantity);

    //         console.log('After replacement:', meal); // 添加调试语句

    //         var listItem = document.createElement('p');
    //         listItem.textContent = meal;
    //         itemList.appendChild(listItem);
    //     }
    // }

    // // 更新左侧卡片的内容

    var mainDescriptionElement = document.getElementById('card-text-left');
    if (mainDescriptionElement) {
        // 確保找到了元素再進行更新
        var meal_left = mainDescriptionElement.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', test);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + test);
        console.log('Updated meal for element:', meal_check);
        mainDescriptionElement.textContent = meal_check;
        // }
    } else {
        console.error('Element with id "chickenDescription" not found.');
    }


    var chickenDescriptionElement = document.getElementById('chickenDescription');
    if (chickenDescriptionElement) {
        // 確保找到了元素再進行更新
        var meal_left = chickenDescriptionElement.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', test);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + test);
        console.log('Updated meal for element:', meal_check);
        chickenDescriptionElement.textContent = meal_check;
        // }
    } else {
        console.error('Element with id "chickenDescription" not found.');
    }

    var eggDescriptionElement = document.getElementById('eggDescription');
    if (eggDescriptionElement) {
        // 確保找到了元素再進行更新
        var meal_left = eggDescriptionElement.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', test);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + test);
        console.log('Updated meal for element:', meal_check);
        eggDescriptionElement.textContent = meal_check;
        // }
    } else {
        console.error('Element with id "chickenDescription" not found.');
    }

    var drinkDescription = document.getElementById('drinkDescription');
    if (drinkDescription) {
        // 確保找到了元素再進行更新
        var meal_left = drinkDescription.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', test);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + test);
        console.log('Updated meal for element:', meal_check);
        drinkDescription.textContent = meal_check;
        // }
    } else {
        console.error('Element with id "chickenDescription" not found.');
    }

    var feenchDescription = document.getElementById('frenchDescription');
    if (feenchDescription) {
        // 確保找到了元素再進行更新
        var meal_left = feenchDescription.textContent.trim();
        console.log('before update:', meal_left);
        console.log('left_quan:', test);
        // if (meal.includes('x ')) {
        meal_check = meal_left.replace(/x \d+$/, "x " + test);
        console.log('Updated meal for element:', meal_check);
        feenchDescription.textContent = meal_check;
        // }
    } else {
        console.error('Element with id "chickenDescription" not found.');
    }





    // var cardTexts = document.querySelectorAll('.card-text');
    // console.log("card-text", cardTexts);

    // for (var i = 0; i < cardTexts.length; i++) {
    //     // cardTexts[i].textContent = mealsArray[i].trim() + " x " + quantity;
    //     cardTexts[i].textContent = mealsArray[i] + " x " + quantity;
    // }

    // 更新左侧卡片的内容
    // var cardTexts = document.querySelectorAll('.update-me p');


    // console.log("card-text", cardTexts);

    // // for (var i = 0; i < cardTexts.length; i++) {
    // //     // var meal = mealsArray[i].trim(); // 去除两端的空格
    // //     var meal = mealsArray[i]; // 去除两端的空格
    // //     console.log('before update:', meal)
    // //     if (meal !== '') {
    // //         // 使用正则表达式替换 x1 为新的数量
    // //         meal = meal.replace(/x \d+$/, "x " + quantity);

    // //         console.log('Updated meal for card:', meal); // 添加调试语句

    // //         // 更新卡片的文本内容
    // //         cardTexts[i].textContent = meal;
    // //     }
    // // }

    // for (var i = 0; i < cardTexts.length; i++) {
    //     var meal = mealsArray[i] || ''; // 获取卡片内容，如果值为 undefined 则设置为空字符串
    //     console.log('before update:', meal);

    //     // 使用正则表达式检查 meal 是否包含 'x '
    //     if (meal && meal.includes('x ')) {
    //         // 使用正则表达式替换 x 为新的数量
    //         meal = meal.replace(/x \d+$/, "x " + quantity);

    //         console.log('Updated meal for card:', meal);

    //         // 更新卡片的文本内容
    //         cardTexts[i].textContent = meal;
    //     }
    // }

}



function showReplacementOptions(category) {
    var drinksOptions = document.getElementById('drinksOptions');
    var mealsOptions = document.getElementById('mealsOptions');

    if (category === 'drinks') {
        drinksOptions.style.display = 'block';
        mealsOptions.style.display = 'none';
    } else if (category == 'french') {
        drinksOptions.style.display = 'none';
        mealsOptions.style.display = 'block';
    }
}

//蛋塔

//
function updateQuantity_Egg(MMF_DataType, item, quantityId, limitId) {
    var quantityInput = document.getElementById(quantityId);
    var replacementQuantity = document.getElementById(limitId).innerText;
    // var currentQuantity = parseInt(quantityInput.value);
    var replacementLimit = parseInt(replacementQuantity.match(/\d+/)[0]); // 取得數字部分

    var minQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var muxQuantity = parseInt(document.getElementById('txtQuantity_2').value);

    var newminQuantity = minQuantity;
    var newmuxQuantity = muxQuantity;

    if (item === '4') {
        if (MMF_DataType === 'Add') {
            newminQuantity = minQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newminQuantity = minQuantity - 1;
        }
        newminQuantity = Math.min(Math.max(newminQuantity, 0), replacementLimit - newmuxQuantity);
    } else if (item === '5') {
        if (MMF_DataType === 'Add') {
            newmuxQuantity = muxQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newmuxQuantity = muxQuantity - 1;
        }
        newmuxQuantity = Math.min(Math.max(newmuxQuantity, 0), replacementLimit - newminQuantity);
    }

    quantityInput.value = item === '4' ? newminQuantity : newmuxQuantity;
    document.getElementById('txtQuantity_1').value = newminQuantity;
    document.getElementById('txtQuantity_2').value = newmuxQuantity;
    // updateLeftCard(item, newPepsiQuantity, newSevenUpQuantity);
}

function updateLeftCard_Egg(minQuantity, newmuxQuantity) {
    var cardText = document.getElementById('eggDescription');
    console.log(cardText);
    // var cardImage = document.querySelector('.img-fluid');

    // 更新飲料卡片描述
    var description = '';

    if (minQuantity > 0) {
        description += '原味蛋塔 x ' + minQuantity + '\n';
    }

    if (newmuxQuantity > 0) {
        description += '調皮搗蛋蛋塔 x ' + newmuxQuantity + '\n';
    }

    cardText = description; // 移除描述的最後一個換行符號


    // 隱藏對話框，顯示餐點區域
    var dialog = document.getElementById('replacementDialog_egg');
    dialog.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}

function showReplacementDialog_egg(cartetypeId) {


    var dialog = document.getElementById('replacementDialog_egg');
    dialog.style.display = 'block';

    // 隱藏原本的餐點區域
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'none';
}

function confirmReplacement_egg() {
    // 获取选中的饮料信息和数量
    var minQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var muxQuantity = parseInt(document.getElementById('txtQuantity_2').value);

    console.log(minQuantity, muxQuantity);

    // updateLeftCard('百事可樂', pepsiQuantity);
    // updateLeftCard('七喜', sevenUpQuantity);
    updateLeftCard_Egg(minQuantity, muxQuantity);
    updateRightDescription_egg(minQuantity, muxQuantity);
    cancelReplacement_egg();
}

function cancelReplacement_egg() {
    // 隱藏對話框
    var dialog_french = document.getElementById('replacementDialog_egg');
    dialog_french.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}

function updateRightDescription_egg(minQuantity, muxQuantity) {
    // 获取右侧文字描述的元素
    var rightDescription = document.getElementById('divMealListText');

    // 获取原始的右侧文字描述
    var originalDescription = rightDescription.innerHTML;

    // 定義正則表達式以匹配原始描述中的百事可樂和七喜內容
    var minRegex = /原味蛋撻 x \d+/;
    var muxRegex = /調皮搗蛋蛋撻 x \d+/;


    // 取得原始描述中的百事可樂和七喜內容
    var originalMinContent = originalDescription.match(minRegex);
    var originalMuxContent = originalDescription.match(muxRegex);

    // 替換內容，如果數量大於0，否則保留空字串
    var replacedMinContent = minQuantity > 0 ? '原味蛋撻 x ' + minQuantity : '';
    var replacedMuxContent = muxQuantity > 0 ? '調皮搗蛋蛋撻 x ' + muxQuantity : '';


    // 更新右侧文字描述
    var replacedDescription = originalDescription
        .replace(minRegex, replacedMinContent)
        .replace(muxRegex, replacedMuxContent)
        ;


    // 如果原始描述中沒有相應的內容，則追加新的內容
    if (!originalMinContent) {
        replacedDescription += replacedMinContent;
    }
    if (!originalMuxContent) {
        replacedDescription += replacedMuxContent;
    }


    // 清空原有內容
    rightDescription.innerHTML = '';

    // 將更新的描述添加到右侧文字描述
    rightDescription.innerHTML = replacedDescription;
}




//原本

function updateQuantity_French(MMF_DataType, item, quantityId, limitId) {
    var quantityInput = document.getElementById(quantityId);
    var replacementQuantity = document.getElementById(limitId).innerText;
    // var currentQuantity = parseInt(quantityInput.value);
    var replacementLimit = parseInt(replacementQuantity.match(/\d+/)[0]); // 取得數字部分

    var minQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var muxQuantity = parseInt(document.getElementById('txtQuantity_2').value);

    var newminQuantity = minQuantity;
    var newmuxQuantity = muxQuantity;

    if (item === '19') {
        if (MMF_DataType === 'Add') {
            newminQuantity = minQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newminQuantity = minQuantity - 1;
        }
        newminQuantity = Math.min(Math.max(newminQuantity, 0), replacementLimit - newmuxQuantity);
    } else if (item === '20') {
        if (MMF_DataType === 'Add') {
            newmuxQuantity = muxQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newmuxQuantity = muxQuantity - 1;
        }
        newmuxQuantity = Math.min(Math.max(newmuxQuantity, 0), replacementLimit - newminQuantity);
    }

    quantityInput.value = item === '19' ? newminQuantity : newmuxQuantity;
    document.getElementById('txtQuantity_1').value = newminQuantity;
    document.getElementById('txtQuantity_2').value = newmuxQuantity;
    // updateLeftCard(item, newPepsiQuantity, newSevenUpQuantity);
}

function updateLeftCard_french(minQuantity, newmuxQuantity) {
    var cardText = document.getElementById('frenchDescription');
    console.log(cardText);
    // var cardImage = document.querySelector('.img-fluid');

    // 更新飲料卡片描述
    var description = '';

    if (minQuantity > 0) {
        description += '香酥脆薯(中) x ' + minQuantity + '\n';
    }

    if (newmuxQuantity > 0) {
        description += '香酥脆薯(大) x ' + newmuxQuantity + '\n';
    }

    cardText = description; // 移除描述的最後一個換行符號


    // 隱藏對話框，顯示餐點區域
    var dialog = document.getElementById('replacement_french_Dialog');
    dialog.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}

function showReplacementDialog_french(cartetypeId) {


    var dialog = document.getElementById('replacement_french_Dialog');
    dialog.style.display = 'block';

    // 隱藏原本的餐點區域
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'none';
}

function confirmReplacement_french() {
    // 获取选中的饮料信息和数量
    var minQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var muxQuantity = parseInt(document.getElementById('txtQuantity_2').value);

    console.log(minQuantity, muxQuantity);

    // updateLeftCard('百事可樂', pepsiQuantity);
    // updateLeftCard('七喜', sevenUpQuantity);
    updateLeftCard_french(minQuantity, muxQuantity);
    updateRightDescription_french(minQuantity, muxQuantity);
    cancelReplacement_french();
}

function cancelReplacement_french() {
    // 隱藏對話框
    var dialog_french = document.getElementById('replacement_french_Dialog');
    dialog_french.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}

function updateRightDescription_french(minQuantity, muxQuantity) {
    // 获取右侧文字描述的元素
    var rightDescription = document.getElementById('divMealListText');

    // 获取原始的右侧文字描述
    var originalDescription = rightDescription.innerHTML;

    // 定義正則表達式以匹配原始描述中的百事可樂和七喜內容
    var minRegex = /香酥脆薯\(中\) x \d+/;
    var muxRegex = /香酥脆薯\(大\) x \d+/;


    // 取得原始描述中的百事可樂和七喜內容
    var originalMinContent = originalDescription.match(minRegex);
    var originalMuxContent = originalDescription.match(muxRegex);

    // 替換內容，如果數量大於0，否則保留空字串
    var replacedMinContent = minQuantity > 0 ? '香酥脆薯(中) x ' + minQuantity : '';
    var replacedMuxContent = muxQuantity > 0 ? '香酥脆薯(大) x ' + muxQuantity : '';


    // 更新右侧文字描述
    var replacedDescription = originalDescription
        .replace(minRegex, replacedMinContent)
        .replace(muxRegex, replacedMuxContent)
        ;


    // 如果原始描述中沒有相應的內容，則追加新的內容
    if (!originalMinContent) {
        replacedDescription += replacedMinContent;
    }
    if (!originalMuxContent) {
        replacedDescription += replacedMuxContent;
    }


    // 清空原有內容
    rightDescription.innerHTML = '';

    // 將更新的描述添加到右侧文字描述
    rightDescription.innerHTML = replacedDescription;
}






//炸機

function showReplacementDialog_chicken(cartetypeId) {
    // 使用 AJAX 请求更新页面内容
    // var xhr = new XMLHttpRequest();
    // xhr.open('GET', 'your_php_file.php?cartetype_id=' + cartetypeId, true);
    // xhr.onreadystatechange = function () {
    //     if (xhr.readyState == 4 && xhr.status == 200) {
    //         // 假设返回的是 HTML 内容
    //         document.getElementById('replacementDialog').innerHTML = xhr.responseText;
    //     }
    // };
    // xhr.send();

    var dialog = document.getElementById('replacementDialog_chicken');
    dialog.style.display = 'block';

    // 隱藏原本的餐點區域
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'none';
}


function updateQuantity_chicken(MMF_DataType, item, quantityId, limitId) {
    var quantityInput = document.getElementById(quantityId);
    console.log(quantityInput);
    var replacementQuantity = document.getElementById(limitId).innerText;
    console.log(replacementQuantity);
    // var currentQuantity = parseInt(quantityInput.value);
    var replacementLimit = parseInt(replacementQuantity.match(/\d+/)[0]); // 取得數字部分
    console.log(replacementLimit);

    var pepsiQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var sevenUpQuantity = parseInt(document.getElementById('txtQuantity_2').value);
    var lemonQuantity = parseInt(document.getElementById('txtQuantity_3').value);

    // var pepsiQuantity = 0;
    // var sevenUpQuantity = 0;
    // var lemonQuantity = 0;
    // var greenteaQuantity = 0;
    // var redteaQuantity = 0;


    var newPepsiQuantity = pepsiQuantity;
    var newSevenUpQuantity = sevenUpQuantity;
    var newlemonQuantity = lemonQuantity;

    if (item === '1') {
        if (MMF_DataType === 'Add') {
            newPepsiQuantity = pepsiQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newPepsiQuantity = pepsiQuantity - 1;
        }
        newPepsiQuantity = Math.min(Math.max(newPepsiQuantity, 0), (replacementLimit - newSevenUpQuantity - newlemonQuantity));
    } else if (item === '2') {
        if (MMF_DataType === 'Add') {
            newSevenUpQuantity = sevenUpQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newSevenUpQuantity = sevenUpQuantity - 1;
        }
        newSevenUpQuantity = Math.min(Math.max(newSevenUpQuantity, 0), (replacementLimit - newPepsiQuantity - newlemonQuantity));

    } else if (item === '3') {
        if (MMF_DataType === 'Add') {
            newlemonQuantity = lemonQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newlemonQuantity = lemonQuantity - 1;
        }
        newlemonQuantity = Math.min(Math.max(newlemonQuantity, 0), (replacementLimit - newPepsiQuantity - newSevenUpQuantity));
    }

    // quantityInput.value = item === '百事可樂' ? newPepsiQuantity : newSevenUpQuantity;
    // var totalQuantity = newPepsiQuantity + newSevenUpQuantity + newlemonQuantity + newgreenteaQuantity + newredteaQuantity;
    // quantityInput.value = Math.min(totalQuantity, replacementLimit);
    // quantityInput.value = newPepsiQuantity + newSevenUpQuantity + newlemonQuantity + newgreenteaQuantity + newredteaQuantity;
    // 在所有商品的处理分支结束后
    var finalQuantity = 0;
    if (item === '1') {
        finalQuantity == newPepsiQuantity;
    } else if (item === '2') {
        finalQuantity = newSevenUpQuantity;
    } else if (item === '3') {
        finalQuantity == newlemonQuantity;
    }

    // 设置最终数量
    quantityInput.value = finalQuantity;

    document.getElementById('txtQuantity_1').value = newPepsiQuantity;
    document.getElementById('txtQuantity_2').value = newSevenUpQuantity;
    document.getElementById('txtQuantity_3').value = newlemonQuantity;

    // document.getElementById('txtQuantity_1') = newPepsiQuantity;
    // document.getElementById('txtQuantity_2') = newSevenUpQuantity;
    // document.getElementById('txtQuantity_3') = newlemonQuantity;
    // document.getElementById('txtQuantity_4') = newgreenteaQuantity;
    // document.getElementById('txtQuantity_5') = newredteaQuantity;
    // updateLeftCard(item, newPepsiQuantity, newSevenUpQuantity, newlemonQuantity, newgreenteaQuantity, newredteaQuantity);
}

function updateLeftCard_chicken(pepsiQuantity, sevenUpQuantity, lemonQuantity) {
    var cardText = document.getElementById('chickenDescription');

    // 检查元素是否存在
    if (cardText) {
        // 更新飲料卡片描述
        var description = '';

        if (pepsiQuantity > 0) {
            description += '青花椒香麻脆雞(辣) x ' + pepsiQuantity + '\n';
        }

        if (sevenUpQuantity > 0) {
            description += '咔啦脆雞(辣) x ' + sevenUpQuantity + '\n';
        }

        if (lemonQuantity > 0) {
            description += '上校薄脆雞(不辣) x ' + lemonQuantity + '\n';
        }



        cardText.innerText = description.trim(); // 移除描述的最後一個換行符號

        // 隱藏對話框，顯示餐點區域
        var dialog = document.getElementById('replacementDialog_chicken');
        dialog.style.display = 'none';

        var mealInformation = document.querySelector('.combo-flow__imformation');
        mealInformation.style.display = 'block';
    } else {
        console.error('Element with id "drinkDescription" not found.');
    }
}

function confirmReplacement_chicken() {
    // 获取选中的饮料信息和数量
    var pepsiQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var sevenUpQuantity = parseInt(document.getElementById('txtQuantity_2').value);
    var lemonQuantity = parseInt(document.getElementById('txtQuantity_3').value);

    console.log(pepsiQuantity, sevenUpQuantity, lemonQuantity);

    // updateLeftCard('百事可樂', pepsiQuantity);
    // updateLeftCard('七喜', sevenUpQuantity);
    updateLeftCard_chicken(pepsiQuantity, sevenUpQuantity, lemonQuantity);
    updateRightDescription_chicken(pepsiQuantity, sevenUpQuantity, lemonQuantity);
    cancelReplacement_chicken();
}

function updateRightDescription_chicken(pepsiQuantity, sevenUpQuantity, lemonQuantity) {
    // 获取右侧文字描述的元素
    var rightDescription = document.getElementById('divMealListText');

    // 获取原始的右侧文字描述
    var originalDescription = rightDescription.innerHTML;

    // 定義正則表達式以匹配原始描述中的百事可樂和七喜內容
    var pepsiRegex = /青花椒香麻脆雞\(辣\) x \d+/;
    var sevenUpRegex = /咔啦脆雞\(辣\) x \d+/;
    var teaRegex = /上校薄脆雞\(不辣\) x \d+/;


    // 取得原始描述中的百事可樂和七喜內容
    var originalPepsiContent = originalDescription.match(pepsiRegex);
    var originalSevenUpContent = originalDescription.match(sevenUpRegex);
    var originalTeaContent = originalDescription.match(teaRegex);


    // 替換內容，如果數量大於0，否則保留空字串
    var replacedPepsiContent = pepsiQuantity > 0 ? '青花椒香麻脆雞(辣) x ' + pepsiQuantity : '';
    var replacedSevenUpContent = sevenUpQuantity > 0 ? '咔啦脆雞(辣) x ' + sevenUpQuantity : '';
    var replacedTeaContent = lemonQuantity > 0 ? '上校薄脆雞(不辣) x ' + lemonQuantity : '';


    // 更新右侧文字描述
    var replacedDescription = originalDescription
        .replace(pepsiRegex, replacedPepsiContent)
        .replace(sevenUpRegex, replacedSevenUpContent)
        .replace(teaRegex, replacedTeaContent)
        ;


    // 如果原始描述中沒有相應的內容，則追加新的內容
    if (!originalPepsiContent) {
        replacedDescription += replacedPepsiContent;
    }
    if (!originalSevenUpContent) {
        replacedDescription += replacedSevenUpContent;
    }
    if (!originalTeaContent) {
        replacedDescription += replacedTeaContent;
    }

    // 清空原有內容
    rightDescription.innerHTML = '';

    // 將更新的描述添加到右侧文字描述
    rightDescription.innerHTML = replacedDescription;
}


function cancelReplacement_chicken() {
    // 隱藏對話框
    var dialog = document.getElementById('replacementDialog_chicken');
    dialog.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}




//飲料

function updateQuantity(MMF_DataType, item, quantityId, limitId) {
    var quantityInput = document.getElementById(quantityId);
    console.log(quantityInput);
    var replacementQuantity = document.getElementById(limitId).innerText;
    console.log(replacementQuantity);
    // var currentQuantity = parseInt(quantityInput.value);
    var replacementLimit = parseInt(replacementQuantity.match(/\d+/)[0]); // 取得數字部分
    console.log(replacementLimit);

    var pepsiQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var sevenUpQuantity = parseInt(document.getElementById('txtQuantity_2').value);
    var lemonQuantity = parseInt(document.getElementById('txtQuantity_3').value);
    var greenteaQuantity = parseInt(document.getElementById('txtQuantity_4').value);
    var redteaQuantity = parseInt(document.getElementById('txtQuantity_5').value);

    // var pepsiQuantity = 0;
    // var sevenUpQuantity = 0;
    // var lemonQuantity = 0;
    // var greenteaQuantity = 0;
    // var redteaQuantity = 0;


    var newPepsiQuantity = pepsiQuantity;
    var newSevenUpQuantity = sevenUpQuantity;
    var newlemonQuantity = lemonQuantity;
    var newgreenteaQuantity = greenteaQuantity;
    var newredteaQuantity = redteaQuantity;

    if (item === '6') {
        if (MMF_DataType === 'Add') {
            newSevenUpQuantity = sevenUpQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newSevenUpQuantity = sevenUpQuantity - 1;
        }
        newSevenUpQuantity = Math.min(Math.max(newSevenUpQuantity, 0), (replacementLimit - newPepsiQuantity - newgreenteaQuantity - newlemonQuantity - newredteaQuantity));
         
    } else if (item === '7') {
        if (MMF_DataType === 'Add') {
            
            newPepsiQuantity = pepsiQuantity + 1;
        } else if (MMF_DataType === 'Del') {
             
            newPepsiQuantity = pepsiQuantity - 1;
        }
        newPepsiQuantity = Math.min(Math.max(newPepsiQuantity, 0), (replacementLimit - newSevenUpQuantity - newlemonQuantity - newredteaQuantity - newgreenteaQuantity));
         

    } else if (item === '8') {
        if (MMF_DataType === 'Add') {
            newlemonQuantity = lemonQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newlemonQuantity = lemonQuantity - 1;
        }
        newlemonQuantity = Math.min(Math.max(newlemonQuantity, 0), (replacementLimit - newPepsiQuantity - newSevenUpQuantity - newgreenteaQuantity - newredteaQuantity));
    } else if (item == '9') {
        if (MMF_DataType === 'Add') {
            newgreenteaQuantity = greenteaQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newgreenteaQuantity = greenteaQuantity - 1;
        }
        newgreenteaQuantity = Math.min(Math.max(newgreenteaQuantity, 0), (replacementLimit - newPepsiQuantity - newSevenUpQuantity - newlemonQuantity - newredteaQuantity));
    } else if (item == '10') {
        if (MMF_DataType === 'Add') {
            newredteaQuantity = redteaQuantity + 1;
        } else if (MMF_DataType === 'Del') {
            newredteaQuantity = redteaQuantity - 1;
        }
        newredteaQuantity = Math.min(Math.max(newredteaQuantity, 0), (replacementLimit - newPepsiQuantity - newSevenUpQuantity - newlemonQuantity - newgreenteaQuantity));
    }

    // quantityInput.value = item === '百事可樂' ? newPepsiQuantity : newSevenUpQuantity;
    // var totalQuantity = newPepsiQuantity + newSevenUpQuantity + newlemonQuantity + newgreenteaQuantity + newredteaQuantity;
    // quantityInput.value = Math.min(totalQuantity, replacementLimit);
    // quantityInput.value = newPepsiQuantity + newSevenUpQuantity + newlemonQuantity + newgreenteaQuantity + newredteaQuantity;
    // 在所有商品的处理分支结束后
    var finalQuantity = 0;
    if (item === '6') {
        finalQuantity = newSevenUpQuantity;
         
    } else if (item === '7') {
         
        finalQuantity == newPepsiQuantity;
    } else if (item === '8') {
        finalQuantity == newlemonQuantity;
    } else if (item == '9') {
        finalQuantity == newgreenteaQuantity;
    } else if (item == '10') {
        finalQuantity == newredteaQuantity;
    }

    // 设置最终数量
    quantityInput.value = finalQuantity;

    document.getElementById('txtQuantity_1').value = newPepsiQuantity;
    document.getElementById('txtQuantity_2').value = newSevenUpQuantity;
    document.getElementById('txtQuantity_3').value = newlemonQuantity;
    document.getElementById('txtQuantity_4').value = newgreenteaQuantity;
    document.getElementById('txtQuantity_5').value = newredteaQuantity;

    // document.getElementById('txtQuantity_1') = newPepsiQuantity;
    // document.getElementById('txtQuantity_2') = newSevenUpQuantity;
    // document.getElementById('txtQuantity_3') = newlemonQuantity;
    // document.getElementById('txtQuantity_4') = newgreenteaQuantity;
    // document.getElementById('txtQuantity_5') = newredteaQuantity;
    // updateLeftCard(item, newPepsiQuantity, newSevenUpQuantity, newlemonQuantity, newgreenteaQuantity, newredteaQuantity);
}

// function updateQuantity(MMF_DataType, item, quantityId, limitId, type) {
//     var quantityInput = document.getElementById(quantityId);
//     console.log(quantityInput);
//     var replacementQuantity = document.getElementById(limitId).innerText;
//     console.log(replacementQuantity);
//     var currentQuantity = parseInt(quantityInput.value);
//     var replacementLimit = parseInt(replacementQuantity.match(/\d+/)[0]); // 取得數字部分
//     console.log(replacementLimit);
//     var newQuantity = currentQuantity;
//     console.log(currentQuantity);

//     if (MMF_DataType === 'Add') {
//         newQuantity = currentQuantity + 1;
//     } else if (MMF_DataType === 'Del') {
//         newQuantity = currentQuantity - 1;
//     }

//     // 根据商品类型调整数量
//     newQuantity = Math.min(Math.max(newQuantity, 0), replacementLimit);

//     quantityInput.value = newQuantity;
// }

//原本

// function updateLeftCard(pepsiQuantity, sevenUpQuantity) {
//     var cardText = document.getElementById('drinkDescription');
//     // var cardImage = document.querySelector('.img-fluid');

//     // 更新飲料卡片描述
//     var description = '';

//     if (pepsiQuantity > 0) {
//         description += '百事可樂 x ' + pepsiQuantity + '\n';
//     }

//     if (sevenUpQuantity > 0) {
//         description += '七喜 x ' + sevenUpQuantity + '\n';
//     }

//     cardText.textContent = description.trim(); // 移除描述的最後一個換行符號


//     // 隱藏對話框，顯示餐點區域
//     var dialog = document.getElementById('replacementDialog');
//     dialog.style.display = 'none';
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'block';
// }



// function updateLeftCard(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity) {
//     var cardText = document.getElementById('drinkDescription');
//     console.log(cardText);
//     // 更新飲料卡片描述
//     var description = '';

//     if (pepsiQuantity > 0) {
//         description += '百事可樂 x ' + pepsiQuantity + '\n';
//     }

//     if (sevenUpQuantity > 0) {
//         description += '七喜 x ' + sevenUpQuantity + '\n';
//     }

//     if (lemonQuantity > 0) {
//         description += '檸檬風味紅茶 x ' + lemonQuantity + '\n';
//     }

//     if (greenteaQuantity > 0) {
//         description += '冰無糖綠茶 x ' + greenteaQuantity + '\n';
//     }

//     if (redteaQuantity > 0) {
//         description += '熱紅茶 x ' + redteaQuantity + '\n';
//     }

//     cardText.innerText = description.trim(); // 移除描述的最後一個換行符號

//     // 隱藏對話框，顯示餐點區域
//     var dialog = document.getElementById('replacementDialog');
//     dialog.style.display = 'none';

//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'block';
// }

function updateLeftCard(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity) {
    var cardText = document.getElementById('drinkDescription');

    // 检查元素是否存在
    if (cardText) {
        // 更新飲料卡片描述
        var description = '';

        if (pepsiQuantity > 0) {
            description += '百事可樂 x ' + pepsiQuantity + '\n';
        }

        if (sevenUpQuantity > 0) {
            description += '七喜 x ' + sevenUpQuantity + '\n';
        }

        if (lemonQuantity > 0) {
            description += '檸檬風味紅茶 x ' + lemonQuantity + '\n';
        }

        if (greenteaQuantity > 0) {
            description += '冰無糖綠茶 x ' + greenteaQuantity + '\n';
        }

        if (redteaQuantity > 0) {
            description += '熱紅茶 x ' + redteaQuantity + '\n';
        }

        cardText.innerText = description.trim(); // 移除描述的最後一個換行符號

        // 隱藏對話框，顯示餐點區域
        var dialog = document.getElementById('replacementDialog');
        dialog.style.display = 'none';

        var mealInformation = document.querySelector('.combo-flow__imformation');
        mealInformation.style.display = 'block';
    } else {
        console.error('Element with id "drinkDescription" not found.');
    }
}


// function confirmMeal() {
//     // 获取百事可乐和七喜的数量
//     var pepsiQuantity = parseInt(document.getElementById('txtQuantity_cola').value);
//     var sevenUpQuantity = parseInt(document.getElementById('txtQuantity_seven_up').value);
//     var lemonQuantity = parseInt(document.getElementById('txtQuantity_tea').value);
//     var greenteaQuantity = parseInt(document.getElementById('txtQuantity_greentea').value);
//     var redteaQuantity = parseInt(document.getElementById('txtQuantity_redtea').value);


//     // 调用更新左侧卡片的函数，传入数量信息
//     updateLeftCard('百事可樂', pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity);
// }

// function showReplacementDialog() {
//     // 顯示對話框
//     // var carttypeId = event.target.dataset.cartetypeid;
//     // console.log(carttypeId); // 在控制台印出 carttype_id
//     var dialog = document.getElementById('replacementDialog');
//     dialog.style.display = 'block';

//     // 隱藏原本的餐點區域
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'none';
// }

function showReplacementDialog(cartetypeId) {
    // 使用 AJAX 请求更新页面内容
    // var xhr = new XMLHttpRequest();
    // xhr.open('GET', 'your_php_file.php?cartetype_id=' + cartetypeId, true);
    // xhr.onreadystatechange = function () {
    //     if (xhr.readyState == 4 && xhr.status == 200) {
    //         // 假设返回的是 HTML 内容
    //         document.getElementById('replacementDialog').innerHTML = xhr.responseText;
    //     }
    // };
    // xhr.send();

    var dialog = document.getElementById('replacementDialog');
    dialog.style.display = 'block';

    // 隱藏原本的餐點區域
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'none';
}

// function showReplacementDialog(cartetypeId, isFrench) {
//     // 使用 AJAX 请求更新页面内容
//     // var xhr = new XMLHttpRequest();
//     // xhr.open('GET', 'your_php_file.php?cartetype_id=' + cartetypeId, true);
//     // xhr.onreadystatechange = function () {
//     //     if (xhr.readyState == 4 && xhr.status == 200) {
//     //         // 假设返回的是 HTML 内容
//     //         var dialogId = isFrench ? 'replacement_french_Dialog' : 'replacementDialog';
//     //         document.getElementById(dialogId).innerHTML = xhr.responseText;
//     //     }
//     // };
//     // xhr.send();

//     var dialogId = isFrench ? 'replacement_french_Dialog' : 'replacementDialog';
//     var dialog = document.getElementById(dialogId);
//     dialog.style.display = 'block';

//     // 隐藏原本的餐點區域
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'none';
// }


var Mealtype;

// function showReplacementDialog(element) {
//     // 獲取 data-combo-id 屬性的值
//     var Mealtype = element.getAttribute('data-combo-id');
//     var comboId = element.getAttribute('data-combo-id_2');
//     document.getElementById('mealTypeInput').value = Mealtype;

//     // 在這裡可以使用 comboId 進行後續的處理
//     console.log('Mealtype ID:', Mealtype);
//     console.log('comboId ID:', comboId);

//     var mealTypeElement = document.getElementById('mealType');
//     mealTypeElement.innerHTML = 'Meal Type: ' + Mealtype;
//     // // 使用 AJAX 向後端發送請求處理相關邏輯
//     var xhttp = new XMLHttpRequest();
//     xhttp.open('GET', 'your_php_file.php', true);
//     xhttp.send();
//     // xhttp.open('GET', 'hotdeal_1_1.php', true);

//     // xhr.open('GET', 'hotdeal_1_1.php?mealType=' + MealtypeealType + '&comboId=' + comboId, true);

//     xhttp.onload = function () {
//         if (xhttp.status === 200) {
//             // 在此處處理 AJAX 請求的回應
//             console.log(xhttp.responseText);
//         }
//     };

//     // xhr.send();
//     var dialog = document.getElementById('replacementDialog');
//     dialog.style.display = 'block';

//     // 隱藏原本的餐點區域
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'none';

//     // var hiddenInput = document.createElement('input');
//     // hiddenInput.type = 'hidden';
//     // hiddenInput.name = 'Mealtype'; // 在 form 提交時使用的名稱
//     // hiddenInput.value = Mealtype;
//     // document.getElementById('replacementDialog').appendChild(hiddenInput);
// }

// function showReplacementDialog(element) {
//     // 獲取 data-combo-id 屬性的值
//     var Mealtype = element.getAttribute('data-combo-id');
//     var comboId = element.getAttribute('data-combo-id_2');
//     document.getElementById('mealTypeInput').value = Mealtype;

//     // 在這裡可以使用 comboId 進行後續的處理
//     console.log('Mealtype ID:', Mealtype);
//     console.log('comboId ID:', comboId);

//     var mealTypeElement = document.getElementById('mealType');
//     mealTypeElement.innerHTML = 'Meal Type: ' + Mealtype;

//     // 使用 AJAX 向後端發送請求處理相關邏輯
//     var xhttp = new XMLHttpRequest();

//     // 在 URL 中添加參數
//     var url = 'your_php_file.php?Mealtype=' + Mealtype;

//     xhttp.open('GET', url, true);
//     xhttp.send();

//     xhttp.onload = function () {
//         if (xhttp.status === 200) {
//             // 在此處處理 AJAX 請求的回應
//             console.log('Raw Response:', xhttp.responseText);

//             try {
//                 // 嘗試解析 JSON
//                 var responseData = JSON.parse(xhttp.responseText);
//                 console.log('Parsed Response:', responseData);
//             } catch (error) {
//                 console.error('Error parsing JSON:', error);
//             }
//         }
//     };

//     // xhr.send();
//     var dialog = document.getElementById('replacementDialog');
//     dialog.style.display = 'block';

//     // 隱藏原本的餐點區域
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'none';
// }



document.addEventListener("DOMContentLoaded", function () {
    // 取得當前網址
    var currentURL = window.location.href;

    // 使用 URLSearchParams 來解析 URL 中的參數
    var urlParams = new URLSearchParams(currentURL);

    // 獲取 combo_id 的值
    var comboId = urlParams.get('combo_id');

    // 使用 AJAX 將 combo_id 傳送到 PHP 文件
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            // 這裡可以處理從 PHP 返回的數據
            // console.log(this.responseText);
        }
    };
    xhttp.open("GET", "your_php_file.php?combo_id=" + comboId, true);
    xhttp.send();
});

// function showReplacementDialog(cartetypeId) {
//     // 將 cartetype_id 傳遞給對話框
//     var dialog = document.getElementById('replacementDialog');
//     dialog.setAttribute('data-cartetype-id', cartetypeId);
//     console.logdialog.setAttribute('data-cartetype-id', cartetypeId);
//     // 顯示對話框
//     dialog.style.display = 'block';

//     // 隱藏原本的餐點區域
//     var mealInformation = document.querySelector('.combo-flow__imformation');
//     mealInformation.style.display = 'none';
// }


function confirmReplacement() {
    // 获取选中的饮料信息和数量
    var pepsiQuantity = parseInt(document.getElementById('txtQuantity_1').value);
    var sevenUpQuantity = parseInt(document.getElementById('txtQuantity_2').value);
    var lemonQuantity = parseInt(document.getElementById('txtQuantity_3').value);
    var greenteaQuantity = parseInt(document.getElementById('txtQuantity_4').value);
    var redteaQuantity = parseInt(document.getElementById('txtQuantity_5').value);
    console.log(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity);

    // updateLeftCard('百事可樂', pepsiQuantity);
    // updateLeftCard('七喜', sevenUpQuantity);
    updateLeftCard(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity);
    updateRightDescription(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity);
    cancelReplacement();
}

function updateRightDescription(pepsiQuantity, sevenUpQuantity, lemonQuantity, greenteaQuantity, redteaQuantity) {
    // 获取右侧文字描述的元素
    var rightDescription = document.getElementById('divMealListText');

    // 获取原始的右侧文字描述
    var originalDescription = rightDescription.innerHTML;

    // 定義正則表達式以匹配原始描述中的百事可樂和七喜內容
    var pepsiRegex = /百事可樂\(中\) x \d+/;
    var sevenUpRegex = /七喜\(中\) x \d+/;
    var teaRegex = /立頓檸檬風味紅茶\(中\) x \d+/;
    var greenteaRegex = /冰無糖綠茶\(中\) x \d+/;
    var redteaRegex = /熱紅茶\(中\) x \d+/;

    // 取得原始描述中的百事可樂和七喜內容
    var originalPepsiContent = originalDescription.match(pepsiRegex);
    var originalSevenUpContent = originalDescription.match(sevenUpRegex);
    var originalTeaContent = originalDescription.match(teaRegex);
    var originalGreenTeaContent = originalDescription.match(greenteaRegex);
    var originalRedteaContent = originalDescription.match(redteaRegex);

    // 替換內容，如果數量大於0，否則保留空字串
    var replacedPepsiContent = pepsiQuantity > 0 ? '百事可樂 x ' + pepsiQuantity : '';
    var replacedSevenUpContent = sevenUpQuantity > 0 ? '七喜 x ' + sevenUpQuantity : '';
    var replacedTeaContent = lemonQuantity > 0 ? '立頓檸檬風味紅茶 x ' + lemonQuantity : '';
    var replacedGreenTeaContent = greenteaQuantity > 0 ? '冰無糖綠茶 x ' + greenteaQuantity : '';
    var replacedRedTeaContent = redteaQuantity > 0 ? '熱紅茶 x ' + redteaQuantity : '';

    // 更新右侧文字描述
    var replacedDescription = originalDescription
        .replace(pepsiRegex, replacedPepsiContent)
        .replace(sevenUpRegex, replacedSevenUpContent)
        .replace(teaRegex, replacedTeaContent)
        .replace(greenteaRegex, replacedGreenTeaContent)
        .replace(redteaRegex, replacedRedTeaContent);


    // 如果原始描述中沒有相應的內容，則追加新的內容
    if (!originalPepsiContent) {
        replacedDescription += replacedPepsiContent;
    }
    if (!originalSevenUpContent) {
        replacedDescription += replacedSevenUpContent;
    }
    if (!originalTeaContent) {
        replacedDescription += replacedTeaContent;
    }
    if (!originalGreenTeaContent) {
        replacedDescription += replacedGreenTeaContent;
    }
    if (!originalRedteaContent) {
        replacedDescription += replacedRedTeaContent;
    }

    // 清空原有內容
    rightDescription.innerHTML = '';

    // 將更新的描述添加到右侧文字描述
    rightDescription.innerHTML = replacedDescription;
}


function cancelReplacement() {
    // 隱藏對話框
    var dialog = document.getElementById('replacementDialog');
    dialog.style.display = 'none';
    var mealInformation = document.querySelector('.combo-flow__imformation');
    mealInformation.style.display = 'block';
}