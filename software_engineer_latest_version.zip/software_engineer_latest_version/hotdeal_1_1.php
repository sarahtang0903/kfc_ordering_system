<?php
// header('Content-Type: application/json;charset=utf-8');
session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼

$comboId = isset($_GET['combo_id']) ? $_GET['combo_id'] : 1;
 
// if(isset($_GET['combo_id']) ) {
//     $comboId = $_GET['combo_id'];
//     var_dump($comboId);
// } else {
//     echo 'error combo_id';
//     var_dump($_GET);
// }

// $comboId = $_SESSION['combo_id'];
// $comboId = $_SESSION['combo_id'];

// echo 



$sql_combo = "SELECT * from ((combination 
join combo on combination.combo_id = combo.combo_id) 
join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
join meals on meals.cartetype_id = combination.cartetype_id 
where combination.combo_id = $comboId";

$result_combo = mysqli_query($link, $sql_combo);
$row_combo = mysqli_fetch_assoc($result_combo);

 
//var_dump($comboname);
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取从前端发送的数据
    // $mealList = $_POST['mealList'];
    //  var_dump("mealList", $mealList);
    
    $mealListData = json_decode($_POST['mealList']);
    var_dump("mealllll", $mealListData);
    if ($mealListData === null && json_last_error() !== JSON_ERROR_NONE) {
        // JSON 解析失败
        echo 'Error decoding JSON: ' . json_last_error_msg();
    } 
    $mealTotalPrice = $_POST['mealTotalPrice'];
    var_dump("totallllll:", $mealTotalPrice);

    // $mealsNum = $_POST['txtQuantity'];
    // var_dump("mealsnum:", $mealsNum);
    $combonames = $_POST['combo_name'];


    $ways_id = $_SESSION['ways_id'];

    // var_dump('ways_id:', $ways_id);
    $member_id = $_SESSION['member_id'];
    // var_dump('member_id:', $member_id);
    $date_id = $_SESSION['date_id'];
    // var_dump('date_id:', $date_id);
    // $comboId = isset($_POST['combo_id']) ? $_POST['combo_id'] : 1;

    // $sql_combo_name = "SELECT * from ((combination 
    // join combo on combination.combo_id = combo.combo_id) 
    // join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
    // join meals on meals.cartetype_id = combination.cartetype_id 
    // where combination.combo_id = $comboId";

    // $result_combo_name = mysqli_query($link, $sql_combo_name);
    // $row_combo_name = mysqli_fetch_assoc($result_combo_name);

    // $comboname = $row_combo_name['combo_name'];

    if ($ways_id == 1) {
        $branch_id = $_SESSION['branch_id'];
        foreach ($mealListData as $meal) {
            $sql_branch = "INSERT INTO shoppingcart (shoppingcart_meals_name, shoppingcart_meals_content, shoppingcart_meals_price, member_id, ways_id, branch_id, date_id)
            VALUES ('$combonames', '$meal', '$mealTotalPrice', $member_id, $ways_id, $branch_id, $date_id)";
            mysqli_query($link, $sql_branch);
            // if ($link->query($sql_branch) === TRUE) {
            //     echo 'update successful';
            // } else {
            //     echo 'error';
            // }
        }
    } elseif ($ways_id == 2) {
        $delivery_id = $_SESSION['delivery_id'];
        foreach ($mealListData as $meal) {
            $sql_delivery = "INSERT INTO shoppingcart (shoppingcart_meals_name, shoppingcart_meals_content, shoppingcart_meals_price, member_id, ways_id, delivery_id)
            VALUES ('$combonames', '$meal', '$mealTotalPrice', $member_id, $ways_id, $delivery_id)";
            if ($link->query($sql_delivery) === TRUE) {
                echo 'update successful';
            } else {
                echo 'error';
            }
        }
    }



    // // 将数据插入到数据库
    // $sql = "INSERT INTO your_table_name (meal_name) VALUES ('$mealList')";
    // if ($conn->query($sql) === TRUE) {
    //     echo "Record inserted successfully";
    // } else {
    //     echo "Error inserting record: " . $conn->error;
    // }
    header("Location: hotdeal.php");
    exit();  // Ensure that no more output is sent
}



?>

<!DOCTYPE html>
<html lang="en">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="home_page.css">
</head>

<body>
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <button>
                <a href="#">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>
        </div>
    </header>

    <nav>
        <a href="hotdeal.php">熱門優惠</a>
        <a href="individual.php" style="color: red;">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php">早餐</a>
        <a href="single.php">單點</a>
    </nav>

    <div> </div>
    <main class="hub-spoke-flow">
        <div class="content">
            <div class="combo-flow__image">
                <div class="img-md">

                    <img class="lazy" alt="肯德基 雙層咔啦雞腿堡M經典餐" src="<?php echo $row_combo["combo_picture"] ?>">
                </div>
                <div class="mealsCartList">
                    <h1 class="mealsTitle">
                        <span class="smaller "><?php echo $row_combo['combo_name'] ?></span>
                    </h1>

                    <div class="front-bold front_color_gray" style="margin-bottom: 8px;">
                    </div>

                    <!-- <div id="divMealListText"> -->
                    <?php
                    $mealList = $row_combo['combo_content'];

                    // 使用某个字符（例如 'x'）分割字符串为数组
                    
                    // $mealsArray = explode('x1', $mealList);
                    // $mealsArray = preg_split('/x[1-6]/', $mealList, -1, PREG_SPLIT_NO_EMPTY);
                    // // 输出数组
                    // echo '<div id="divMealListText">';
                    // foreach ($mealsArray as $meal) {
                    //     // 去除两端的空格并创建相应的 HTML 元素
                    //     $meal = trim($meal);
                    //     if (!empty($meal)) {
                    //         echo '<p class="price-row mealList"><span>' . $meal . ' x 1</span></p>';
                    //     }
                    // }
                    preg_match_all('/([^\sx]+)\s*x\s*(\d+)/', $mealList, $matches, PREG_SET_ORDER);

// 输出数组
                    echo '<div id="divMealListText">';
                    foreach ($matches as $match) {
                        $mealType = trim($match[1]);
                        $quantity = trim($match[2]);

                        if (!empty($mealType) && !empty($quantity)) {
                            echo '<p class="price-row mealList"><span>' . $mealType . ' x ' . $quantity . '</span></p>';
                        }
                    }
                    echo '<p> </p>';
                    echo '</div>';
                    // $mealList = $row_combo['combo_content'];
                    // $mealsArray = explode('1', $mealList);
                    // var_dump($mealList);
                    // var_dump($mealsArray);

                    ?>
                    <!-- <p class="price-row mealList">
                            <span>雙層咔啦雞腿堡 x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>香酥脆薯(中) x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>百事可樂(中) x 1</span>
                        </p> -->
                </div>
                <hr>
                <p class="price-row mealList">
                    <span>餐點小計</span>
                    <span class="small-price">
                        $
                        <span id="MealTotalPrice"><?php echo $row_combo["combo_price"] ?></span>
                    </span>
                </p>

            </div>
        </div>

        <div class="combo-flow__imformation">
            <div calss="card_dispaly">

                <?php
                 

                $sql_content = "SELECT * from ((combination 
                    join combo on combination.combo_id = combo.combo_id) 
                    join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                    join meals on meals.cartetype_id = combination.cartetype_id 
                    where combination.combo_id = $comboId and combination.meals_id = meals.meals_id";

                $result_content = mysqli_query($link, $sql_content);

                $sql = "select * from ((combination 
                    join combo on combination.combo_id = combo.combo_id) 
                    join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                    join meals on meals.cartetype_id = combination.cartetype_id 
                    where combination.combo_id = $comboId";
                
                $result = mysqli_query($link, $sql);

                $row = mysqli_fetch_assoc($result);

                
                echo '<div class="card mb-3" style="max-width: 540px;">';
                echo '    <div class="row g-0">';
                echo '        <div class="col-md-4">';
                echo '            <img src="' . $row_combo['combo_picture'] . '" class="img-fluid rounded-start" alt="' . $row_combo['meals_name'] . '">';
                echo '        </div>';
                echo '        <div class="col-md-8">';
                echo '            <div class="card-body">';
                echo '                <h5 class="card-title">主餐</h5>';
                echo '<div class="card-text update-me">';
                echo '                <p class="card-text" id="card-text-left">' . $row_combo['combo_name'] . 'x1</p>';
                echo '<div/>';
                echo '            </div>';
                echo '        </div>';
                echo '    </div>';
                echo '</div>';
                  
                while ($row_content = mysqli_fetch_assoc($result_content)) {
                    $carttype = $row_content['cartetype_id'];
                     
                    if ($carttype == 1) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '        <p class="card-text" id = "chickenDescription">' . $row_content['meals_name'] . 'x 1</p>';
                        echo '</div>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_chicken()">';

                        echo '            更換';
                        // var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 2;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 2) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id = "eggDescription">' . $row_content['meals_name'] . 'x 1</p>';
                        echo '<div/>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_egg()">';

                        echo '            更換';
                        // var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 3;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 3) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id="drinkDescription" >' . $row_content['meals_name'] . 'x 1</p>';
                        echo '<div/>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                        echo '            更換';
                        // var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 4;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 4) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        // echo '                <p class="card-text">' . $row_content['meals_name'] . 'x1</p>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id =frenchDescription>' . $row_content['meals_name'] . 'x 1</p>';
                        echo '</div>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_french()">';

                        echo '            更換';
                        // var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype++;
                        // break;
                    }
                     
                }



                ?>


                <div class="amount-price">
                    <div class="incrementer">
                        <button class="js-dec" onclick="decrementQuantity()">
                            <img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">
                        </button>

                        <input title="Quantity" type="text" readonly value="1" id="txtQuantity">

                        <button class="js-inc" onclick="incrementQuantity()">
                            <img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">
                        </button>

                        <span class="small-small-price">
                            <span class="singleM">餐點 </span>
                            $
                            <span class="integer">
                                <span id="MealTotalPriceNoDiscount_none" style="display: none;"><?php echo $row_combo["combo_price"] ?></span>

                                <span id="MealTotalPriceNoDiscount"><?php echo $row_combo["combo_price"] ?></span>

                            </span>
                        </span>
                    </div>
                </div>
                <hr>
                <div>
                    <!-- <button type="button" class="btn-white " >
                        <span>回到菜單</span>
                    </button> -->
                    <button type="button" class="btn-white">
                        <a href="hotdeal.php">
                            <span>回到菜單</span>
                        </a>
                    </button>

                    <!-- <button type="button" class="btn-red " onclick="">
                        <span>加入餐車</span>
                    </button> -->
                    <form id="mealForm" action="hotdeal_1_1.php" method="POST">
                        <input type="hidden" id="mealListInput" name="mealList" value="">
                        <input type="hidden" id="mealTotalPriceInput" name="mealTotalPrice" value="">
                        <input type="hidden" name="combo_name" value="<?php echo $row_combo['combo_name'];?>">
                        <input type="submit" value="加入餐車" class="bbb">
                        <!-- <button type="submit" class="btn-red">
                                <span>加入餐車</span>
                            </button> -->
                    </form>
                </div>

            </div>
        </div>

        <script src="meal.js">
        </script>
    </main>






</body>



<?php
$carttype = $_GET['cartetype_id'];
// var_dump($carttype);

$sql = "select * from ((combination 
   join combo on combination.combo_id = combo.combo_id) 
   join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
   join meals on meals.cartetype_id = combination.cartetype_id 
   where combination.combo_id = $comboId
   and cartetype.cartetype_id = $carttype";

$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);

$sql_change_meals = "select * from ((combination 
   join combo on combination.combo_id = combo.combo_id) 
   join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
   join meals on meals.cartetype_id = combination.cartetype_id 
   where combination.combo_id = $comboId
   and cartetype.cartetype_id = $carttype";



// var_dump($carttype);

$result_change_meals = mysqli_query($link, $sql_change_meals);
// var_dump($result_change_meals);

$index = 1;
if ($carttype == 1) {
    echo '<div id="replacementDialog_chicken" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    // var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_chicken(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        // var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_chicken(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_chicken()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_chicken()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 2) {

    echo '<div id="replacementDialog_egg" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";

    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_Egg(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    // var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_Egg(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        // var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_Egg(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_egg()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_egg()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 3) {
    echo '<div id="replacementDialog" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    // var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        // var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 4) {
    echo '<div id="replacement_french_Dialog" style="display: none;">';

    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_French(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    // var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_French(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_French(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        // var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_French(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_french()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_french()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
}


 


?>
 


</div>
</div>




</div>

</html>