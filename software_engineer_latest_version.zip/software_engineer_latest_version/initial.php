<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acc = $_POST['acc'];
    $password1 = $_POST['pw'];
    $userEnteredCaptcha = $_POST['Captcha']; // 获取用户输入的验证码

    // 验证验证码是否匹配
    if ($_SESSION['captcha'] != $userEnteredCaptcha) {
        echo '<p>驗證碼錯誤，請重新輸入。</p>';
    } else {
        // 验证用户名和密码
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "software_db";

        $link = mysqli_connect($servername, $username, $password) or die("無法選擇資料庫");
        mysqli_select_db($link, $database);
        mysqli_query($link, "SET NAMES utf8");

        if (!$link) {
            die("連接失敗: " . mysqli_connect_error());
        }

        $sql = "SELECT member_id, member_phone, member_email, member_pwd FROM `member` WHERE ( `member_phone` = '$acc' OR `member_email` = '$acc' ) AND `member_pwd`= '$password1'";
        $result = mysqli_query($link, $sql);
        $member_id = mysqli_fetch_assoc($result);

        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $_SESSION['user_acc'] = $acc;
                $_SESSION['user_pwd'] = $password1;
                $_SESSION['logged_in'] = true;
                $_SESSION['member_id'] = $member_id['member_id'];

                header("Location: home_page.php");
                exit();
            } else {
                echo '<p>登入失敗，請檢查帳號和密碼。</p>';
            }
        } else {
            echo "查詢失敗：" . mysqli_error($link);
        }

        mysqli_close($link);
    }
}
?>

<!DOCTYPE html>
<html lang="zh-TW">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>會員登入</title>
    <link rel="stylesheet" href="initial.css">

</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">
                <a href="home_page.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
                </a>
            </div>
            <div class="user-controls">
                <button id="unsetbutton">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="Member Icon" width="20" height="20">
                </button>
                <div class="cart-icon">
                    <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="Shopping Cart Icon" width="50" height="50"></a>
                </div>
            </div>
        </div>
        <nav class="header-bottom">
            <a href="hotdeal.php">熱門優惠</a>
            <a href="individual.php">個人餐</a>
            <a href="many.php">多人餐</a>
            <a href="breakfast.php">早餐</a>
            <a href="single.php">單點</a>
        </nav>
    </header>
    <script>
        document.getElementById("unsetbutton").addEventListener("click", function() {
            window.location.href = "unset_session.php";
        });
    </script>



    <form action="initial.php" class="login" method="POST">
        <div class="change-details__form">
            <div class="content" id="tabLogin">
                <h1>會員登入</h1>
                <div data-tag="Login">
                    <div class="input-wrapper">
                        <input type="text" id="txtAcc" name="acc" placeholder="請輸入信箱或手機號碼" require="1" autocomplete="off">
                        <span for="acc" style="display:none">請輸入信箱或手機號碼</span>
                    </div>
                    <div class="input-wrapper">
                        <input type="password" id="txtPwd" name="pw" placeholder="請輸入密碼" autocomplete="off" require="1" />
                        <span for="pw" style="display:none">請輸入密碼</span>
                    </div>
                    <div class="memberInputbox">
                        <div class="input-wrapper">
                            <input type="text" id="txtCaptcha" name="Captcha" placeholder="請輸入驗證碼" require="1" maxlength="4">
                            <span for="Captcha" style="display:none">請輸入驗證碼</span>
                        </div>
                        <div class="verification_display">
                            <span id="displayCaptcha"></span>
                        </div>
                        <div>
                            <button type="button" class="btn white btn-spacing" onclick="refreshCaptcha(); Func_Analytic_Click('刷新驗證碼', 'Login')">
                                <span>刷新驗證碼</span>
                            </button>
                        </div>
                    </div>
                    <input type="submit" name="Login" class="btn btn-spacing" value=" 登入">
                    <div class="button-spacing"></div>
                    <div>
                        <button type="button" class="btn btn-spacing" onclick="redirectToRegister()">
                            <span>加入會員</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </form>
    <script>
        refreshCaptcha();

        function getRandom4Digit() {
            return Math.floor(1000 + Math.random() * 9000);
        }

        function refreshCaptcha() {
            var randomCaptcha = getRandom4Digit();
            document.getElementById("displayCaptcha").textContent = randomCaptcha;

            // 发送 AJAX 请求来更新验证码
            fetch('refresh_captcha.php', { // 创建一个新的 PHP 文件来处理验证码刷新
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'captcha=' + encodeURIComponent(randomCaptcha), // 将随机生成的验证码发送到后端
                })
                .then(response => {
                    // 在这里处理响应（如果需要的话）
                })
                .catch(error => {
                    console.error('刷新验证码时发生错误:', error);
                });
        }


        function redirectToRegister() {
            window.location.href = 'Register.php';
        }
    </script>
    <div class="account__links">
        <ul class="account-links">
            <li class="account-link"><a href="initial.php" onclick="GA4_login('5');">會員登入</a></li>
            <li class="account-link"><a href="Register.php" onclick="GA4_Signup('2');">加入會員</a></li>
            <li class="account-link"><a href="ForgetPW.php" onclick="GA4_fgpassword();">忘記密碼</a></li>
        </ul>
    </div>
</body>

</html>