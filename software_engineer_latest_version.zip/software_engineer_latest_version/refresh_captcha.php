<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['captcha'])) {
        $captcha = $_POST['captcha'];

        $_SESSION['captcha'] = $captcha;

        echo '驗證碼已更新'; // 
    } else {
        echo '未提供驗證碼';
    }
} else {
    echo '無效請求';
}
