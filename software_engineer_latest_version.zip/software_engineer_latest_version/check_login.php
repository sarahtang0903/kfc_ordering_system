<?php
session_start();// 在使用SESSION变量之前需要调用session_start()

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    // 用户未登录，在当前页面显示警告框
    echo '<script>alert("請先登入!");</script>';
    echo '<script>window.location.href = "initial.php";</script>'; // 使用 JavaScript 跳转
    exit(); // 终止脚本执行
}
