<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼

include("check_login.php");

$bag_price = 0;
$total_price = 0;
//$member_id = $_SESSION['member_id'];
$member_id = 1;
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  if (isset($_POST["delete"])) {

    $sql_delete = "DELETE FROM shoppingcart WHERE shoppingcart_meals_name = '{$_REQUEST['delete']}'";
    if ($link->query($sql_delete) === TRUE) {
      echo 'delete successful';
      header("Location: shoppingcart.php");
      exit();
    } else {
      echo "Error: " . $sql_delete . "<br>" . $link->error;
    }
  }
  if (isset($_POST["pay"])) {
    $bagNum = $_SESSION['shoppingbag_num'];

    $sql_insertshoppingbag_num = "UPDATE shoppingcart SET shoppingbag=$bagNum where member_id = $member_id";
    if ($link->query($sql_insertshoppingbag_num) === TRUE) {
      echo 'update successful';
      header("Location: pay.php");
      exit();
    } else {
      echo "Error: " . $sql_insertshoppingbag_num . "<br>" . $link->error;
    }
  }

  // 处理下拉式选单    
}
$sql = "SELECT * FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);


$sql_content = "SELECT * FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
$result_content = mysqli_query($link, $sql_content);
$row_content = mysqli_fetch_assoc($result_content);


$sql_test = "SELECT * FROM shoppingcart join member on member.member_id = shoppingcart.member_id";
$result_test = mysqli_query($link, $sql_test);
$row_test = mysqli_fetch_assoc($result_test);


?>

<!DOCTYPE html>
<html>

<head>
  <!--網頁編碼ｕｔｆ－８-->
  <meta charset="utf-8" />
  <title>KFC Website</title>
  <style>
    /* 設定select元素的寬度 */
    select {
      width: 418px;
      /* 設定寬度為200像素 */
      height: 25px;
    }

    hr {
      border-color: #d61111;
      /* 使用16進制顏色碼，這裡是紅色 */
    }

    .member {

      padding: 0;
      border: 0;
      font-size: 100%;
      margin-top: 10px;
      margin-left: 1080px;
      font: inherit;
      vertical-align: baseline;

    }

    .nameframe {
      background-color: #ea8966;
      padding: 6px 12px;
      color: #fff;
      font-weight: bold;
      font-size: 18px;
    }

    .main {
      background-image: url(background.jpg);
      display: block;


    }

    .background {
      position: sticky;
      background-color: #fff;
      top: 0;
    }

    .checkoutTotal {
      border-top: 1px solid #b7282c;
      border-bottom: 1px solid #b7282c;
      color: #b7282c;
      font-weight: bold;
      margin: 10px 0 0 0;
      padding: 3px 0;
      margin-bottom: 20px;
    }

    .font_24 {
      font-size: 24px;
      font-family: Arial;
    }

    .mealTitle {
      color: #ea8966;
      font-weight: bold;
      font-size: 16px !important;
      margin: 5px 0;
    }

    .mealContent li {
      list-style: none;
      padding-left: 24px;
      font-size: 14px;
      color: black;
    }

    .priceFrame {
      background-color: #fff !important;
      border-radius: 5px;
      padding: 2px 10px;
      margin: 10px 0 10px 0;
      text-align: right;
    }

    .bag {
      margin: 0 0 10px 0;
    }

    .img_delete {
      border: 0;
      vertical-align: middle;

    }

    .btn_edit {
      background-color: #ea8966;
      color: #fff;
      border-radius: 3px;
      padding: 2px 7px;
      font-size: 12px;
      float: none !important;
      margin-left: auto !important;
    }

    .btn_checkout_right {
      font-size: 21px;
      background-color: #b7282c;
      border-radius: 5px;
      margin: 20px 12px;
      padding: 10px;
      text-align: center;
      font-weight: bold;

      color: white;
      width: 100%;
    }

    #dropdown {
      display: none;
    }

    .bag {
      vertical-align: middle;
      width: auto !important;
      padding: 0.05em 1.2em;
      margin: 0 10px 0 5px;
      border: 1px solid;
      border-radius: 3px;
    }

    #dropdown_price {
      display: none;
    }

    .bagprice {
      float: right;
      font-weight: bold;
      font-size: 24px;
      margin-left: 1020px;
    }

    #container {
      display: flex;

    }
  </style>
</head>
<!--webite 主畫面，都寫在ｂｏｄｙ標籤中-->

<body>

  <!--<a href = "https://www.kfcclub.com.tw/">KFC訂購網站</a>-->
  <main class="main" id="gOptCart">
    <p class="background">
      <a href="home_page.php">
        <img src="kfc_grandfa.png" height="65" width="65" margin-top="0" margin-left="125" />
      </a>
      <a href="initial.php">
        <img class="member" src="shoppingcart_member.png" height="30" width="30" />
      </a>
    </p>
    <div class="nameframe">
      餐點內容
    </div>

    <form id="form" name="form" action="shoppingcart.php" method="POST">
      <?php
      
      // while ($row = mysqli_fetch_assoc($result)) {
      //   if ($row_content["shoppingcart_meals_name"] !== $row_test["shoppingcart_meals_name"]) {
      //     $row_test = mysqli_fetch_assoc($result_test);
      //   } else {
      // ?>
      <!-- //     <div class="mealTitle" id="container">
      //       <li><?php //echo $row["shoppingcart_meals_name"] ?><button id="button" style="background-color: #ea8966;color: #fff;border-radius: 3px; -->
      <!-- //       padding: 2px 7px;
      //       font-size: 12px;
      //       float: none !important;
      //       margin-left: auto !important;">修改</button> -->
      <!-- //         <input type="hidden" name="shoppingcart_meals_name" value="<?php //echo $row['shoppingcart_meals_name']; ?>"> -->
              <!--<input  type="image"  name="delete"  class="img_delete" img src="delete_button.PNG" width="25px" height="25px" onClick="document.form.submit()">-->
               <!--<button type="button" class="img_delete"><img src="delete_button.PNG" width="25px" height="25px"></button>-->
      <!-- //         <input type="submit" name="delete" value="<?php //echo $row['shoppingcart_meals_name']; ?>"> -->
             </li>
           </div>

           <li><?php //echo $row_content["shoppingcart_meals_content"] ?></li>
           <?php
      //     while ($row_content = mysqli_fetch_assoc($result_content)) {
      //       if ($row_content["shoppingcart_meals_name"] == $row_test["shoppingcart_meals_name"]) {
      //     ?>
               <li><?php //echo $row_content["shoppingcart_meals_content"] ?></li>
         <?php
      //       } else {
      //         $row_test = mysqli_fetch_assoc($result_test);
      //         break;
      //       }
      //     }
      ?>
      <?php
      $prevComboName = null;
      $count = 0;
      ?>
       
      <?php
      while ($row_content = mysqli_fetch_assoc($result)) {
        $comboName = $row_content["shoppingcart_meals_name"];
    
        // 检查套餐名是否变化
        if ($comboName != $prevComboName) {
          ?>
          <div class="mealTitle" id="container">
                 <li><?php echo $row_content["shoppingcart_meals_name"] ?><button id="button" style="background-color: #ea8966;color: #fff;border-radius: 3px; -->
                 padding: 2px 7px;
                 font-size: 12px;
                float: none !important;
                margin-left: auto !important;">修改</button> 
                   <input type="hidden" name="shoppingcart_meals_name" value="<?php echo $row_content['shoppingcart_meals_name']; ?>">
                    
                  <!-- <button type="button" class="img_delete"><img src="delete_button.PNG" width="25px" height="25px"></button> -->
                   <input type="submit" name="delete" value="<?php echo $row_content['shoppingcart_meals_name']; ?>">
                </li>
              </div>
    
               
              <?php
            $prevComboName = $comboName;
        }
        if($count == 0) {
          $count++;
          ?>
          <li><?php echo $row["shoppingcart_meals_content"] ?></li>
      
          <?php
        }
    ?>
         
        <li><?php echo $row_content["shoppingcart_meals_content"] ?></li>
    
         
 <?php        
    }
    ?>
    
    
          

          <div class="priceFrame">
            $<?php echo $row["shoppingcart_meals_price"];
              $price = $row["shoppingcart_meals_price"];

              $total_price = $total_price + $price;
              $_SESSION['shoppingcart_total_price'] = $total_price;
              ?>
          </div>
      <?php
       // }
      //}
      ?>

      <div id="container">

        <input id="showDropdown" type="checkbox" onchange="updatePrice()">購物袋
        <select id="dropdown" name="bag" class="bag" onchange="updatePrice()">
          <option value="1">1</option>
          <option value="2">2</option>
          <option value="3">3</option>
          <option value="4">4</option>
          <option value="5">5</option>
          <option value="6">6</option>
          <option value="7">7</option>
          <option value="8">8</option>
          <option value="9">9</option>
          <option value="10">10</option>
          <option value="11">11</option>
          <option value="12">12</option>
          <option value="13">13</option>
          <option value="14">14</option>
          <option value="15">15</option>
          <option value="16">16</option>
          <option value="17">17</option>
          <option value="18">18</option>
          <option value="19">19</option>
          <option value="20">20</option>
          <option value="21">21</option>
          <option value="22">22</option>
          <option value="23">23</option>
          <option value="24">24</option>
          <option value="25">25</option>
          <option value="26">26</option>
          <option value="27">27</option>
          <option value="28">28</option>
          <option value="29">29</option>
          <option value="30">30</option>
        </select>



        <script>
          function updatePrice() {
            var bagNum = document.getElementById('dropdown').value;
            var price = bagNum * 3;
            document.getElementById('displaybagprice').innerText = price;

            // 檢查購物袋是否被選中
            var isBagSelected = document.getElementById('showDropdown').checked;

            // 如果購物袋未被選中，價格設為零並更新顯示
            if (!isBagSelected) {
              document.getElementById('displayPrice').innerText = "<?php echo $total_price ?>";
              return; // 不再執行後續的 AJAX 請求
            }
            // 使用 AJAX 发送选择的值到服务器
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
              if (xhr.readyState == 4 && xhr.status == 200) {
                // 获取服务器返回的计算结果并更新显示在页面上
                var result = JSON.parse(xhr.responseText);
                var totalprice = parseFloat(result.totalprice);
                document.getElementById('displayPrice').innerText = totalprice;
                if (!isNaN(totalprice)) {
                  document.getElementById('displayPrice').innerText = totalprice;
                } else {
                  // 如果不是数字，显示错误信息
                  document.getElementById('displayPrice').innerText = "Error";
                }
              }

            };
            xhr.open("GET", "shoppingbag_calculate.php?bagNum=" + bagNum, true);
            xhr.send();
          }
        </script>

        <p id="dropdown_price" class="bagprice">$<span id="displaybagprice">3</span></p>
      </div>


      <script>
        document.getElementById('showDropdown').addEventListener('change', function() {
          var dropdown = document.getElementById('dropdown');
          dropdown.style.display = this.checked ? 'block' : 'none';
        });
      </script>

      <script>
        document.getElementById('showDropdown').addEventListener('change', function() {
          var dropdown = document.getElementById('dropdown_price');
          dropdown.style.display = this.checked ? 'block' : 'none';
        });
      </script>

      <div class="font_24 checkoutTotal" displayfor="propmotion">
        金額總計
        <div id="priceDisplay" class="floatR">Total Price: $<span id="displayPrice"><?php echo $total_price ?></span></div>


      </div>
      <div>
        <input type="submit" class="btn_checkout_right" name="pay" value="立即結帳">
      </div>
  </main>
  </form>
</body>

</html>