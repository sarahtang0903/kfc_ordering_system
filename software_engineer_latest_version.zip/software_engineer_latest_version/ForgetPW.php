<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 获取登录表单提交的数据
    $ep = $_POST['ep'];
    $userEnteredCaptcha = $_POST['Captcha'];

    if ($_SESSION['captcha'] != $userEnteredCaptcha) {
        echo '<p>驗證碼錯誤，請重新輸入。</p>';
    } else {

        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "software_db";

        // 建立与数据库的连接
        $link = mysqli_connect($servername, $username, $password) or die("无法选择数据库"); // 建立与数据库的连接对象
        mysqli_select_db($link, $database); // 选择数据库
        mysqli_query($link, "SET NAMES utf8"); // 设置编码

        // 检查连接是否成功
        if (!$link) {
            die("连接失败: " . mysqli_connect_error());
        }

        // 执行登录的SQL语句
        $sql = "SELECT  member_phone, member_email FROM `member` WHERE `member_phone` = '$ep' OR `member_email` = '$ep' ";
        $result = mysqli_query($link, $sql);
        if ($result) {
            if (mysqli_num_rows($result) > 0) {
                // 登录成功，储存用户 ID 到 Session
                $row = mysqli_fetch_assoc($result);
                $_SESSION['ep'] = $ep;

                header("Location: Chanpwd.php");
                exit();
            } else {
                $_SESSION['error_message'] = '尚未注册。';
            }
        } else {
            $_SESSION['error_message'] = "查询失败：" . mysqli_error($link);
        }
        mysqli_close($link);
    }
    // 关闭连接

}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC 忘記密碼</title>
    <link rel="stylesheet" href="Forget.css">
    <style>

    </style>
</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">
                <a href="home_page.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
                </a>
            </div>
            <div class="user-controls">
                <button id="unsetbutton">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="Member Icon" width="20" height="20">
                </button>
                <div class="cart-icon">
                    <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="Shopping Cart Icon" width="50" height="50"></a>
                </div>
            </div>
        </div>
        <nav class="header-bottom">
            <a href="hotdeal.php">熱門優惠</a>
            <a href="individual.php">個人餐</a>
            <a href="many.php">多人餐</a>
            <a href="breakfast.php">早餐</a>
            <a href="single.php">單點</a>
        </nav>
    </header>
    <script>
        document.getElementById("unsetbutton").addEventListener("click", function() {
            window.location.href = "unset_session.php";
        });
    </script>
    <main class="change-details">
        <form action="ForgetPW.php" method="post" onsubmit="return showLoginModal()">
            <div class="content">
                <div class="change-details__form">
                    <div class="content">
                        <h1>忘記密碼</h1>
                        <?php
                        if (isset($_SESSION['error_message'])) {
                            echo '<p>' . $_SESSION['error_message'] . '</p>';
                            unset($_SESSION['error_message']); // 清除错误消息
                        }
                        ?>
                        <div id="verificationCodeResult" style="display: none;"></div>

                        <div class="input-wrapper">
                            <input type="text" id="ep" name="ep" maxlength="60" placeholder="請輸入會員帳號(email)或手機號碼" autocomplete="off" />
                        </div>
                        <div class="input-wrapper">
                            <input type="text" id="txtCaptcha" name="Captcha" placeholder="請輸入驗證碼" require="1" maxlength="4">
                            <span for="Captcha" style="display:none">請輸入驗證碼</span>
                        </div>

                        <div class="verification_display">
                            <span id="displayCaptcha"></span>
                        </div>
                        <div>
                            <button class="btn white btn-spacing" onclick="refreshCaptcha(); Func_Analytic_Click('刷新驗證碼', 'Login')">
                                <span>刷新驗證碼</span>
                            </button>
                        </div>
                        <div class="button-spacing"></div>

                        <input type="submit" name="Change" class="btn block btn-spacing" value="確認送出">

                        <div class="button-spacing"></div>
                        <div>
                            <button type="button" class="btn block white btn-spacing" onclick="redirectToRegister()">
                                <span>加入會員</span>
                            </button>
                        </div>
                    </div>

                </div>
            </div>
        </form>

        <script>
            refreshCaptcha();

            function getRandom4Digit() {
                return Math.floor(1000 + Math.random() * 9000);
            }

            function refreshCaptcha() {
                var randomCaptcha = getRandom4Digit();
                document.getElementById("displayCaptcha").textContent = randomCaptcha;

                // 发送 AJAX 请求来更新验证码
                fetch('refresh_captcha.php', { // 创建一个新的 PHP 文件来处理验证码刷新
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: 'captcha=' + encodeURIComponent(randomCaptcha), // 将随机生成的验证码发送到后端
                    })
                    .then(response => {
                        // 在这里处理响应（如果需要的话）
                    })
                    .catch(error => {
                        console.error('刷新验证码时发生错误:', error);
                    });
            }

            function showLoginModal() {
                var enteredAcc = document.getElementById("ep").value;
                var enteredCaptcha = document.getElementById("txtCaptcha").value;
                var actualCaptcha = document.getElementById("displayCaptcha").textContent;

                if (enteredAcc !== "" && enteredCaptcha === actualCaptcha) {
                    setTimeout(function() {
                        redirectToChange();
                    }, 2000);
                    return true; // 允许表单提交
                } else {
                    alert("尚未注册帐号，或验证码错误。");
                    // 刷新验证码
                    refreshCaptcha();
                    return false; // 阻止表单提交
                }
            }
        </script>
        <script>
            function redirectToLogin() {
                window.location.href = '/kfc/initial.php';
            }

            function redirectToRegister() {
                window.location.href = '/kfc/Register.php';
            }

            function redirectToOrder() {
                window.location.href = '/kfc/Order.html';
            }

            function redirectToChange() {
                window.location.href = '/kfc/Chanpwd.php';
            }
        </script>
    </main>
</body>

</html>