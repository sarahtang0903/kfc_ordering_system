<?php
// header('Content-Type: application/json;charset=utf-8');

// $comboId = $_SESSION['combo_id'];
// $comboId = $_GET['combo_id'];
// $_SESSION

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼
include("check_login.php");

?>

<!DOCTYPE html>
<html lang="en">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="hotdeal.css">
</head>

<body class="page-hotdeal">
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <button>
                <a href="#">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>
        </div>

    </header>
    <nav>
        <a href="hotdeal.php" style="color: red;">熱門優惠</a>
        <a href="individual.php">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php">早餐</a>
        <a href="single.php">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>
    <nav class="hotdeal_bar">
        <a href="#hotdeal_1">熱門菜單優惠</a>
        <a href="#hotdeal_2">預定快取+1送蛋塔</a>
        <a href="#hotdeal_3">預定快取+1送炸雞塊或炸雞</a>
        <a href="#hotdeal_4">青花椒系列</a>
        <a href="#hotdeal_5">XL超豪肯套餐 買多送多專區</a>
    </nav>

    <h1></h1>
    <div>
        <h1 id="hotdeal_1">熱門菜單優惠</h1>

        <div class="card-group mx-auto">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL-20230721-pc.jpg" class="card-img-top" alt="Zinger stacker XL combo">
                <div class="card-body">
                    <h5 class="card-title">雙層咔啦雞腿堡 XL餐</h5>
                    <p class="card-text">
                    <div>雙層咔啦雞腿堡 x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>百事可樂(中) x 1</div>
                    <div>...更多</div>
                    <div>$260</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 1";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . urlencode($comboId). '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    
                ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1XL%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡L絕配餐">
                <div class="card-body">
                    <h5 class="card-title">海陸咔啦脆雞Q蝦堡 XL餐</h5>
                    <p class="card-text">
                    <div>雙層咔啦雞腿堡 x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>原味蛋塔 x 1</div>
                    <div>...更多</div>
                    <div>245</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 2";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1M%e7%b6%93%e5%85%b8%e9%a4%90-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡XL">
                <div class="card-body">
                    <h5 class="card-title">雙層咔啦雞腿堡 M經典餐</h5>
                    <p class="card-text">
                    <div>雙層咔啦雞腿堡 x 1</div>
                    <div>咔啦脆雞(辣) x 1</div>
                    <div>原味蛋塔 x 1</div>
                    <div>205</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 11";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

        </div>


        <div class="card-group mx-auto">


            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1M%e7%b6%93%e5%85%b8%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="海陸堡M經典餐">
                <div class="card-body">
                    <h5 class="card-title">海陸卡啦脆雞Q蝦堡M經典餐</h5>
                    <p class="card-text">
                    <div>海陸卡啦脆雞Q蝦堡 x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>百事可樂(中) x 1</div>
                    <div>195</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 12";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-XL-20231019-pc.jpg" class="card-img-top" alt="海陸堡XL餐">
                <div class="card-body">
                    <h5 class="card-title">剝皮辣椒紙包雞 XL套餐</h5>
                    <p class="card-text">
                    <div>剝皮辣椒紙包雞 x 1</div>
                    <div>雞汁風味飯 x 1</div>
                    <div>上校雞塊 x 4</div>
                    <div>原味蛋撻 x 1</div>
                    <div>百事可樂(中) x 1</div>
                    <div>...更多</div>
                    <div>239</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 3";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>



        </div>
        <!-- 熱門菜單優惠結束 -->

        <!-- 預定快取+1送蛋塔 -->

        <h1 id="hotdeal_2">預定快取+1送蛋塔</h1>

        <div class="card-group">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡XL">
                <div class="card-body">
                    <h5 class="card-title">雙層咔啦雞腿堡XL餐</h5>
                    <p class="card-text">
                    <div>雙層咔啦雞腿堡 x 1</div>
                    <div>咔啦脆雞(辣) x 1</div>
                    <div>原味蛋塔 x 1</div>
                    <div>...更多</div>
                    <div>260</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 1";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1XL%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="海陸堡XL餐">
                <div class="card-body">
                    <h5 class="card-title">海陸咔啦雞Q蝦堡XL餐</h5>
                    <p class="card-text">
                    <div>海陸咔啦雞Q蝦堡 x 1</div>
                    <div>咔啦脆雞(辣) x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>...更多</div>
                    <div>245</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 2";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-XL-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-XL">
                <div class="card-body">
                    <h5 class="card-title">剝皮辣椒紙包雞XL套餐</h5>
                    <p class="card-text">
                    <div>剝皮辣椒紙包雞 x 1</div>
                    <div>20:00前供應雞汁風味飯 x 1</div>
                    <div>上校雞塊塊 x 1</div>
                    <div>...更多</div>
                    <div>239</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 3";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

        </div>

        <div class="card-group">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-XL%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e9%ba%bb%e9%9b%9e20221215-pc.jpg" class="card-img-top" alt="XL餐-青花椒麻雞">
                <div class="card-body">
                    <h5 class="card-title">青花椒香麻脆雞XL餐</h5>
                    <p class="card-text">
                    <div>青花椒香麻脆雞(辣) X 2</div>
                    <div>上校雞塊4塊 x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>...更多</div>
                    <div>235</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 4";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒卡啦雞腿堡XL餐">
                <div class="card-body">
                    <h5 class="card-title">青花椒香麻咔啦雞腿堡XL餐</h5>
                    <p class="card-text">
                    <div>青花椒香麻咔啦雞腿堡 x 1</div>
                    <div>咔啦脆雞(辣) x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>...更多</div>
                    <div>220</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 5";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>



        </div>

        <!-- 預定快取+1送蛋塔結束 -->

        <!-- 預定快取+1送炸雞塊或炸雞 -->

        <h1 id="hotdeal_3">預定快取+1送炸雞塊或炸雞</h1>

        <div class="card-group">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-%e5%90%8c%e6%a8%82%e9%a4%9020231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-同樂餐">
                <div class="card-body">
                    <h5 class="card-title">剝皮辣椒紙包雞 同樂餐</h5>
                    <p class="card-text">
                    <div>剝皮辣椒紙包雞 x 3</div>
                    <div>20:00前供應雞汁風味飯 x 3</div>
                    <div>咔啦脆雞(辣) x 1</div>
                    <div>...更多</div>
                    <div>920</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 30";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-%e9%9b%99%e6%8b%bc%e9%a4%9020231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-雙拼餐">
                <div class="card-body">
                    <h5 class="card-title">剝皮辣椒紙包雞 雙拼餐</h5>
                    <p class="card-text">
                    <div>剝皮辣椒紙包雞 x 2</div>
                    <div>20:00前供應雞汁風味飯 x 2</div>
                    <div>咔啦脆雞(辣) x 4</div>
                    <div>...更多</div>
                    <div>389</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 26";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-%e9%9b%99%e4%ba%ba%e9%a4%9020231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-雙人餐">
                <div class="card-body">
                    <h5 class="card-title">剝皮辣椒紙包雞-雙人餐</h5>
                    <p class="card-text">
                    <div>剝皮辣椒紙包雞 x 1</div>
                    <div>20:00前供應雞汁風味飯 x 1</div>
                    <div>咔啦脆雞(辣) x 2</div>
                    <div>...更多</div>
                    <div>389</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 25";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

        </div>

        <div class="card-group">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e9%9d%92%e8%8a%b1%e6%a4%92%e7%8b%82%e5%97%91%e6%a1%b6_20220928-pc.jpg" class="card-img-top" alt="青花椒狂嗑桶">
                <div class="card-body">
                    <h5 class="card-title">青花椒狂嗑桶</h5>
                    <p class="card-text">
                    <div>青花椒香麻脆雞 x 5</div>
                    <div>雙色轉轉QQ球 x 1</div>
                    <div>原味蛋塔 x 2</div>
                    <div>...更多</div>
                    <div>389</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 27";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e9%a6%99%e9%ba%bb%e8%84%86%e9%9b%9e%e9%9b%99%e4%ba%ba%e9%a4%9020220901-pc.jpg" class="card-img-top" alt="青花椒香麻脆雞雙人餐">
                <div class="card-body">
                    <h5 class="card-title">青花椒香麻脆雞雙人餐</h5>
                    <p class="card-text">
                    <div>青花椒香麻脆雞(辣) x 2</div>
                    <div>咔啦脆雞(辣) x 2</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>...更多</div>
                    <div>380</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 29";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>


        </div>

        <!-- 預定快取+1送炸雞塊或炸雞結束 -->

        <h1 id="hotdeal_4">青花椒系列</h1>
        <!-- 青花椒系列開始 -->
        <div class="card-group">
            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-%e9%9d%92%e8%8a%b1%e6%a4%92%e7%8b%82%e5%97%91%e6%a1%b6_20220928-pc.jpg" class="card-img-top" alt="青花椒狂嗑桶">
                <div class="card-body">
                    <h5 class="card-title">青花椒狂嗑桶</h5>
                    <p class="card-text">
                    <div>青花椒香麻脆雞 x 5</div>
                    <div>雙色轉轉QQ球 x 1</div>
                    <div>原味蛋塔 x 2</div>
                    <div>...更多</div>
                    <div>389</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 27";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <<img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e9%a6%99%e9%ba%bb%e8%84%86%e9%9b%9e%e9%9b%99%e4%ba%ba%e9%a4%9020220901-pc.jpg" class="card-img-top" alt="青花椒香麻脆雞雙人餐">
                    <div class="card-body">
                        <h5 class="card-title">青花椒香麻脆雞雙人餐</h5>
                        <p class="card-text">
                        <div>青花椒香麻脆雞(辣) x 2</div>
                        <div>咔啦脆雞(辣) x 2</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>380</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 29";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
            </div>

            <div class="hotmeal_card" style="width: 18rem;">
                <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-XL%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e9%ba%bb%e9%9b%9e20221215-pc.jpg" class="card-img-top" alt="XL餐-青花椒麻雞">
                <div class="card-body">
                    <h5 class="card-title">青花椒香麻脆雞XL餐</h5>
                    <p class="card-text">
                    <div>青花椒香麻脆雞(辣) X 2</div>
                    <div>上校雞塊4塊 x 1</div>
                    <div>香酥脆薯(中) x 1</div>
                    <div>...更多</div>
                    <div>235</div>
                    </p>
                    <?php
                    $sql = "SELECT * FROM `combo` WHERE `combo_id`= 4";
                    $result = mysqli_query($link, $sql);

                    if ($result) {
                        $row = mysqli_fetch_assoc($result);
                        // 在這裡使用 $row 中的資料來顯示內容

                        // 使用 combo_id 參數生成訂購連結
                        $comboId = $row['combo_id'];
                        // $_SESSION['combo_id'] = $comboId;

                        echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                    } else {
                        echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                    }
                    // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                    ?>
                </div>

            </div>

            <div class="card-group">
                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e9%a6%99%e9%ba%bb%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1%e9%9b%99%e4%ba%ba%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒香麻咔啦雞腿堡雙人餐">
                    <div class="card-body">
                        <h5 class="card-title">青花椒香麻咔啦雞腿堡雙人餐</h5>
                        <p class="card-text">
                        <div>青花椒香麻咔啦雞腿堡 x 1</div>
                        <div>青花椒香麻脆雞(辣) x 2</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>380</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 28";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>

                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒卡啦雞腿堡XL餐">
                    <div class="card-body">
                        <h5 class="card-title">青花椒香麻咔啦雞腿堡XL餐</h5>
                        <p class="card-text">
                        <div>青花椒香麻咔啦雞腿堡 x 1</div>
                        <div>咔啦脆雞(辣) x 1</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>220</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 5";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>



            </div>

            <!-- 青花椒系列結束 -->

            <!-- XL超豪肯套餐 買多送多專區 -->
            <h1 id="hotdeal_5">XL超豪肯套餐 買多送多專區</h1>

            <div class="card-group">
                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1XL%e9%a4%9020230417-pc.jpg" class="card-img-top" alt="海陸堡XL餐">
                    <div class="card-body">
                        <h5 class="card-title">海陸咔啦脆雞Q蝦堡XL餐</h5>
                        <p class="card-text">
                        <div>海陸咔啦脆雞Q蝦堡 x 1</div>
                        <div>咔啦脆雞(辣) x 1</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>245</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 2";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>

                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL%e9%a4%9020220518-pc.jpg" class="card-img-top" alt="青花椒卡啦雞腿堡XL餐">
                    <div class="card-body">
                        <h5 class="card-title">青花椒香麻咔啦雞腿堡XL餐</h5>
                        <p class="card-text">
                        <div>青花椒香麻咔啦雞腿堡 x 1</div>
                        <div>咔啦脆雞(辣) x 1</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>220</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 5";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>

                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/OLO%e9%a4%90%e5%9c%96-XL%e9%a4%90-%e9%9d%92%e8%8a%b1%e6%a4%92%e9%ba%bb%e9%9b%9e20221215-pc.jpg" class="card-img-top" alt="XL餐-青花椒麻雞">
                    <div class="card-body">
                        <h5 class="card-title">青花椒香麻脆雞XL餐</h5>
                        <p class="card-text">
                        <div>青花椒香麻脆雞(辣) X 2</div>
                        <div>上校雞塊4塊 x 1</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>...更多</div>
                        <div>235</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 4";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>


            </div>

            <div class="card-group">
                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-XL-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-XL">
                    <div class="card-body">
                        <h5 class="card-title">剝皮辣椒紙包雞XL套餐</h5>
                        <p class="card-text">
                        <div>剝皮辣椒紙包雞 x 1</div>
                        <div>20:00前供應雞汁風味飯 x 1</div>
                        <div>上校雞塊塊 x 1</div>
                        <div>...更多</div>
                        <div>239</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 3";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>

                <div class="hotmeal_card" style="width: 18rem;">
                    <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1XL-20230721-pc.jpg" class="card-img-top" alt="Zinger stacker XL combo">
                    <div class="card-body">
                        <h5 class="card-title">雙層咔啦雞腿堡 XL餐</h5>
                        <p class="card-text">
                        <div>雙層咔啦雞腿堡 x 1</div>
                        <div>香酥脆薯(中) x 1</div>
                        <div>百事可樂(中) x 1</div>
                        <div>...更多</div>
                        <div>260</div>
                        </p>
                        <?php
                        $sql = "SELECT * FROM `combo` WHERE `combo_id`= 1";
                        $result = mysqli_query($link, $sql);

                        if ($result) {
                            $row = mysqli_fetch_assoc($result);
                            // 在這裡使用 $row 中的資料來顯示內容

                            // 使用 combo_id 參數生成訂購連結
                            $comboId = $row['combo_id'];
                            // $_SESSION['combo_id'] = $comboId;

                            echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                        } else {
                            echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                        }
                        // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                        ?>
                    </div>
                </div>


            </div>
            <!-- XL超豪肯套餐 買多送多專區 結束 -->



        </div>

</body>

</html>