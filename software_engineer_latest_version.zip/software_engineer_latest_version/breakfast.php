<?php
// header('Content-Type: application/json;charset=utf-8');
// session_start();
// $comboId = $_SESSION['combo_id'];
$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼
include("check_login.php");
?>

<!DOCTYPE html>
<html lang="en">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="hotdeal.css">
</head>

<body class="page-hotdeal">
    <div class="top-section">
        <header>
            <div class=logo>
                <a href="home_page.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
                </a>
            </div>
            <div class=member>
                <button>
                    <a href="initial.php">
                        <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                    </a>
                </button>
            </div>
        </header>
    </div>

    <nav class="all_bar">
        <a href="hotdeal.php">熱門優惠</a>
        <a href="individual.php">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php" style="color: red;">早餐</a>
        <a href="single.php">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>
    <nav class="hotdeal_bar">
        <a href="#breakfast_set">早餐套餐</a>
        <a href="#breakfast_single">早餐單點</a>
    </nav>

    <h1></h1>

    <h1 id="breakfast_set">早餐套餐</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a1-%e5%a5%97%e9%a4%9020221115-pc.jpg" class="card-img-top" alt="花生吮指嫩雞蛋堡-套餐">
            <div class="card-body">
                <h5 class="card-title">花生吮指嫩雞蛋堡套餐</h5>
                <p class="card-text">
                <div>花生吮指嫩雞蛋堡 x 1</div>
                <div>經典熱奶茶(小) x 1</div>
                <div>$79</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 35";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e8%82%89%e9%ac%86%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a1-%e5%a5%97%e9%a4%9020221115-pc.jpg" class="card-img-top" alt="花生肉鬆嫩雞蛋堡-套餐">
            <div class="card-body">
                <h5 class="card-title">花生肉鬆嫩雞蛋堡套餐</h5>
                <p class="card-text">
                <div>花生肉鬆嫩雞蛋堡 x 1</div>
                <div>經典熱奶茶(小) x 1</div>
                <div>$79</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 36";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a1%e5%a5%97%e9%a4%900724-pc.jpg" class="card-img-top" alt="吮指嫩雞蛋堡套餐">
            <div class="card-body">
                <h5 class="card-title">吮指嫩雞蛋堡套餐</h5>
                <p class="card-text">
                <div>吮指嫩雞蛋堡 x 1</div>
                <div>經典熱奶茶(小) x 1</div>
                <div>$69</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 37";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e8%b5%b7%e5%8f%b8%e8%9b%8b%e5%a0%a1-%e5%a5%97%e9%a4%9020221115-pc.jpg" class="card-img-top" alt="花生起司蛋堡-套餐">
            <div class="card-body">
                <h5 class="card-title">花生起司蛋堡套餐</h5>
                <p class="card-text">
                <div>花生起司蛋堡 x 1</div>
                <div>經典熱奶茶(小) x 1</div>
                <div>$49</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 38";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e6%8d%b2%e9%a4%85-%e5%a5%97%e9%a4%9020221115-pc.jpg" class="card-img-top" alt="吮指嫩雞蛋捲餅-套餐">
            <div class="card-body">
                <h5 class="card-title">吮指嫩雞蛋捲餅套餐</h5>
                <p class="card-text">
                <div>吮指嫩雞蛋捲餅 x 1</div>
                <div>經典熱奶茶(小) x 1</div>
                <div>$85</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 39";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>


    </div>


    <h1 id="breakfast_single">早餐單點</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a120221115-pc.jpg" class="card-img-top" alt="花生吮指嫩雞蛋堡">
            <div class="card-body">
                <h5 class="card-title">花生吮指嫩雞蛋堡</h5>
                <p class="card-text">
                <div>$60</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 40";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e8%82%89%e9%ac%86%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a120221115-pc.jpg" class="card-img-top" alt="花生肉鬆嫩雞蛋堡">
            <div class="card-body">
                <h5 class="card-title">花生肉鬆嫩雞蛋堡</h5>
                <p class="card-text">
                <div>$60</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 41";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e5%a0%a1-pc.jpg" class="card-img-top" alt="吮指嫩雞蛋堡">
            <div class="card-body">
                <h5 class="card-title">吮指嫩雞蛋堡</h5>
                <p class="card-text">
                <div>$50</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 42";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%b1%e7%94%9f%e8%b5%b7%e5%8f%b8%e8%9b%8b%e5%a0%a120221115-pc.jpg" class="card-img-top" alt="花生起司蛋堡">
            <div class="card-body">
                <h5 class="card-title">花生起司蛋堡</h5>
                <p class="card-text">
                <div>$35</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 43";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%90%ae%e6%8c%87%e5%ab%a9%e9%9b%9e%e8%9b%8b%e6%8d%b2%e9%a4%8520221115-pc.jpg" class="card-img-top" alt="吮指嫩雞蛋捲餅">
            <div class="card-body">
                <h5 class="card-title">吮指嫩雞蛋捲餅</h5>
                <p class="card-text">
                <div>$66</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 44";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>



    </div>







</body>

</html>