<?php
session_start();
$totalprice = $_SESSION['shoppingcart_total_price'];

if (isset($_GET["bagNum"])) {
    $bagNum = intval($_GET["bagNum"]);
    $_SESSION['shoppingbag_num'] = $bagNum;
    $bagPerPrice = 3;
    $bagPrice = $bagNum * $bagPerPrice;

    $totalprice = $totalprice + $bagPrice;
    
    // 將計算結果返回為 JSON 格式
    echo json_encode(["totalprice" => $totalprice]);
}
?>