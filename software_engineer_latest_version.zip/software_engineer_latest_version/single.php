<?php
// header('Content-Type: application/json;charset=utf-8');
// session_start();
// $comboId = $_SESSION['combo_id'];
$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼
include("check_login.php");
?>

<!DOCTYPE html>
<html lang="en">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="hotdeal.css">
</head>

<body class="page-hotdeal">
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <button>
                <a href="initial.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>
        </div>
    </header>

    <nav>
        <a href="hotdeal.php">熱門優惠</a>
        <a href="individual.php">個人餐</a>
        <a href="many.php">多人餐</a>
        <a href="breakfast.php">早餐</a>
        <a href="single.php" style="color: red;">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>
    <nav class="hotdeal_bar">
        <a href="#single_1">單點主餐</a>
        <a href="#single_2">蛋塔</a>
        <a href="#single_3">附餐/點心</a>
        <a href="#single_4">飲料/湯品</a>
    </nav>

    <h1></h1>

    <h1 id="single_1">單點主餐</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e5%b1%a4%e5%92%94%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a1-20230721-pc.jpg" class="card-img-top" alt="雙層咔啦雞腿堡">
            <div class="card-body">
                <h5 class="card-title">雙層咔啦雞腿堡</h5>
                <p class="card-text">
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 45";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%b5%b7%e9%99%b8%e5%a0%a1%e5%96%ae%e9%bb%9e20230417-pc.jpg" class="card-img-top" alt="海陸堡單點">
            <div class="card-body">
                <h5 class="card-title">海陸咔啦脆雞Q蝦堡</h5>
                <p class="card-text">
                <div>$89</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 46";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%89%9d%e7%9a%ae%e8%be%a3%e6%a4%92%e7%b4%99%e5%8c%85%e9%9b%9e-%e5%96%ae%e9%bb%9e-20231019-pc.jpg" class="card-img-top" alt="剝皮辣椒紙包雞-單點">
            <div class="card-body">
                <h5 class="card-title">剝皮辣椒紙包雞</h5>
                <p class="card-text">
                <div>不需刀叉及手套 x 1</div>
                <div>$149</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 47";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%be%8e%e5%bc%8f%e7%85%99%e7%87%bb%e5%92%94%e8%84%86%e9%9b%9e%e5%a0%a120230208-pc.jpg" class="card-img-top" alt="美式煙燻咔脆雞堡">
            <div class="card-body">
                <h5 class="card-title">美式煙燻咔脆雞堡</h5>
                <p class="card-text">
                <div>$99</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 48";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9d%92%e8%8a%b1%e6%a4%92%e5%8d%a1%e5%95%a6%e9%9b%9e%e8%85%bf%e5%a0%a12022051801-pc.jpg" class="card-img-top" alt="青花椒卡啦雞腿堡">
            <div class="card-body">
                <h5 class="card-title">青花椒香麻咔啦雞腿堡</h5>
                <p class="card-text">
                <div>$125</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 49";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>


        <!-- 單點主餐結束 -->
    </div>
    <!-- 蛋塔開始 -->
    <h1 id="single_2">蛋塔</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%aa%bf%e7%9a%ae%e6%90%97%e8%9b%8b%e7%a6%ae%e7%9b%9220231023-pc.jpg" class="card-img-top" alt="調皮搗蛋禮盒">
            <div class="card-body">
                <h5 class="card-title">調皮搗蛋蛋塔禮盒</h5>
                <p class="card-text">
                <div>調皮搗蛋蛋塔 x 6</div>
                <div>$288</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 50";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%aa%bf%e7%9a%ae%e6%90%97%e8%9b%8b%e7%a6%ae%e7%9b%92-%e9%9b%99%e8%89%b220231023-pc.jpg" class="card-img-top" alt="調皮搗蛋禮盒-雙色">
            <div class="card-body">
                <h5 class="card-title">調皮搗蛋蛋塔雙色禮盒</h5>
                <p class="card-text">
                <div>原味蛋塔 x 3</div>
                <div>調皮搗蛋蛋塔 x 3</div>
                <div>$264</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 51";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%aa%bf%e7%9a%ae%e6%90%97%e8%9b%8b-%e5%a5%bd%e6%99%82%e5%85%8920231023-pc.jpg" class="card-img-top" alt="調皮搗蛋-好時光">
            <div class="card-body">
                <h5 class="card-title">調皮搗蛋好時光套餐</h5>
                <p class="card-text">
                <div>原味蛋塔 x 1</div>
                <div>調皮搗蛋蛋塔 x 1</div>
                <div>無糖綠茶(中) x 1</div>
                <div>$139</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 52";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%aa%bf%e7%9a%ae%e6%90%97%e8%9b%8b-%e5%96%ae%e9%a1%8620231023-pc.jpg" class="card-img-top" alt="調皮搗蛋-單顆">
            <div class="card-body">
                <h5 class="card-title">調皮搗蛋蛋塔</h5>
                <p class="card-text">
                <div>$53</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 53";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%8e%9f%e5%91%b3%e8%9b%8b%e6%92%bb-pc.jpg" class="card-img-top" alt="原味蛋撻">
            <div class="card-body">
                <h5 class="card-title">原味蛋撻</h5>
                <p class="card-text">
                <div>$45</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 54";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>



    </div>
    <!-- 蛋塔結束 -->
    </div>
    <!-- 附餐/點心開始 -->
    <h1 id="single_3">附餐/點心</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%92%e6%9e%9c%e7%99%be%e9%a6%99%e6%9e%9c%e5%86%b0%e6%b7%87%e6%b7%8b%e5%a4%a7%e7%a6%8f%e7%a6%ae%e7%9b%928%e5%85%a520230517-pc.jpg" class="card-img-top" alt="芒果百香果冰淇淋大福禮盒8入">
            <div class="card-body">
                <h5 class="card-title">芒果百香果冰淇淋大福禮盒8入</h5>
                <p class="card-text">
                <div>芒果百香果冰淇淋大福 x 8</div>
                <div>$399</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 55";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e9%9b%99%e8%89%b2%e5%86%b0%e6%b7%87%e6%b7%8b%e5%a4%a7%e7%a6%8f%e7%a6%ae%e7%9b%928%e5%85%a520230517-pc.jpg" class="card-img-top" alt="雙色冰淇淋大福禮盒8入">
            <div class="card-body">
                <h5 class="card-title">雙色冰淇淋大福禮盒8入</h5>
                <p class="card-text">
                <div>草莓起司冰淇淋大福 x 4</div>
                <div>芒果百香果冰淇淋大福 x 4</div>
                <div>$375</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 56";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e8%8a%92%e6%9e%9c%e7%99%be%e9%a6%99%e6%9e%9c%e5%86%b0%e6%b7%87%e6%b7%8b%e5%a4%a7%e7%a6%8f20230517-pc.jpg" class="card-img-top" alt="芒果百香果冰淇淋大福">
            <div class="card-body">
                <h5 class="card-title">芒果百香果冰淇淋大福</h5>
                <p class="card-text">
                <div>$50</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 57";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">


        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e6%af%94%e5%8f%b8%e5%90%89%2b%e7%99%bd%e7%9b%a420231127-pc.jpg" class="card-img-top" alt="金黃比司吉">
            <div class="card-body">
                <h5 class="card-title">金黃比司吉</h5>
                <p class="card-text">
                <div>$59</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 60";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%b6%93%e5%85%b8%e7%8e%89%e7%b1%b3-pc.jpg" class="card-img-top" alt="經典玉米">
            <div class="card-body">
                <h5 class="card-title">經典玉米</h5>
                <p class="card-text">
                <div>$33</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 61";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>


        <!-- 附餐/點心結束 -->
    </div>
    <!-- 飲料/湯品開始 -->
    <h1 id="single_4">飲料/湯品</h1>

    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%8e%89%e7%b1%b3%e6%bf%83%e6%b9%af(%e5%b0%8f)20220421-pc.jpg" class="card-img-top" alt="玉米濃湯(小)">
            <div class="card-body">
                <h5 class="card-title">玉米濃湯(小)</h5>
                <p class="card-text">
                <div>響應環保不需湯匙 x 1</div>
                <div>$40</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 62";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%8e%89%e7%b1%b3%e6%bf%83%e6%b9%af(%e5%a4%a7)20220421-pc.jpg" class="card-img-top" alt="玉米濃湯(大)">
            <div class="card-body">
                <h5 class="card-title">玉米濃湯(大)</h5>
                <p class="card-text">
                <div>響應環保不需湯匙 x 1</div>
                <div>$52</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 63";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%86%b0%e7%be%a9%e5%bc%8f%e5%92%96%e5%95%a1-pc.jpg" class="card-img-top" alt="冰義式咖啡">
            <div class="card-body">
                <h5 class="card-title">冰義式咖啡</h5>
                <p class="card-text">
                <div>$69</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 64";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

    </div>


    <div class="card-group">

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e5%86%b0%e7%be%a9%e5%bc%8f%e6%8b%bf%e9%90%b5-pc.jpg" class="card-img-top" alt="冰義式拿鐵">
            <div class="card-body">
                <h5 class="card-title">冰義式拿鐵</h5>
                <p class="card-text">
                <div>$80</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 65";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>

        <div class="hotmeal_card" style="width: 18rem;">
            <img src="https://kfcoosfs.kfcclub.com.tw/%e7%86%b1%e7%be%a9%e5%bc%8f%e5%92%96%e5%95%a1(%e5%b0%8f)-pc.jpg" class="card-img-top" alt="熱義式咖啡(小)">
            <div class="card-body">
                <h5 class="card-title">熱義式咖啡(小)</h5>
                <p class="card-text">
                <div>$36</div>
                </p>
                <?php
                $sql = "SELECT * FROM `combo` WHERE `combo_id`= 66";
                $result = mysqli_query($link, $sql);

                if ($result) {
                    $row = mysqli_fetch_assoc($result);
                    // 在這裡使用 $row 中的資料來顯示內容

                    // 使用 combo_id 參數生成訂購連結
                    $comboId = $row['combo_id'];
                    // $_SESSION['combo_id'] = $comboId;

                    echo '<a href="hotdeal_1_1.php?combo_id=' . $comboId . '" class="btn btn-danger">訂購</a>';
                } else {
                    echo "ERROR: Could not execute $sql. " . mysqli_error($link);
                }
                // echo '<a href="hotdeal_1_1.html" class="btn btn-danger">訂購</a>'
                ?>
            </div>
        </div>




        <!-- 飲料/湯品結束 -->

    </div>




</body>

</html>