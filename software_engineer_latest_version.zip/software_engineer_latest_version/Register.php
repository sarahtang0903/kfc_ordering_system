<?php
session_start();
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $account = $_POST['Name'];
    $password1 = $_POST['Password'];
    $confirm_password = $_POST['PasswordC'];
    $mobilePhone = $_POST['MobilePhone'];
    $email = $_POST['Email'];
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $birthdayY = $_POST['BirthdayY'];
    $birthdayM = $_POST['BirthdayM'];
    $birthdayD = $_POST['BirthdayD'];
    $userEnteredCaptcha = $_POST['Captcha'];

    if ($_SESSION['captcha'] != $userEnteredCaptcha) {
        echo '<p>驗證碼錯誤，請重新輸入。</p>';
    } else {
        $servername = "localhost";
        $username = "root";
        $password = "";
        $database = "software_db";

        // 建立與資料庫的連接
        $link = mysqli_connect($servername, $username, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
        mysqli_select_db($link, $database); //選擇資料庫
        mysqli_query($link, "SET NAMES utf8"); //設定編碼


        $check = "SELECT * FROM `member` WHERE `member_phone`='$mobilePhone' OR `member_email`='$email'";
        $check_result = mysqli_query($link, $check);

        if (mysqli_num_rows($check_result) == 0) {
            if ($password1 == $confirm_password) {
                if (strlen($password1) >= 8) {
                    //插入資料庫
                    $sql = "INSERT INTO member (member_name, member_pwd, member_email, member_phone, gender, birthday)
                            VALUES ('$account', '$password1','$email','$mobilePhone','$gender','$birthdayY-$birthdayM-$birthdayD')";
                    if (mysqli_query($link, $sql)) {
                        header("Location: initial.php");
                        exit();
                    } else {
                        echo '<p>插入資料庫失敗: ' . mysqli_error($link) . '</p>';
                    }
                } else {
                    echo '<p>密碼不得小於8個字元。</p>';
                }
            } else {
                echo '<p>註冊失敗，請檢查密碼和確認密碼。</p>';
            }
        } else {
            echo '<p>該帳號已有人使用!</p>';
        }
        // 關閉資料庫連接
        mysqli_close($link);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>肯德基會員註冊</title>
    <link rel="stylesheet" href="Register.css">
    <style>
        /* 在這裡添加樣式（如果有需要） */
    </style>
</head>

<body>
    <header>
        <div class="header-top">
            <div class="logo">
                <a href="home_page.php">
                    <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
                </a>
            </div>
            <div class="user-controls">
                <button id="unsetbutton">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="Member Icon" width="20" height="20">
                </button>
                <div class="cart-icon">
                    <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="Shopping Cart Icon" width="50" height="50"></a>
                </div>
            </div>
        </div>
        <nav class="header-bottom">
            <a href="hotdeal.php">熱門優惠</a>
            <a href="individual.php">個人餐</a>
            <a href="many.php">多人餐</a>
            <a href="breakfast.php">早餐</a>
            <a href="single.php">單點</a>
        </nav>
    </header>
    <script>
        document.getElementById("unsetbutton").addEventListener("click", function() {
            window.location.href = "unset_session.php";
        });
    </script>


    <div class="change-details__form" style="display:block" name="Register" id="Registerform">
        <div class="content" datatag="Member">
            <h1>加入會員</h1>

            <form action="Register.php" class="register" method="POST">
                <div id="RegisterStep2" style="display:block">

                    <div class="input-wrapper">
                        <input type="text" id="MobilePhone" name="MobilePhone" onchange="changePhoneReset()" maxlength="10" placeholder="手機">
                        <span id="ST_ID" style="display:none"></span>
                    </div>
                    <div class="memberInputbox">
                        <div class="input-wrapper  memberMail-width">
                            <input type="text" id="Email" name="Email" type="text" maxlength="60" placeholder="電子信箱(Email)">
                        </div>

                    </div>
                    <p>
                        (建議勿使用 Yahoo、PChome 或 Hotmail 信箱，避免發生收不到重要通知，或信件被歸類於垃圾郵件的狀況。)
                    </p>
                    <div class="input-wrapper">
                        <input type="password" id="Password" name="Password" maxlength="20" autocomplete="off" placeholder="會員密碼">
                    </div>
                    <p>(密碼限8~20個字元，必須包含英文字母及數字)</p>
                    <div class="input-wrapper">
                        <input type="password" maxlength="20" id="PasswordC" name="PasswordC" autocomplete="off" placeholder="確認密碼">
                    </div>
                    <div class="input-wrapper">
                        <input type="text" id="Name" name="Name" placeholder="姓名">
                    </div>

                    <p>性別</p>
                    <div class="gender">
                        <label><input type="radio" name="gender" value="先生"> 先生</label>
                        <label><input type="radio" name="gender" value="小姐"> 小姐</label>
                        <!-- 可以加入其他性別選項 -->
                    </div>

                    <p>生日</p>
                    <div class="birthday">
                        <div class="input-wrapper">
                            <select id="BirthdayY" name="BirthdayY">
                                <option value="">年</option>
                                <option value="2002">2002</option>
                                <option value="2003">2003</option>
                                <option value="2004">2004</option>
                                <option value="2005">2005</option>
                                <option value="2006">2006</option>
                                <option value="2007">2007</option>
                                <option value="2008">2008</option>
                                <option value="2009">2009</option>
                                <option value="2010">2010</option>
                                <option value="2012">2012</option>
                                <option value="2013">2013</option>
                                <!-- 加入其他年份選項 -->
                            </select>
                        </div>
                        <div class="input-wrapper">
                            <select id="BirthdayM" name="BirthdayM">
                                <option value="">月</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <!-- 加入其他月份選項 -->
                            </select>
                        </div>
                        <div class="input-wrapper">
                            <select id="BirthdayD" name="BirthdayD">
                                <option value="">日</option>
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                                <option>11</option>
                                <option>12</option>
                                <option>13</option>
                                <option>14</option>
                                <option>15</option>
                                <option>16</option>
                                <option>17</option>
                                <option>18</option>
                                <option>19</option>
                                <option>20</option>
                                <option>21</option>
                                <option>22</option>
                                <option>23</option>
                                <option>24</option>
                                <option>25</option>
                                <option>26</option>
                                <option>27</option>
                                <option>28</option>
                                <option>29</option>
                                <option>30</option>
                                <option>31</option>
                            </select>
                        </div>
                    </div>

                    <div class="memberInputbox">
                        <div class="input-wrapper">
                            <input type="text" id="txtCaptcha" name="Captcha" placeholder="請輸入驗證碼" required="1" maxlength="4">
                            <span for="Captcha" style="display:none">請輸入驗證碼</span>
                        </div>
                        <div class="verification_code">
                            <img src="" id="imgVerification" />
                        </div>
                        <div class="verification_display">
                            <span id="displayCaptcha"></span>
                        </div>
                        <div>
                            <button class="btn white btn-spacing" onclick="refreshCaptcha(); Func_Analytic_Click('刷新驗證碼', 'Login')">
                                <span>刷新驗證碼</span>
                            </button>
                        </div>
                    </div>
                    <script>
                        refreshCaptcha();

                        function getRandom4Digit() {
                            return Math.floor(1000 + Math.random() * 9000);
                        }

                        function refreshCaptcha() {
                            var randomCaptcha = getRandom4Digit();
                            document.getElementById("displayCaptcha").textContent = randomCaptcha;

                            // 发送 AJAX 请求来更新验证码
                            fetch('refresh_captcha.php', { // 创建一个新的 PHP 文件来处理验证码刷新
                                    method: 'POST',
                                    headers: {
                                        'Content-Type': 'application/x-www-form-urlencoded',
                                    },
                                    body: 'captcha=' + encodeURIComponent(randomCaptcha), // 将随机生成的验证码发送到后端
                                })
                                .then(response => {
                                    // 在这里处理响应（如果需要的话）
                                })
                                .catch(error => {
                                    console.error('刷新验证码时发生错误:', error);
                                });
                        }
                    </script>


                    <input type="submit" name="Register" class="btn block btn-spacing" onclick="ShowRegister()" value="確認送出">

                    <script>
                        // 定義 ShowRegister 函數在全局作用域
                        function ShowRegister() {
                            console.log("ShowRegister function is called.");
                            var form = document.forms["Register"];
                            var mobilePhone = document.getElementById("MobilePhone").value;
                            var email = document.getElementById("Email").value;
                            var password = document.getElementById("Password").value;
                            var confirmPassword = document.getElementById("PasswordC").value;
                            var name = document.getElementById("Name").value;
                            var gender = document.querySelector('input[name="gender"]:checked');
                            var birthdayY = document.getElementById("BirthdayY").value;
                            var birthdayM = document.getElementById("BirthdayM").value;
                            var birthdayD = document.getElementById("BirthdayD").value;
                            var validateCode = document.getElementById("txtCaptcha").value;
                            var actualCaptcha = document.getElementById("displayCaptcha").textContent;

                            var regist = true; // 設定預設值為 true

                            if (!mobilePhone || !email || !password || !confirmPassword || !name || !gender || !gender.value || !birthdayY || !birthdayM || !birthdayD || !validateCode) {
                                regist = false; // 如果有缺少資料，設定為 false
                            }
                            if (password.length < 8) {
                                alert("加入失敗，密碼需至少 8 個字元!");
                                regist = false;
                            }
                            if (mobilePhone.length != 10) {
                                alert("加入失敗，手機格式不正確");
                                regist = false;
                            }
                            if (!isValidEmail(email)) {
                                alert("加入失敗，請輸入有效的電子郵件地址!");
                                regist = false;
                            }
                            if (validateCode !== actualCaptcha) {
                                alert("加入失敗，請輸入正確的驗證碼!");
                                regist = false;
                            }

                            if (regist) {
                                alert("加入成功!")
                                setTimeout(function() {
                                    redirectToLogin();
                                }, 2000);

                            } else {
                                alert("加入失敗，請正確填寫資料!")
                                document.getElementById("Password").value = "";
                                document.getElementById("PasswordC").value = "";
                                // 刷新驗證碼
                                refreshCaptcha();
                            }
                        }
                    </script>
                    <script>
                        function isValidEmail(email) {
                            // 簡單的正則表達式檢查
                            var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
                            return emailPattern.test(email);
                        }
                    </script>
                    <script>
                        function redirectToOrder() {
                            window.location.href = 'Order.html';
                        }

                        function redirectToLogin() {
                            window.location.href = '/kfc/initial.php';
                        }

                        function redirectToRegister() {
                            window.location.href = '/kfc/Register.php';
                        }
                    </script>

                </div>
            </form>
        </div>
    </div>

</body>

</html>