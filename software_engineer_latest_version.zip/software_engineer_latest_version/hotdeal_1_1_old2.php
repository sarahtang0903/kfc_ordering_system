<?php
// header('Content-Type: application/json;charset=utf-8');
session_start();

$host = "localhost";
$user = "root";
$password = "";
$database = "software_engineer_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼

// $comboId = isset($_GET['combo_id']) ? $_GET['combo_id'] : 1;
// $comboId = isset($_GET['combo_id']) ? $_GET['combo_id'] : 1;
$comboId = $_SESSION['combo_id'];

// echo 
var_dump($comboId);


$sql_combo = "SELECT * from ((combination 
join combo on combination.combo_id = combo.combo_id) 
join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
join meals on meals.cartetype_id = combination.cartetype_id 
where combination.combo_id = $comboId";

$result_combo = mysqli_query($link, $sql_combo);
$row_combo = mysqli_fetch_assoc($result_combo);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // 获取从前端发送的数据
    // $mealList = $_POST['mealList'];
    // var_dump("mealList", $mealList);
    $mealListData = json_decode($_POST['mealList']);
    var_dump("mealllll", $mealListData);
    $combo_name = $row_combo['combo_name'];
    $mealTotalPrice = $_POST['mealTotalPrice'];
    var_dump("totallllll:", $mealTotalPrice);

    foreach ($mealListData as $meal) {
        $sql = "INSERT INTO shoppingcart (shoppingcart_meals_name, shopping_meals_content, shoppongcart_meals_price)
        VALUES ('$combo_name', '$meal', ' $mealTotalPrice')";
    }



    // // 将数据插入到数据库
    // $sql = "INSERT INTO your_table_name (meal_name) VALUES ('$mealList')";
    // if ($conn->query($sql) === TRUE) {
    //     echo "Record inserted successfully";
    // } else {
    //     echo "Error inserting record: " . $conn->error;
    // }
    header("Location: hotdeal.php");
    exit();  // Ensure that no more output is sent
}



?>

<!DOCTYPE html>
<html lang="en">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="home_page.css">
</head>

<body>
    <header>
        <div class=logo>
            <a href="home_page.php">
                <img src="https://kfcoosfs.kfcclub.com.tw/logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
            </a>
        </div>
        <div class=member>
            <button>
                <a href="#">
                    <img src="https://kfcoosfs.kfcclub.com.tw/member_grey.png" alt="KFC Logo" width="20" height="20">
                </a>
            </button>
        </div>
    </header>

    <nav>
        <a href="hotdeal.html">熱門優惠</a>
        <a href="individual.html" style="color: red;">個人餐</a>
        <a href="many.html">多人餐</a>
        <a href="breakfast.html">早餐</a>
        <a href="#single">單點</a>
    </nav>

    <div> </div>
    <main class="hub-spoke-flow">
        <div class="content">
            <div class="combo-flow__image">
                <div class="img-md">

                    <img class="lazy" alt="肯德基 雙層咔啦雞腿堡M經典餐" src="<?php echo $row_combo["combo_picture"] ?>">
                </div>
                <div class="mealsCartList">
                    <h1 class="mealsTitle">
                        <span class="smaller "><?php echo $row_combo['combo_name'] ?></span>
                    </h1>

                    <div class="front-bold front_color_gray" style="margin-bottom: 8px;">
                    </div>

                    <!-- <div id="divMealListText"> -->
                    <?php
                    $mealList = $row_combo['combo_content'];

                    // 使用某个字符（例如 'x'）分割字符串为数组
                    $mealsArray = explode('x1', $mealList);

                    // 输出数组
                    echo '<div id="divMealListText">';
                    foreach ($mealsArray as $meal) {
                        // 去除两端的空格并创建相应的 HTML 元素
                        $meal = trim($meal);
                        if (!empty($meal)) {
                            echo '<p class="price-row mealList"><span>' . $meal . ' x 1</span></p>';
                        }
                    }
                    echo '<p> </p>';
                    echo '</div>';
                    // $mealList = $row_combo['combo_content'];
                    // $mealsArray = explode('1', $mealList);
                    // var_dump($mealList);
                    // var_dump($mealsArray);

                    ?>
                    <!-- <p class="price-row mealList">
                            <span>雙層咔啦雞腿堡 x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>香酥脆薯(中) x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>百事可樂(中) x 1</span>
                        </p> -->
                </div>
                <hr>
                <p class="price-row mealList">
                    <span>餐點小計</span>
                    <span class="small-price">
                        $
                        <span id="MealTotalPrice"><?php echo $row_combo["combo_price"] ?></span>
                    </span>
                </p>

            </div>
        </div>

        <div class="combo-flow__imformation">
            <div calss="card_dispaly">

                <?php
                // $sql_content = "SELECT * from ((combination 
                // join combo on combination.combo_id = combo.combo_id) 
                // join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                // join meals on meals.cartetype_id = combination.cartetype_id 
                // where combination.combo_id = $comboId and combination.meals_id = meals.meals_id";

                // $result_content = mysqli_query($link, $sql_content);

                // $sql = "select * from ((combination 
                // join combo on combination.combo_id = combo.combo_id) 
                // join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                // join meals on meals.cartetype_id = combination.cartetype_id 
                // where combination.combo_id = $comboId";
                // $result = mysqli_query($link, $sql);

                // $row = mysqli_fetch_assoc($result);


                // echo '<div class="card mb-3" style="max-width: 540px;">';
                // echo '    <div class="row g-0">';
                // echo '        <div class="col-md-4">';
                // echo '            <img src="' . $row_combo['combo_picture'] . '" class="img-fluid rounded-start" alt="' . $row_combo['meals_name'] . '">';
                // echo '        </div>';
                // echo '        <div class="col-md-8">';
                // echo '            <div class="card-body">';
                // echo '                <h5 class="card-title">主餐</h5>';
                // echo '                <p class="card-text">' . $row_combo['combo_name'] . 'x1</p>';
                // echo '            </div>';
                // echo '        </div>';
                // echo '    </div>';
                // echo '</div>';
                // // $carttype = $row['cartetype_id'];
                // // $row_content = mysqli_fetch_assoc($result_content)
                // while ($row_content = mysqli_fetch_assoc($result_content)) {
                //     $carttype = $row_combo['cartetype_id'];
                //     // if (strpos($row['combo_content'], $row['meals_name']) !== false) {
                //     if ($carttype == 1) {

                //         echo '<div class="card mb-3" style="max-width: 540px;">';
                //         echo '    <div class="row g-0">';
                //         echo '        <div class="col-md-4">';
                //         echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                //         echo '        </div>';
                //         echo '        <div class="col-md-8">';
                //         echo '            <div class="card-body">';
                //         echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                //         echo '                <p class="card-text">' . $row_content['meals_name'] . 'x1</p>';

                //         echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                //         echo '            更換';
                //         var_dump($carttype);
                //         echo '            <span class="chevron-inline">';
                //         echo '                                        </span>';
                //         echo '        </a>';
                //         echo '            </div>';
                //         echo '        </div>';
                //         echo '    </div>';
                //         echo '</div>';
                //     } else if ($carttype == 2) {

                //         echo '<div class="card mb-3" style="max-width: 540px;">';
                //         echo '    <div class="row g-0">';
                //         echo '        <div class="col-md-4">';
                //         echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                //         echo '        </div>';
                //         echo '        <div class="col-md-8">';
                //         echo '            <div class="card-body">';
                //         echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                //         echo '                <p class="card-text">' . $row_content['meals_name'] . 'x1</p>';

                //         echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                //         echo '            更換';
                //         var_dump($carttype);
                //         echo '            <span class="chevron-inline">';
                //         echo '                                        </span>';
                //         echo '        </a>';
                //         echo '            </div>';
                //         echo '        </div>';
                //         echo '    </div>';
                //         echo '</div>';
                //     } else if ($carttype == 3) {

                //         echo '<div class="drinkContent">';
                //         echo '<div class="card mb-3" style="max-width: 540px;">';
                //         echo '    <div class="row g-0">';
                //         echo '        <div class="col-md-4">';
                //         echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                //         echo '        </div>';
                //         echo '        <div class="col-md-8">';
                //         echo '            <div class="card-body">';
                //         echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                //         echo '                <p class="card-text" id="drinkDescription" >' . $row_content['meals_name'] . 'x1</p>';

                //         echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                //         echo '            更換';
                //         var_dump($carttype);
                //         echo '            <span class="chevron-inline">';
                //         echo '                                        </span>';
                //         echo '        </a>';
                //         echo '            </div>';
                //         echo '        </div>';
                //         echo '    </div>';
                //         echo '</div>';
                //         echo '</div>';
                //     } else if ($carttype == 4) {

                //         echo '<div class="frenchContent">';
                //         echo '<div class="card mb-3" style="max-width: 540px;">';
                //         echo '    <div class="row g-0">';
                //         echo '        <div class="col-md-4">';
                //         echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                //         echo '        </div>';
                //         echo '        <div class="col-md-8">';
                //         echo '            <div class="card-body">';
                //         echo '                <h5 class="card-title" >' . $row_content['cartetype_name'] . '</h5>';
                //         echo '                <p class="card-text" id="frenchDescription">' . $row_content['meals_name'] . 'x1</p>';

                //         echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_french()">';

                //         echo '            更換';
                //         var_dump($carttype);
                //         echo '            <span class="chevron-inline">';
                //         echo '                                        </span>';
                //         echo '        </a>';
                //         echo '            </div>';
                //         echo '        </div>';
                //         echo '    </div>';
                //         echo '</div>';
                //         echo '</div>';
                //     }

                $sql_content = "SELECT * from ((combination 
                    join combo on combination.combo_id = combo.combo_id) 
                    join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                    join meals on meals.cartetype_id = combination.cartetype_id 
                    where combination.combo_id = $comboId and combination.meals_id = meals.meals_id";

                $result_content = mysqli_query($link, $sql_content);

                $sql = "select * from ((combination 
                    join combo on combination.combo_id = combo.combo_id) 
                    join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                    join meals on meals.cartetype_id = combination.cartetype_id 
                    where combination.combo_id = $comboId";
                $result = mysqli_query($link, $sql);

                $row = mysqli_fetch_assoc($result);


                echo '<div class="card mb-3" style="max-width: 540px;">';
                echo '    <div class="row g-0">';
                echo '        <div class="col-md-4">';
                echo '            <img src="' . $row_combo['combo_picture'] . '" class="img-fluid rounded-start" alt="' . $row_combo['meals_name'] . '">';
                echo '        </div>';
                echo '        <div class="col-md-8">';
                echo '            <div class="card-body">';
                echo '                <h5 class="card-title">主餐</h5>';
                echo '<div class="card-text update-me">';
                echo '                <p class="card-text" id="card-text-left">' . $row_combo['combo_name'] . 'x1</p>';
                echo '<div/>';
                echo '            </div>';
                echo '        </div>';
                echo '    </div>';
                echo '</div>';
                // $carttype = $row['cartetype_id'];
                // $row_content = mysqli_fetch_assoc($result_content)
                // $carttype = $row_combo['cartetype_id'];
                // $initialCarttype = $row_combo['cartetype_id'];
                while ($row_content = mysqli_fetch_assoc($result_content)) {
                    $carttype = $row_content['cartetype_id'];
                    // $carttype = $initialCarttype; // 设置为初始值

                    // var_dump("where", $carttype);
                    // if (strpos($row['combo_content'], $row['meals_name']) !== false) {
                    if ($carttype == 1) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '        <p class="card-text" id = "chickenDescription">' . $row_content['meals_name'] . 'x 1</p>';
                        echo '</div>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_chicken()">';

                        echo '            更換';
                        var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 2;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 2) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id = "eggDescription">' . $row_content['meals_name'] . 'x 1</p>';
                        echo '<div/>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_egg()">';

                        echo '            更換';
                        var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 3;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 3) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id="drinkDescription" >' . $row_content['meals_name'] . 'x 1</p>';
                        echo '<div/>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                        echo '            更換';
                        var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype = 4;
                        // break;
                        // $carttype++;
                    } else if ($carttype == 4) {

                        echo '<div class="card mb-3" style="max-width: 540px;">';
                        echo '    <div class="row g-0">';
                        echo '        <div class="col-md-4">';
                        echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                        echo '        </div>';
                        echo '        <div class="col-md-8">';
                        echo '            <div class="card-body">';
                        echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                        // echo '                <p class="card-text">' . $row_content['meals_name'] . 'x1</p>';
                        echo '<div class="card-text update-me">';
                        echo '                <p class="card-text" id =frenchDescription>' . $row_content['meals_name'] . 'x 1</p>';
                        echo '</div>';

                        echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog_french()">';

                        echo '            更換';
                        var_dump($carttype);
                        echo '            <span class="chevron-inline">';
                        echo '                                        </span>';
                        echo '        </a>';
                        echo '            </div>';
                        echo '        </div>';
                        echo '    </div>';
                        echo '</div>';
                        // $carttype++;
                        // break;
                    }
                    // $carttype++;
                    // }

                    // echo '<div class="card mb-3" style="max-width: 540px;">';
                    // echo '    <div class="row g-0">';
                    // echo '        <div class="col-md-4">';
                    // echo '            <img src="' . $row_content['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row_content['meals_name'] . '">';
                    // echo '        </div>';
                    // echo '        <div class="col-md-8">';
                    // echo '            <div class="card-body">';
                    // echo '                <h5 class="card-title">' . $row_content['cartetype_name'] . '</h5>';
                    // echo '                <p class="card-text">' . $row_content['meals_name'] . 'x1</p>';

                    // echo '<a href="?combo_id=' . $comboId . '&cartetype_id=' . $row_content['cartetype_id'] . '#cartetype_id=' . $row_content['cartetype_id'] . '" class="group-item__change" onclick="showReplacementDialog()">';

                    // echo '            更換';
                    // echo '            <span class="chevron-inline">';
                    // echo '                                        </span>';
                    // echo '        </a>';
                    // echo '            </div>';
                    // echo '        </div>';
                    // echo '    </div>';
                    // echo '</div>';
                }



                ?>


                <div class="amount-price">
                    <div class="incrementer">
                        <button class="js-dec" onclick="decrementQuantity()">
                            <img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">
                        </button>

                        <input title="Quantity" type="text" readonly value="1" id="txtQuantity">

                        <button class="js-inc" onclick="incrementQuantity()">
                            <img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">
                        </button>

                        <span class="small-small-price">
                            <span class="singleM">餐點 </span>
                            $
                            <span class="integer">
                                <span id="MealTotalPriceNoDiscount_none" style="display: none;"><?php echo $row_combo["combo_price"] ?></span>

                                <span id="MealTotalPriceNoDiscount"><?php echo $row_combo["combo_price"] ?></span>

                            </span>
                        </span>
                    </div>
                </div>
                <hr>
                <div>
                    <button type="button" class="btn-white " onclick="">
                        <span>回到菜單</span>
                    </button>
                    <!-- <button type="button" class="btn-red " onclick="">
                        <span>加入餐車</span>
                    </button> -->
                    <form id="mealForm" action="hotdeal_1_1.php" method="POST">
                        <input type="hidden" id="mealListInput" name="mealList" value="">
                        <input type="hidden" id="mealTotalPriceInput" name="mealTotalPrice" value="">
                        <input type="submit" value="加入餐車" class="bbb">
                        <!-- <button type="submit" class="btn-red">
                                <span>加入餐車</span>
                            </button> -->
                    </form>
                </div>

            </div>
        </div>

        <script src="meal.js">
        </script>
    </main>






</body>



<?php
$carttype = $_GET['cartetype_id'];
var_dump($carttype);

$sql = "select * from ((combination 
   join combo on combination.combo_id = combo.combo_id) 
   join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
   join meals on meals.cartetype_id = combination.cartetype_id 
   where combination.combo_id = $comboId
   and cartetype.cartetype_id = $carttype";

$result = mysqli_query($link, $sql);
$row = mysqli_fetch_assoc($result);

$sql_change_meals = "select * from ((combination 
   join combo on combination.combo_id = combo.combo_id) 
   join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
   join meals on meals.cartetype_id = combination.cartetype_id 
   where combination.combo_id = $comboId
   and cartetype.cartetype_id = $carttype";



// var_dump($carttype);

$result_change_meals = mysqli_query($link, $sql_change_meals);
// var_dump($result_change_meals);

$index = 1;
if ($carttype == 1) {
    echo '<div id="replacementDialog_chicken" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_chicken(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_chicken(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_chicken()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_chicken()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 2) {

    echo '<div id="replacementDialog_egg" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";

    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_Egg(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_Egg(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_chicken(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_Egg(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_egg()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_egg()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 3) {
    echo '<div id="replacementDialog" style="display: none;"> ';
    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="image\inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="image\inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
} else if ($carttype == 4) {
    echo '<div id="replacement_french_Dialog" style="display: none;">';

    echo "<h3>{$row['cartetype_name']} </h3>";
    echo '<h5 id="replacementQuantity">共可選1項</h5>';
    echo '<div class="combo-flow__imformation" id="replacementItems">';
    echo '<div class="card_dispaly">';
    echo '<div class="card mb-3" style="max-width: 540px;">';
    echo '<div class="row g-0">';
    echo '<div class="col-md-4">';
    echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    echo '<div class="incrementer-right">';
    echo '<button class="js-dec" onclick="updateQuantity_French(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
    echo '</button>';
    echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
    var_dump($index);
    echo '<button class="js-inc" onclick="updateQuantity_French(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">';
    echo '</button>';
    echo '</div>';
    echo '</div>';
    $index += 1;
    while ($row = mysqli_fetch_assoc($result)) {

        echo '<div class="card_dispaly">';
        echo '<div class="card mb-3" style="max-width: 540px;">';
        echo '<div class="row g-0">';
        echo '<div class="col-md-4">';
        echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
        echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
        echo '<div class="incrementer-right">';
        echo '<button class="js-dec" onclick="updateQuantity_French(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
        echo '</button>';
        echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
        var_dump($index);
        echo '<button class="js-inc" onclick="updateQuantity_French(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
        echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">';
        echo '</button>';
        echo '</div>';
        echo '</div>';
        $index += 1;
    }
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '<div>';
    echo '<button type="button" class="btn-red " onclick=" confirmReplacement_french()">';
    echo '<span>確認餐點</span>';
    echo '</button>';
    echo '<button type="button" class="btn-white " onclick="cancelReplacement_french()">';
    echo '<span>取消</span>';
    echo '</button>';
    echo '</div>';
    echo '</div>';
}


// echo "<h3>{$row['cartetype_name']} </h3>";
// echo '<h5 id="replacement_french_Dialog">共可選1杯</h5>';
// echo '<div class="combo-flow__imformation" id="replacementItems">';
// while ($row = mysqli_fetch_assoc($result)) {

//     echo '<div class="card_dispaly">';
//     echo '<div class="card mb-3" style="max-width: 540px;">';
//     echo '<div class="row g-0">';
//     echo '<div class="col-md-4">';
//     echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
//     echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
//     echo '<div class="incrementer-right">';
//     echo '<button class="js-dec" onclick="updateQuantity_French(\'Del\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
//     echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-minus.png" alt="Decrement">';
//     echo '</button>';
//     echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_' . $index . '">';
//     var_dump($index);
//     echo '<button class="js-inc" onclick="updateQuantity_French(\'Add\', \'' . $row['meals_id'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
//     echo '<img src="https://storage.googleapis.com/kfcoosfs/inc-plus.png" alt="Increment">';
//     echo '</button>';
//     echo '</div>';
//     echo '</div>';
//     $index += 1;
// }
// echo '</div>';
// echo '</div>';
// echo '</div>';


?>
<!-- <h3>飲料</h3> -->

<!-- <h5 id="replacementQuantity">共可選1杯</h5>
    <div class="combo-flow__imformation" id="replacementItems">
        <div calss="card_dispaly">


            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="image\M-可樂中-210512.png" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">百事可樂(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','百事可樂','txtQuantity_cola', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="1" id="txtQuantity_cola">

                            <button class="js-inc" onclick="updateQuantity('Add','百事可樂','txtQuantity_cola', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="image\M-七喜(中)-210608.png" class="img-fluid rounded-start" alt="七喜(中)">
                        <p class="hidden-card-text">七喜(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','七喜','txtQuantity_seven_up','replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_seven_up">

                            <button class="js-inc" onclick="updateQuantity('Add','七喜','txtQuantity_seven_up','replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div> -->


<hr>
<!-- <div>
        <button type="button" class="btn-red " onclick=" confirmReplacement()">
            <span>確認餐點</span>
        </button>
        <button type="button" class="btn-white " onclick="cancelReplacement()">
            <span>取消</span>
        </button>
    </div> -->


</div>
</div>




</div>

</html>