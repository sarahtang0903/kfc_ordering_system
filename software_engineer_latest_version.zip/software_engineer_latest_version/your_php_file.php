<?php
// session_start();
session_start();
header('Content-Type: application/json');
// $carttype = $_GET['Mealtype'];
$carttype = isset($_GET['Mealtype']) ? $_GET['Mealtype'] : '';
$_SESSION['cartetype_id'] = $carttype;
var_dump($carttype);
echo json_encode(["carttype" => $carttype]);
    // // header('Content-Type: application/json');

    // $host = "localhost";
    // $user = "root";
    // $password = "";
    // $database = "software_engineer_db";
    // $link = mysqli_connect($host, $user, $password, $database) or die(json_encode(['error' => 'Database connection failed']));

    // mysqli_select_db($link, $database);
    // mysqli_query($link, "SET NAMES utf8");

    // $carttype = isset($_GET['cartetype_id']) ? $_GET['cartetype_id'] : '';
    // var_dump($carttype);
    // $_SESSION['cartetype_id'] = $carttype;

    // $sql = "select * from ((combination 
    //     join combo on combination.combo_id = combo.combo_id) 
    //     join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
    //     join meals on meals.cartetype_id = combination.cartetype_id 
    //     where combination.combo_id = $comboId
    //     and cartetype.cartetype_id = $carttype";
    // if ($stmt = mysqli_prepare($link, $sql)) {
    //     mysqli_stmt_bind_param($stmt, "s", $carttype);
    //     mysqli_stmt_execute($stmt);
    //     $result = mysqli_stmt_get_result($stmt);
    //     $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

    //     echo json_encode(['result' => $data]);

    //     mysqli_stmt_close($stmt);
    // } else {
    //     echo json_encode(['error' => 'Query failed']);
    // }

    // mysqli_close($link);
