<?php
// header('Content-Type: application/json;charset=utf-8');
session_start();
// header('Content-Type: application/json');

$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
mysqli_select_db($link, $database); //選擇資料庫
mysqli_query($link, "SET NAMES utf8"); //設定編碼

// $comboId = isset($_GET['combo_id']) ? $_GET['combo_id'] : 1;
// $comboId = isset($_GET['combo_id']) ? $_GET['combo_id'] : 1;
// $comboId = $_SESSION['combo_id'];
$comboId = $_GET['combo_id'];

// echo 
// var_dump($comboId);


?>

<!DOCTYPE html>
<html lang="en">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KFC</title>
    <link rel="stylesheet" type="text/css" href="home_page.css">
</head>

<body>
    <header>
        <div class=logo>
            <img src="image\logo_NewIndex.png" alt="KFC Logo" width="50" height="50">
        </div>
        <div class=member>
            <img src="image\member_black.png" alt="KFC Logo" width="20" height="20">
        </div>
    </header>

    <nav>
        <a href="hotdeal.html">熱門優惠</a>
        <a href="individual.html" style="color: red;">個人餐</a>
        <a href="many.html">多人餐</a>
        <a href="breakfast.html">早餐</a>
        <a href="#single">單點</a>
        <div class=member>
            <a href="shoppingcart.php"><img src="cart_icon.jpg" alt="shoppingcart icon" width="50" height="50"></a>
        </div>
    </nav>

    <div> </div>
    <main class="hub-spoke-flow">
        <div class="content">
            <div class="combo-flow__image">
                <div class="img-md">

                    <img class="lazy" alt="肯德基 雙層咔啦雞腿堡M經典餐" src="image\雙層咔啦雞腿堡M經典餐-20230721-pc.jpg">
                </div>
                <div class="mealsCartList">
                    <h1 class="mealsTitle">
                        <span class="smaller ">雙層咔啦雞腿堡 M經典餐</span>
                    </h1>

                    <div class="front-bold front_color_gray" style="margin-bottom: 8px;">
                    </div>

                    <div id="divMealListText">
                        <p class="price-row mealList">
                            <span>雙層咔啦雞腿堡 x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>香酥脆薯(中) x 1</span>
                        </p>
                        <p class="price-row mealList">
                            <span>百事可樂(中) x 1</span>
                        </p>
                    </div>
                    <hr>
                    <p class="price-row mealList">
                        <span>餐點小計</span>
                        <span class="small-price">
                            $
                            <span id="MealTotalPrice">197</span>
                        </span>
                    </p>

                </div>
            </div>

            <div class="fench_none">
                <div class="combo-flow__imformation">
                    <div calss="card_dispaly">
                        <div id="mealType">
                            <?php

                            // $sql = "select * from ((combination 
                            // join combo on combination.combo_id = combo.combo_id) 
                            // join cartetype on cartetype.cartetype_id = combination.cartetype_id) 
                            // join meals on meals.cartetype_id = combination.cartetype_id 
                            // where combination.combo_id = $comboId";

                            // $result = mysqli_query($link, $sql);
                            // $row = mysqli_fetch_assoc($result);
                            // echo '<div class="card mb-3" style="max-width: 540px;">';
                            // echo '    <div class="row g-0">';
                            // echo '        <div class="col-md-4">';
                            // echo '            <img src="' . $row['combo_picture'] . '" class="img-fluid rounded-start" alt="' . $row['meals_name'] . '">';
                            // echo '        </div>';
                            // echo '        <div class="col-md-8">';
                            // echo '            <div class="card-body">';
                            // echo '                <h5 class="card-title">主餐</h5>';
                            // echo '                <p class="card-text">' . $row['combo_name'] . 'x1</p>';
                            // echo '            </div>';
                            // echo '        </div>';
                            // echo '    </div>';
                            // echo '</div>';
                            // // $carttype = $row['cartetype_id'];
                            // while ($row = mysqli_fetch_assoc($result)) {
                            //     if (strpos($row['combo_content'], $row['meals_name']) !== false) {
                            //         echo '<div class="card mb-3" style="max-width: 540px;">';
                            //         echo '    <div class="row g-0">';
                            //         echo '        <div class="col-md-4">';
                            //         echo '            <img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt="' . $row['meals_name'] . '">';
                            //         echo '        </div>';
                            //         echo '        <div class="col-md-8">';
                            //         echo '            <div class="card-body">';
                            //         echo '                <h5 class="card-title">' . $row['cartetype_name'] . '</h5>';
                            //         echo '                <p class="card-text">' . $row['meals_name'] . 'x1</p>';

                            //         $carttype = $row['cartetype_id'];
                            //         echo '<input type="hidden" id="mealTypeInput" name="mealType" value="">';

                            //         // 加入 data-combo-id 屬性，以便在 JavaScript 中獲取
                            //         echo '<a href="#" class="group-item__change" data-combo-id="' . $carttype . '" data-combo-id_2="' . $comboId . '" onclick="showReplacementDialog(this)">更換';
                            //         echo '            <span class="chevron-inline"></span>';
                            //         echo '        </a>';

                            //         echo '            </div>';
                            //         echo '        </div>';
                            //         echo '    </div>';
                            //         echo '</div>';
                            //     }
                            // }

                            ?>
                            <div class="card mb-3" style="max-width: 540px;">
                                <div class="row g-0">
                                    <div class="col-md-4">
                                        <img src="image\雙層咔啦雞腿堡-20230721.jpg" class="img-fluid rounded-start" alt="雙層咔啦雞腿堡">
                                    </div>
                                    <div class="col-md-8">
                                        <div class="card-body">
                                            <h5 class="card-title">主餐</h5>
                                            <p class="card-text">雙層咔啦雞腿堡x1</p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="frenchContent">
                                <div class="card mb-3" style="max-width: 540px;">
                                    <div class="row g-0">
                                        <div class="col-md-4">
                                            <img src="image\M-香酥脆薯(中)-210726.png" class="img-fluid rounded-start" alt="M-香酥脆薯(中)">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">配餐</h5>
                                                <p class="card-text" id="frenchDescription">香酥脆薯(中)x1</p>
                                                <a href="#" class="group-item__change" onclick="showReplacementDialog_french()">
                                                    更換
                                                    <span class="chevron-inline">
                                                    </span>
                                                </a>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="drinkContent">
                                <div class="card mb-3" style="max-width: 540px;">
                                    <div class="row g-0">
                                        <div class="col-md-4">
                                            <img src="image\M-可樂中-210512.png" class="img-fluid rounded-start" alt="飲料">
                                        </div>
                                        <div class="col-md-8">
                                            <div class="card-body">
                                                <h5 class="card-title">飲料</h5>
                                                <p class="card-text" id="drinkDescription">百事可樂(中)x1</p>
                                                <a href="#" class="group-item__change" onclick="showReplacementDialog()">
                                                    更換
                                                    <span class="chevron-inline">
                                                    </span>
                                                </a>

                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                        </div>


                        <div class="amount-price">
                            <div class="incrementer">
                                <button class="js-dec" onclick="decrementQuantity()">
                                    <img src="image\inc-minus.png" alt="Decrement">
                                </button>

                                <input title="Quantity" type="text" readonly value="1" id="txtQuantity">

                                <button class="js-inc" onclick="incrementQuantity()">
                                    <img src="image\inc-plus.png" alt="Increment">
                                </button>

                                <span class="small-small-price">
                                    <span class="singleM">餐點 </span>
                                    $
                                    <span class="integer">

                                        <span id="MealTotalPriceNoDiscount">
                                            197
                                        </span>
                                    </span>
                                </span>
                            </div>
                        </div>
                        <hr>
                        <div>
                            <button type="button" class="btn-white " onclick="">
                                <span>回到菜單</span>
                            </button>
                            <button type="button" class="btn-red " onclick="">
                                <span>加入餐車</span>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="meal.js">
        </script>
    </main>






</body>

<div id="replacementDialog" style="display: none;">

    <?php
    // // $jsonData = file_get_contents('php://input');
    // // $data = json_decode($jsonData, true);  // 將 JSON 資料轉換為 PHP 陣列
    // // if (isset($data['carttpye'])) {
    // //     $carttype = $data['carttpye'];
    // //     echo "Carttype from JSON: $carttype";
    // //     // 在這裡進行其他操作
    // // } else {
    // //     echo "Carttype is not set.";
    // // }

    // // $carttype = $data['carttpye'];
    // // echo "Carttype from JSON: $carttype";

    // // session_start();
    // // $carttype = Mealtype;
    // // $carttype = isset($_GET['cartetype_id']) ? $_GET['cartetype_id'] : '';
    // // $carttype = isset($_GET['Mealtype']) ? $_GET['Mealtype'] : '';
    // // var_dump($_GET);

    // // var_dump($carttype);
    // $sql = "SELECT * FROM combination 
    //     JOIN combo ON combination.combo_id = combo.combo_id
    //     JOIN cartetype ON cartetype.cartetype_id = combination.cartetype_id
    //     JOIN meals ON meals.cartetype_id = combination.cartetype_id
    //     WHERE combination.combo_id = $comboId
    //     AND cartetype.cartetype_id = $carttype";

    // // var_dump($carttype);

    // $result = mysqli_query($link, $sql);
    // $row = mysqli_fetch_assoc($result);
    // $index = 1;

    // echo "<h3>{$row['cartetype_name']} </h3>";
    // echo '<h5 id="replacementQuantity">共可選1杯</h5>';
    // echo '<div class="combo-flow__imformation" id="replacementItems">';
    // while ($row = mysqli_fetch_assoc($result)) {

    //     echo '<div class="card_dispaly">';
    //     echo '<div class="card mb-3" style="max-width: 540px;">';
    //     echo '<div class="row g-0">';
    //     echo '<div class="col-md-4">';
    //     echo '<img src="' . $row['meals_picture'] . '" class="img-fluid rounded-start" alt=' . $row['meals_name'] . '">';
    //     echo '<p class="hidden-card-text">' . $row['meals_name'] . '</p>';
    //     echo '<div class="incrementer-right">';
    //     echo '<button class="js-dec" onclick="updateQuantity(\'Del\', \'' . $row['meals_name'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    //     echo '<img src="image\inc-minus.png" alt="Decrement">';
    //     echo '</button>';
    //     echo '<input title="Quantity" type="text" readonly value="0" id="txtQuantity_cola">';
    //     echo '<button class="js-inc" onclick="updateQuantity(\'Add\', \'' . $row['meals_name'] . '\', \'txtQuantity_' . $index . '\', \'replacementQuantity\', \'' . $row['meals_name'] . '\')">';
    //     echo '<img src="image\inc-plus.png" alt="Increment">';
    //     echo '</button>';
    //     echo '</div>';
    //     echo '</div>';
    // }
    // echo '</div>';
    // echo '</div>';
    // echo '</div>';

    ?>

    <h3>飲料</h3>

    <h5 id="replacementQuantity">共可選1杯</h5>
    <div class="combo-flow__imformation" id="replacementItems  ">
        <div calss="card_dispaly">
            <!-- <div id="drinkDescription"> -->


            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e7%99%be%e4%ba%8b%e5%8f%af%e6%a8%8220220105-pc.jpg" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">百事可樂(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','百事可樂','txtQuantity_cola', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="1" id="txtQuantity_cola">

                            <button class="js-inc" onclick="updateQuantity('Add','百事可樂','txtQuantity_cola', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e4%b8%83%e5%96%9c(%e4%b8%ad)20220106-pc.jpg" class="img-fluid rounded-start" alt="七喜(中)">
                        <p class="hidden-card-text">七喜(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','七喜','txtQuantity_seven_up','replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_seven_up">

                            <button class="js-inc" onclick="updateQuantity('Add','七喜','txtQuantity_seven_up','replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e7%b4%85%e8%8c%b6-20230425-pc.jpg" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">立頓檸檬風味紅茶(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','檸檬風味紅茶','txtQuantity_tea', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_tea">

                            <button class="js-inc" onclick="updateQuantity('Add','檸檬風味紅茶','txtQuantity_tea', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e5%86%b0%e7%84%a1%e7%b3%96%e8%8c%89%e8%8e%89%e7%b6%a0%e8%8c%b6(%e4%b8%ad)-pc.jpg" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">冰無糖綠茶(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','冰無糖綠茶','txtQuantity_greentea', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_greentea">

                            <button class="js-inc" onclick="updateQuantity('Add','冰無糖綠茶','txtQuantity_greentea', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e7%86%b1%e7%b4%85%e8%8c%b6-pc.jpg" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">熱紅茶</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity('Del','熱紅茶','txtQuantity_redtea', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_redtea">

                            <button class="js-inc" onclick="updateQuantity('Add','熱紅茶','txtQuantity_redtea', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <!-- </div> -->
            <hr>
            <div>
                <button type="button" class="btn-red " onclick=" confirmReplacement()">
                    <span>確認餐點</span>
                </button>
                <button type="button" class="btn-white " onclick="cancelReplacement()">
                    <span>取消</span>
                </button>
            </div>


        </div>
    </div>




</div>

<div id="replacement_french_Dialog" style="display: none;">

    <h3>脆薯</h3>

    <h5 id="replacementQuantity">共可選1份</h5>
    <div class="combo-flow__imformation" id="replacementItems  ">
        <div calss="card_dispaly">
            <!-- <div id="drinkDescription"> -->


            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e9%a6%99%e9%85%a5%e8%84%86%e8%96%af(%e4%b8%ad)-210726-pc.jpg" class="img-fluid rounded-start" alt="百事可樂(中)">
                        <p class="hidden-card-text">香酥脆薯(中)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity_French('Del','香酥脆薯_中','txtQuantity_min', 'replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="1" id="txtQuantity_min">

                            <button class="js-inc" onclick="updateQuantity_French('Add','香酥脆薯_中','txtQuantity_min', 'replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>

            <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                    <div class="col-md-4">
                        <img src="https://kfcoosfs.kfcclub.com.tw/%e9%a6%99%e9%85%a5%e8%84%86%e8%96%af(%e5%a4%a7)-210726-pc.jpg" class="img-fluid rounded-start" alt="七喜(中)">
                        <p class="hidden-card-text">香酥脆薯(大)</p>
                        <div class="incrementer-right">
                            <button class="js-dec" onclick="updateQuantity_French('Del','香酥脆薯_大','txtQuantity_mux','replacementQuantity')">
                                <img src="image\inc-minus.png" alt="Decrement">
                            </button>

                            <input title="Quantity" type="text" readonly value="0" id="txtQuantity_mux">

                            <button class="js-inc" onclick="updateQuantity_French('Add','香酥脆薯_大','txtQuantity_mux','replacementQuantity')">
                                <img src="image\inc-plus.png" alt="Increment">
                            </button>
                        </div>
                    </div>

                </div>
            </div>



            <!-- </div> -->
            <hr>
            <div>
                <button type="button" class="btn-red " onclick=" confirmReplacement_french()">
                    <span>確認餐點</span>
                </button>
                <button type="button" class="btn-white " onclick="cancelReplacement_french()">
                    <span>取消</span>
                </button>
            </div>


        </div>
    </div>




</div>

</html>