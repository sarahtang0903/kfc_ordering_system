<?php
// //session_start();
// header('Content-Type: application/json;charset=utf-8'); // 回傳 json 格式的資料

// $host = "localhost";
// $user = "root";
// $password = "";
// $database = "software_engineer_db";
// $link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫"); // 建立與資料庫的連線物件
// mysqli_select_db($link, $database); //選擇資料庫
// mysqli_query($link, "SET NAMES utf8"); //設定編碼

// // 根據 GET 參數設定相關值
// if (!empty($_GET['act'])) {
//     $action = $_GET['act'];
// }
// // if (!empty($_GET['val'])) {
// //     $val = $_GET['val'];
// // }

// $list = array(); //存放查詢結果的陣列

// try {
//     switch ($action) {
//         case 'pickupcity':
//             $sql = "SELECT * FROM pickupcity WHERE 1";
//             $result = mysqli_query($link, $sql);
//             while ($row = mysqli_fetch_assoc($result)) {
//                 $list[] = $row;
//             }
//             break;

//         case 'pickupcity_id':
//             $val = $_POST['val'];
//             $sql = "SELECT * FROM  pickupcity  WHERE pickupcity_id = '$val'";
//             $result = mysqli_query($link, $sql);
//             while ($row = mysqli_fetch_assoc($result)) {
//                 $list[] = $row;
//             }
//             break;

//         case 'branch':
//             $sql = "SELECT * FROM branch WHERE pickuparea_id = '$val'";
//             $result = mysqli_query($link, $sql);
//             while ($row = mysqli_fetch_assoc($result)) {
//                 $list[] = $row;
//             }
//             break;
//     }

//     echo json_encode($list);
// } catch (Exception $e) {
//     // 如果有例外發生，返回包含錯誤訊息的 JSON
//     echo json_encode(array('error' => $e->getMessage()));
// }

// // 釋放記憶體
// mysqli_free_result($result);

// // 釋放連線
// mysqli_close($link);
$host = "localhost";
$user = "root";
$password = "";
$database = "software_db";
$link = mysqli_connect($host, $user, $password) or die("無法選擇資料庫");
mysqli_select_db($link, $database);
mysqli_query($link, "SET NAMES utf8");

if (isset($_GET['pickupcity_id'])) {
    $val = mysqli_real_escape_string($link, $_GET['pickupcity_id']);

    // 根據城市 ID 查詢相應的地區
    $sql = "SELECT * FROM pickuparea WHERE pickupcity_id = '$val'";
    $result = mysqli_query($link, $sql);

    $districts = array();
    while ($cat = mysqli_fetch_assoc($result)) {
        $districts[] = array('pickuparea_id' => $cat['pickuparea_id'], 'pickuparea_name' => $cat['pickuparea_name']);
    }

    echo json_encode($districts);

    mysqli_free_result($result);
}

mysqli_close($link);

?>
<html>
<h1>hello</h1>

</html>